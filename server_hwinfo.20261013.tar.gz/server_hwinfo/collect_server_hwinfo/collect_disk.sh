#!/bin/bash
# ============================================================================
# 服务器硬盘信息收集脚本
#   支持 MegaRAID(storcli64) / LSI SAS3 HBA(sas3ircu) / Adaptec(arcconf)
#   输出 22 列 CSV，列结构自 v59 起保持不变。
#
# v62 = v61 + 缺陷修复与实现优化。CSV 列结构（22 列）与 v59~v61 完全一致。
#
# P0 修复：
#   P0-7  ★ 换行符统一为 LF，并加运行时 CR 自检。
#         v61 的文件是 CRLF（3006 个 CRLF / 0 个 LF），在 Linux 上属于
#         "连跑都跑不起来"级别的问题：
#           ① ./collect_disk.sh → bad interpreter: /bin/bash^M
#           ② bash collect_disk.sh → $'\r' 混进每个值，
#              `[[ "$DEBUG" == "true" ]]` / `[[ "$MOCK_MODE" == "true" ]]`
#              全部恒假（-d、mock 判定静默失效）
#           ③ show_help 的 <<'EOF' 终止行变成 "EOF\r"，heredoc 永不闭合，
#              从 show_help 到文件末尾（含 parse_args / main 的定义与调用）
#              被整体吞进 heredoc —— 脚本"成功退出 0"但什么都不做。
#         现在检测到自身含 CR 时立即报错并以退出码 5 结束，避免再有人
#         用编辑器存成 CRLF 后得到一个"假装成功"的脚本。
#
# v62 缺陷修复（承接 v61 遗留项）：
#   F-1  lsi_gen_of_bdf：v61 的 SAS(39|40|41|50|51)[0-9][0-9] 要求型号后必须
#        跟两位数字，而 lspci 的真实输出是 "MegaRAID 12GSAS/PCIe Secure SAS39xx"
#        （本机 report.html 实测），"xx" 不是数字 → 型号正则不命中 → 落到
#        PID 表也查不到（9560-16i 不在表里）→ 返回 unknown。后果有二：
#          ① 某些 lspci 库输出 "SAS3916" 这类四位型号时会命中 sas4，
#             于是对一张【正在正常工作】的 MegaRAID 卡打印
#             "检测到 SAS4 HBA，脚本不支持"的恐吓性告警；
#          ② 返回 unknown 时卡被归入 lsi_unknown_bdfs，一旦 storcli 无输出
#             就被丢给 sas3ircu —— 正是 v60 声明要避免的、白白超时 20 秒的场景。
#        改为按【家族前缀 + 代数后缀】判定：SAS3[0-9]xx / SAS34xx / SAS35xx
#        → sas3，SAS38xx / SAS39xx → sas4，并识别 SAS2 家族。
#   F-2  SAS4 告警按 PCI class 区分措辞：在 MegaRAID(0x0104) 上"sas4"指的是
#        RAID 卡，"改用 storcli64 或装 sas4ircu"这句建议是错的。
#   F-3  smart_serial_of 不再 tr -d ' \n'。旧写法会把序列号【内部】的空格
#        一并删掉（"PHYF 1296" → "PHYF1296"），而 by-id 兜底链（_get_disk_serial）
#        保留原样，两条链拿到的序列号写法不一致 —— 而序列号正是去重键，
#        同一块盘会被记成两条。改为只去 CR 与首尾空白。
#   F-4  run_cmd 支持捕获 stderr（STDERR_CAPTURE=1）：默认仍丢弃 stderr 保持
#        行为不变；开启后把首次出现的错误信息写入 DEBUG 日志，使
#        "权限不足"与"设备不响应"可以区分。
#   F-5  sanitize_name 增加 8 位校验和：纯字符替换时，不同系统序列号可能被
#        映射成同一个文件名而互相覆盖（多机汇总时尤其危险）。
#   F-6  列数防呆：output_row 强制校验字段数恰好等于表头列数，不一致立即
#        报错。v61 里 emit_row 的四个调用点全靠手工数 23 个参数，数错只会
#        静默错列，没有任何提示。
#   F-7  build_ctrl_channels 不再拿 "关联数组非空" 当"已初始化"标志
#        （语义混淆，容易被误读为真正的缓存判断）。
#   F-8  mock 文件层缺失同样登记到 --mock-strict（v61 只覆盖命令层），
#        否则 mock 跑出 0 条记录时无法区分"夹具没搭"和"逻辑就是没采到"。
#   F-9  （v62 定稿）标称容量对齐做了两件事：
#        ① 容差 5% → 4%。这是本次【真正修掉的缺陷】。物理事实是
#           "厂商标称 ≥ 实际，且差别很小"，所以贴档不该向下贴；而 5% 恰好
#           会把 250 下贴到 240、500 下贴到 480（均 4.17%），等于把盘标小。
#           收紧到 4% 后 250/500/256/512 全部原样保留。
#           下界由最紧的企业档决定：1.6TB 盘 lsblk "1.5T"→1649，与 1600
#           差 3.06%，故容差必须 > 3.06%。实测 4% 时 70 个企业盘组合 0 误判。
#        ② 候选表收敛为【企业级】盘型，共 46 档：
#           · 删消费级 250 500 256 512 与上古 30 60
#           · 删从未命中的冗余档 9000 15000 21000
#           · 补 26000 28000 —— 真实误判修复：26TB 实测 26005/26058，
#             旧表无 26000 档会被 25600 抢走（偏 1.5%）
#           · 补 375 750 1500（Optane P4800X）；1500 缺失会让 1.5TB 被 1600 抢走
#           · 保留 1024~32768 的 TiB 整档
#           · 明确【不做】按口径分表：_size_to_gb 已把两种口径折成同一尺度
#        ③ 教训：审计时曾据"手算"误报 18TB 会被 16384 抢走并想改表，
#           实为审计脚本跳过了单位换算。现自测已加强制端到端断言防复犯。
#   F-10 新增 --test：纯函数自测。无副作用、不需要 root、不需要真机、
#        不需要 mock 目录，用于锁住核心逻辑（容量换算 / 标称对齐 /
#        SAS 代数判定 / CSV 转义 / 去重键 / 序列号归一化）。
#        自测自身经历 3 轮真机纠错，均已修正并留下防回归断言：
#          · 表头列数曾用 `tr ',' '\n' | wc -l` 数成【逗号数】，少 1
#          · "447 → 480" 未核算容差（实为 6.9%，超 5%，应保持 447）
#          · 标称表曾自相矛盾（删 256 又断言 256 → 256）
#          · 端到端断言必须连 _size_to_gb 一起跑，否则会造出假 BUG
#   F-11 errors 列：ATA 与 SCSI/SAS 拆成两条独立分支（★ 修掉一个严重漏报 ★）
#        问题：get_disk_type 只看 NVMe/SSD，SATA 盘和 SAS 盘都判成 "HDD"，
#        于是两者都走 ATA 分支；但 SAS 盘的 smartctl -a 是 SCSI 格式、没有
#        "ID# ATTRIBUTE_NAME" 属性表，所有取值皆空 —— G-list 有 12 项、
#        非介质错误 3 次的坏盘会被报成 errors=0，看上去像全新盘。
#        修复：
#          · 用输出内容判别格式（SCSI 有 "SMART Health Status"，ATA 有属性表，
#            两者互斥），不依赖 disk_type
#          · ATA 分支新增 188 Command_Timeout / 187 Reported_Uncorrect /
#            10 Spin_Retry_Count —— 188 是独立于介质的失效模式（供电/线缆/
#            机械老化），一块盘可以 197=198=0 而 188 很大
#          · 新增 SCSI/SAS 分支：G-list（增长坏道）、Non-medium error count
#            （SCSI 版的 188）、read/write/verify 三行的 Total uncorrected
#            errors 求和、SMART Health Status 非 OK 即登记
#          · 所有模式用 "^[[:space:]]*" 开头，容忍各版本/厂商的缩进差异
#        注意：188 的 RAW_VALUE 语义随厂商而异（Seagate 是 3×16 位打包值），
#        无法可靠区分厂商，故按原始值登记，由人工判断量级。
#   F-10 新增 --test：纯函数自测。无副作用、不需要 root、不需要真机、
#        不需要 mock 目录，用于锁住核心逻辑（容量换算 / 标称对齐 /
#        SAS 代数判定 / CSV 转义 / 去重键 / 序列号归一化 / errors 双分支）。
#        自测自身经历 3 轮真机纠错，均已修正并留下防回归断言：
#          · 表头列数曾用 `tr ',' '\n' | wc -l` 数成【逗号数】，少 1
#          · "447 → 480" 未核算容差（实为 6.9%，超 5%，应保持 447）
#          · 标称表曾自相矛盾（删 256 又断言 256 → 256）
#          · 端到端断言必须连 _size_to_gb 一起跑，否则会造出假 BUG

# v61 = v60 + 精简与可读性整理（无功能变更）：
#   · 合并重复实现（约 -200 行）
#       _find_tool            → storcli/sas3ircu/arcconf 三个查找器各剩 4 行
#       _size_to_gb           → convert_size_to_gb / convert_gib_to_gb 只差倍率
#       _first_sd_under_bdf   → 原来的 _find_ctrl_first_os_dev + _find_first_sd_under_ctrl
#       _find_osdev_by_wwid   → 原来的 arcconf WWID 反查 + sas3ircu VD WWID 反查
#       _err_add_num          → 8 处 "取值 + 校验 >0 + 登记" 收敛成一行
#       _field_val            → 统一的 "标签: 值" 取值
#       health_fields         → 三个分支各写一遍的 PH/LIFE/ERRORS 收敛成一次调用
#       nvme_scan             → nvme id-ctrl 解析直接写全局，去掉 KEY=VALUE 往返
#   · 可读性
#       目录(TOC) + 编号分节；每个函数上方一行用途注释；统一空行分隔
#
# v60 = v59 + P0/P1 修复。CSV 列结构（22 列）与 v59 完全一致。
#
# P0 修复：
#   P0-1  -s/--serial 不再被自动探测结果覆盖
#   P0-2  MegaRAID 分支的 disk_size_gb 改用【物理盘容量】（v59 误取了 VD 容量，
#         导致 RAID 组内每块盘都显示逻辑卷大小）
#   P0-3  去重改为内存关联数组（v59 用 grep ",$sn,"，序列号缺失时会被 ",," 误判，
#         把后续所有缺序列号的盘静默丢弃；同时是 O(n^2) 且未转义）
#   P0-4  errors 基于真正取到 SMART 的那块设备计算（v59 固定传 megaraid 通道设备，
#         丢掉了 --device=megaraid,DID，取到的是 VD 的 SMART）
#   P0-5  PCIe slot 缓存键统一为 BDF（v59 有一处用原始字符串做键，永不命中）
#   P0-6  删除 arcconf LD 解析中把 "Present" 当序列号写入 ADP_PD_RAID 的死逻辑
#
# P1 修复：
#   P1-1  SMART / NVMe 结果在父 shell 缓存，并记住可用的 -d 类型
#         （单盘 smartctl 调用从最多 ~20 次降到 1~2 次）
#   P1-2  分支选择按控制器（BDF）判定：MegaRAID + SAS3、SAS3 + SAS4 混插时
#         不再整类丢盘；SAS4 只跳过它自己
#   P1-3  arcconf 支持多控制器；mvcli 走 run_cmd（mock 可用，key=mvcli.info.o.hba）
#   P1-4  run_cmd 统一加 timeout，并记录非零退出码（DEBUG 可见）
#   P1-5  容量换算支持 lsblk 单字母后缀（465.8G / 1.8T）与 bytes；标称容量表补齐
#   P1-6  统一 SMART 字段解析；0 小时 / 0% 磨损不再被当成缺失
#   P1-7  pcie_gen 取【实际协商速率】(LnkSta)，能力仍在 pcie_link_cap
#   P1-8  disk_pci_busid 统一输出 BDF（v59 在 SATA 路径上会写入 by-path 名字）
#   P1-9  依赖自检、LC_ALL=C、mktemp + trap 清理、退出码、文件名清洗、--quiet
#   P1-10 mock：links.tsv 纯 bash 预载 + 精确匹配（不再 grep -P）+ 多级链解析；
#         新增 --mock-strict 汇总缺失的 mock 命令 key
#
# v60 追加修复：
#   · 颜色：v59 的颜色常量是字面量 '\033[0;32m' 并靠 echo -e 解释；改走 printf 后
#     变成字面输出。现用 $'...'（真实 ESC 字节），两个流都被重定向时自动去色。
#   · disk_model 友好名：带厂商前缀的型号（INTEL SSDSC2KB480G8）也能匹配到 S4510
#   · SMART 属性值带前导 0（099）不再触发 bash 八进制解析错误（_dec）
#   · sas3ircu 只在 class=0x0107（SAS HBA）上运行；MegaRAID(0x0104) 交给 storcli
#
# 目录：
#   §1  全局配置            §10 磁盘路径映射
#   §2  日志与颜色          §11 PCIe Slot / 链路
#   §3  Mock 基础设施       §12 控制器探测与工具查找
#   §4  通用工具            §13 storcli 分支（MegaRAID）
#   §5  PCI 地址工具        §14 sas3ircu 分支（SAS3 HBA）
#   §6  容量换算            §15 arcconf 分支（Adaptec）
#   §7  SMART/NVMe 缓存     §16 fallback 分支（lsblk）
#   §8  SMART 字段解析      §17 主流程与输出
#   §9  厂商/型号映射       §18 自测（--test）
#                           §19 命令行与入口
#
# 有意不做的事（避免引入新风险）：
#   · 不用 set -e / set -u / pipefail：本脚本大量使用 `cmd | head -1`、
#     `grep -q <<< "$var"` 与 `${arr[x]:-}`，pipefail 会因 SIGPIPE 误判失败
#   · 不改 CSV 列结构（VD 容量只在日志里输出）
# ============================================================================

# ============================================================================
# §1 全局配置
# ============================================================================

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
readonly SCRIPT_VERSION="62"

OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
SYSTEM_SERIAL=""                       # 仅在 -s 时被赋值，main 不会覆盖
DEBUG="${DEBUG:-false}"
QUIET=false
MOCK_STRICT=false
MOCK_DIR="${MOCK_DIR:-}"
MOCK_MODE=false
[[ -n "$MOCK_DIR" ]] && MOCK_MODE=true
CMD_TIMEOUT="${CMD_TIMEOUT:-20}"
TIMEOUT_BIN=""
STDERR_CAPTURE="${STDERR_CAPTURE:-0}"  # 1 = 把外部命令的 stderr 首次出现时记入 DEBUG
SELF_TEST=false                        # --test

OUTPUT_FILE=""
ROWS_FILE=""                           # 采集结果暂存（<排序键>\t<行>）
MOCK_MISS_FILE=""                      # --mock-strict 用的缺失 key 记录
MOCK_FS_MISS_FILE=""                   # （F-8）mock 文件层未命中的路径记录

# CSV 表头：emit_row 的 22 个字段必须与这里的顺序一一对应
readonly CSV_HEADER="server_serial,disk_type,disk_vendor,disk_model,disk_product,disk_serial,disk_size_gb,disk_firmware,disk_dev_name,disk_wwn,disk_raid_mode,disk_pci_busid,pcie_slot,raid_ctrl_slot,pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,disk_power_hours,disk_life_percent,errors"

# 列数（F-6：output_row 用它做防呆，不再靠人肉数参数）
readonly CSV_COLUMNS=22

# 强制 C locale，保证 sort/awk/正则行为稳定
export LC_ALL=C

# ---------------------------------------------------------------------------
# P0-7：换行符自检
#   本脚本在 Linux 上运行，必须是 LF。若被编辑器存成 CRLF，症状极其隐蔽：
#   行尾的 \r 会混进每个变量值（比较一律失败），show_help 的 heredoc 终止行
#   变成 "EOF\r" 导致【从 show_help 到文件结尾被整体当成 heredoc 文本】，
#   脚本于是"成功退出 0 但什么都没做"。
#   与其让人对着一个静默无输出的脚本排查半天，不如在这里立刻失败。
#   用 head -c 4096 只读文件头部：足以覆盖 shebang 与开头几行，且不依赖
#   整个文件能否被完整读取。
# ---------------------------------------------------------------------------
check_own_line_endings() {
    local self="${BASH_SOURCE[0]}" head_bytes
    [[ -r "$self" ]] || return 0
    head_bytes=$(head -c 4096 "$self" 2>/dev/null | tr -d '\n' | tr -cd '\r' | wc -c)
    head_bytes=${head_bytes//[!0-9]/}
    [[ -z "$head_bytes" || "$head_bytes" -eq 0 ]] && return 0
    {
        printf '=========================================================\n'
        printf '[ERROR] 本脚本的换行符是 CRLF，无法在 Linux 下运行。\n'
        printf '=========================================================\n'
        printf '  这在 bash 下会引发三类故障：\n'
        printf '    1) ./collect_disk.sh  → bad interpreter: /bin/bash^M\n'
        printf '    2) 行尾的 \\r 混进每个变量值，所有字符串比较恒假\n'
        printf '       （-d/--debug、--mock-dir 等判定会静默失效）\n'
        printf '    3) show_help 的 heredoc 终止行变成 "EOF\\r" 而不闭合，\n'
        printf '       从 show_help 到文件末尾（含 main 的调用）会被整体\n'
        printf '       吞进 heredoc —— 脚本"成功退出"但什么都不做\n'
        printf '\n'
        printf '  修复：\n'
        printf '    sed -i "s/\\r$//" %s\n' "$self"
        printf '  防复发（git 仓库内）：\n'
        printf '    printf "*.sh text eol=lf\\n" > .gitattributes\n'
        printf '=========================================================\n'
    } >&2
    return 5
}

check_own_line_endings || exit 5

# ============================================================================
# §2 日志与颜色
# ============================================================================

# 颜色：
#   · 用 $'...'（ANSI-C 引用）写入【真实 ESC 字节】。v59 用的是字面量 '\033[0;32m'
#     并依赖 echo -e 去解释；现在日志走 printf，不再解释参数里的 \033，
#     否则会打印出 "\033[0;32m[INFO]\033[0m" 这种字面串。
#   · 默认在交互（stdout 或 stderr 是终端）时着色；两个流都被重定向时自动关闭，
#     避免日志文件里混入 ESC 字节。
#   · NO_COLOR=1 强制关闭，FORCE_COLOR=1 强制开启。
if [[ -n "${NO_COLOR:-}" ]]; then
    readonly RED='' GREEN='' YELLOW='' BLUE='' NC=''
elif [[ "${FORCE_COLOR:-}" == "1" || -t 1 || -t 2 ]]; then
    readonly RED=$'\033[0;31m'
    readonly GREEN=$'\033[0;32m'
    readonly YELLOW=$'\033[1;33m'
    readonly BLUE=$'\033[0;34m'
    readonly NC=$'\033[0m'
else
    readonly RED='' GREEN='' YELLOW='' BLUE='' NC=''
fi

# 全部日志走 stderr，stdout 只留给标题/CSV，方便 2>/dev/null 或管道重定向
log_info()  { printf '%s[INFO]%s %s\n'  "$GREEN"  "$NC" "$*" >&2; }
log_warn()  { printf '%s[WARN]%s %s\n'  "$YELLOW" "$NC" "$*" >&2; }
log_error() { printf '%s[ERROR]%s %s\n' "$RED"    "$NC" "$*" >&2; }
log_debug() { [[ "$DEBUG" == "true" ]] && printf '%s[DEBUG]%s %s\n' "$BLUE" "$NC" "$*" >&2; return 0; }

# 分隔线（stdout）
print_separator() { printf '=========================================\n'; }

if [[ "$(id -u)" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi

# ============================================================================
# §3 Mock 基础设施
#   命令层：$MOCK_DIR/cmd/<key>.txt
#   文件层：$MOCK_DIR/fs/<原路径> + $MOCK_DIR/fs/links.tsv（符号链接记录）
#   设计约束：命令替换 $( ) 是子 shell，所有“缓存/状态”必须由父 shell 写。
# ============================================================================

declare -A MOCK_LINK=()                # 路径 -> 目标（links.tsv 全量预载）
MOCK_LINKS_LOADED=false

# 记录缺失的 mock 命令 key（写文件，可跨子 shell 存活）
mock_miss() {
    [[ "$MOCK_MODE" == "true" ]] || return 0
    [[ -n "$MOCK_MISS_FILE" ]] || MOCK_MISS_FILE="${TMPDIR:-/tmp}/collect_disk_mock_miss.$$"
    printf '%s\n' "$1" >> "$MOCK_MISS_FILE" 2>/dev/null
    return 0
}

# F-8：mock 文件层的"没找到"记录。
#   与命令层不同，脚本会【大量】合法地探测不存在的路径（/sys/block/X/device/serial、
#   多个 -d 变体、可选的 links.tsv 等），因此文件层的缺失【不能】当作失败——
#   否则 --mock-strict 会永远以 4 退出而失去意义。
#   这里只做记录，由 main 在 strict 模式末尾以提示（非 error）形式列出，
#   用于区分"夹具没搭好"与"逻辑本来就是没采到"。
mock_fs_miss() {
    [[ "$MOCK_MODE" == "true" && "$MOCK_STRICT" == "true" ]] || return 0
    [[ -n "$MOCK_FS_MISS_FILE" ]] || MOCK_FS_MISS_FILE="${TMPDIR:-/tmp}/collect_disk_mock_fsmiss.$$"
    printf '%s\n' "$1" >> "$MOCK_FS_MISS_FILE" 2>/dev/null
    return 0
}

# mock 命令 key 片段：0000:2d:00.0 -> 0000_2d_00_0
_bdf_key() { printf '%s' "$1" | tr ':. ' '___'; }

# mock 命令 key 片段：/dev/sda -> dev.sda
_dev_key() { printf '%s' "$1" | tr '/ ' '._' | sed 's/^\.//'; }

# 纯 bash 路径归一化（去掉 . 与 ..）：/a/b/../c -> /a/c
_norm_path() {
    local p="$1" out="" seg
    local IFS='/'
    for seg in $p; do
        case "$seg" in
            ''|'.') continue ;;
            '..')   out="${out%/*}" ;;
            *)      out="${out}/${seg}" ;;
        esac
    done
    printf '%s' "${out:-/}"
}

# 预载 links.tsv 到关联数组（mock 模式下只需读一次，避免每个路径都 fork grep）
load_mock_links() {
    [[ "$MOCK_MODE" == "true" ]] || return 0
    [[ "$MOCK_LINKS_LOADED" == "true" ]] && return 0
    MOCK_LINKS_LOADED=true
    local f="$MOCK_DIR/fs/links.tsv" p t
    [[ -r "$f" ]] || { log_debug "mock: 无 links.tsv ($f)"; return 0; }
    while IFS=$'\t' read -r p t; do
        p="${p%$'\r'}"; t="${t%$'\r'}"
        [[ -z "$p" ]] && continue
        MOCK_LINK["$p"]="$t"
    done < "$f"
    log_debug "mock: 预载符号链接 ${#MOCK_LINK[@]} 条"
    return 0
}

# 外部命令唯一入口：mock 优先；真实模式统一加 timeout 并把非零退出码写进 DEBUG
#   STDERR_CAPTURE=1 时（F-4）额外捕获 stderr 并把首次出现的错误信息写进 DEBUG，
#   使"权限不足"（Permission denied）与"设备不响应"可以区分。
#   默认关闭：stderr 直接丢弃，行为与 v61 完全一致（stdout 仍是唯一数据来源）。
run_cmd() {
    local key="$1"; shift
    [[ "${1:-}" == "--" ]] && shift
    if [[ "$MOCK_MODE" == "true" ]]; then
        local f="$MOCK_DIR/cmd/${key}.txt"
        if [[ -r "$f" ]]; then
            cat "$f"
        else
            mock_miss "cmd:${key}"
            log_debug "mock 缺失命令: $key ($f)"
        fi
        return 0
    fi
    local rc=0 errfile="" errmsg
    if [[ "$STDERR_CAPTURE" == "1" ]]; then
        # 用临时文件而不是管道：保持 stdout/stderr 分离，且不受 SIGPIPE 影响
        errfile=$(mktemp 2>/dev/null) || errfile=""
    fi

    if [[ -n "$TIMEOUT_BIN" ]]; then
        if [[ -n "$errfile" ]]; then
            "$TIMEOUT_BIN" --signal=TERM --kill-after=5 "$CMD_TIMEOUT" "$@" 2>"$errfile" || rc=$?
        else
            "$TIMEOUT_BIN" --signal=TERM --kill-after=5 "$CMD_TIMEOUT" "$@" 2>/dev/null || rc=$?
        fi
    else
        if [[ -n "$errfile" ]]; then
            "$@" 2>"$errfile" || rc=$?
        else
            "$@" 2>/dev/null || rc=$?
        fi
    fi

    if [[ $rc -ne 0 ]]; then
        log_debug "cmd[${key}] rc=${rc}: $*"
        if [[ -n "$errfile" && -s "$errfile" ]]; then
            errmsg=$(head -1 "$errfile" 2>/dev/null)
            [[ -n "$errmsg" ]] && log_debug "cmd[${key}] stderr: $errmsg"
        fi
    fi
    [[ -n "$errfile" ]] && rm -f "$errfile"
    return 0
}

# 读文件内容（用 $(<file) 而不是 cat，省一次 fork）
_fs_read() {
    local p="$1" f
    if [[ "$MOCK_MODE" == "true" ]]; then
        f="$MOCK_DIR/fs${p}"
        if [[ -f "$f" ]]; then
            printf '%s' "$(<"$f")"
        else
            mock_fs_miss "read:${p}"
        fi
        return 0
    fi
    [[ -f "$p" && -r "$p" ]] && printf '%s' "$(<"$p")"
    return 0
}

# 路径是否存在（mock：fs/ 下存在，或 links.tsv 里有记录）
_fs_exists() {
    local p="$1"
    if [[ "$MOCK_MODE" == "true" ]]; then
        [[ -e "$MOCK_DIR/fs${p}" ]] && return 0
        [[ -n "${MOCK_LINK[$p]+x}" ]] && return 0
        mock_fs_miss "exists:${p}"
        return 1
    fi
    [[ -e "$p" || -L "$p" ]]
}

# 等价 readlink -f：
#   · links.tsv 有记录 → 按链解析（支持相对目标），最多 32 跳
#   · 无记录但 fs/ 下存在 → 返回规范化后的原路径（与 readlink -f 一致，
#     这样 find_upstream_pci_controller 这类“逐级向上找”的逻辑在 mock 下也成立）
#   · 无记录且不存在 → 返回空（与 readlink -f 一致）
_fs_readlink() {
    local p="$1" t="$1" nxt n=0
    if [[ "$MOCK_MODE" == "true" ]]; then
        while [[ -n "${MOCK_LINK[$t]+x}" && $n -lt 32 ]]; do
            nxt="${MOCK_LINK[$t]}"
            case "$nxt" in
                /*) t="$nxt" ;;
                *)  t=$(_norm_path "$(dirname "$t")/${nxt}") ;;
            esac
            n=$((n + 1))
        done
        if [[ "$t" != "$p" ]]; then
            printf '%s\n' "$t"
            return 0
        fi
        [[ -e "$MOCK_DIR/fs${p}" ]] && printf '%s\n' "$(_norm_path "$p")"
        return 0
    fi
    readlink -f "$p" 2>/dev/null
}

# glob 展开（只支持尾部 *，与真实模式一致）：mock 下从预载的 links.tsv 匹配
_fs_glob() {
    local pattern="$1" prefix f p
    if [[ "$MOCK_MODE" == "true" ]]; then
        prefix="${pattern%\*}"
        for p in "${!MOCK_LINK[@]}"; do
            [[ "$p" == "$prefix"* ]] || continue
            [[ "${p#$prefix}" == */* ]] && continue
            printf '%s\n' "$p"
        done
        return 0
    fi
    for f in $pattern; do
        [[ -e "$f" || -L "$f" ]] && printf '%s\n' "$f"
    done
    return 0
}

# 枚举目录下的名字（如 /sys/block 下的磁盘名），mock 下合并 fs/ 目录与 links.tsv
_fs_list_names() {
    local dir="$1" fake n p
    local -A seen
    seen=()
    if [[ "$MOCK_MODE" == "true" ]]; then
        fake="$MOCK_DIR/fs${dir}"
        if [[ -d "$fake" ]]; then
            while IFS= read -r n; do
                [[ -z "$n" ]] && continue
                seen["$n"]=1
                printf '%s\n' "$n"
            done < <(ls -1 "$fake" 2>/dev/null)
        fi
        for p in "${!MOCK_LINK[@]}"; do
            [[ "$p" == "$dir/"* ]] || continue
            n="${p#$dir/}"
            [[ "$n" == */* ]] && continue
            [[ -n "${seen[$n]+x}" ]] && continue
            seen["$n"]=1
            printf '%s\n' "$n"
        done
        return 0
    fi
    ls -1 "$dir" 2>/dev/null
    return 0
}

# ============================================================================
# §4 通用工具
# ============================================================================

# 去首尾空白
_trim() {
    local v="$1"
    v="${v#"${v%%[![:space:]]*}"}"
    v="${v%"${v##*[![:space:]]}"}"
    printf '%s' "$v"
}

# 序列号归一化（F-3）：去掉 CR/LF 与首尾空白，但【保留内部空格】。
# 用于替换 v61 里到处出现的 `tr -d ' \n'` —— 那会把 "PHYF 1296 0001"
# 压成 "PHYF12960001"，使 sysfs / smartctl / by-id 三条链给出的序列号
# 写法不一致，而序列号正是去重键，会把同一块盘记成多条。
_norm_serial() {
    local v="$1"
    v="${v//$'\r'/}"
    v="${v//$'\n'/}"
    _trim "$v"
}

# 去除非数字并按十进制解析。
# smartctl 的属性值常带前导 0（如 099），直接进 [[ -le ]] / (( )) 会被 bash
# 当成八进制并报 "value too great for base"。
_dec() {
    local x="$1"
    x="${x//[!0-9]/}"
    [[ -z "$x" ]] && return 0
    printf '%s' "$((10#$x))"
}

# 取 "标签: 值" 中冒号后的内容（保留内部空格，去首尾空白）
# 用法：_field_val "$text" "<grep -E 模式>"
_field_val() {
    printf '%s\n' "$1" | grep -iE "$2" | head -1 | sed 's/^[^:]*:[[:space:]]*//; s/[[:space:]]*$//'
}

# CSV 字段转义（含逗号/引号/换行时加引号；去掉 CR）
csv_escape() {
    local f="$1"
    f="${f//$'\r'/}"
    [[ -z "$f" ]] && return 0
    if [[ "$f" == *","* || "$f" == *'"'* || "$f" == *$'\n'* ]]; then
        f=${f//\"/\"\"}
        printf '"%s"' "$f"
    else
        printf '%s' "$f"
    fi
}

# 拼一行 CSV（不含换行）
# F-6：强制校验字段数。v61 只做拼接，而 emit_row 的四个调用点全靠手工数
#      23 个参数（去重键 + 22 列），数错不会报错、只会静默错列——
#      而列结构自 v59 起就是对外承诺不能变的。这里一旦不符立即报错。
output_row() {
    if [[ $# -ne $CSV_COLUMNS ]]; then
        log_error "内部错误：output_row 收到 $# 个字段，应为 $CSV_COLUMNS 个（CSV 列结构与 v59 约定不变）"
        return 1
    fi
    local out="" f
    for f in "$@"; do
        out+="$(csv_escape "$f"),"
    done
    printf '%s\n' "${out%,}"
}

# 去重 + 落盘。
#   emit_row <去重键> <22 个字段>
#   键：优先用 disk_serial；序列号缺失时由调用方传 loc:Cx:Ey:Sz，避免 v59 里
#       grep ",," 误判导致后续缺序列号的盘被整批丢弃。
#   暂存格式：<serial>\t<dev>\t<row>，最后按 serial+dev 排序再切掉前两列。
declare -A SEEN=()

# 去重后把这一行追加到暂存文件（去重键与排序键的说明见上）
emit_row() {
    local dk="$1"; shift
    if [[ -n "${SEEN[$dk]+x}" ]]; then
        log_debug "重复记录，跳过: key=$dk"
        return 0
    fi
    SEEN["$dk"]=1
    local row
    row=$(output_row "$@") || return 1
    printf '%s\t%s\t%s\n' "${6:-}" "${9:-}" "$row" >> "$ROWS_FILE"
    return 0
}

# 目标文件名的说明：系统序列号可能含 / 等字符，先清洗再用
# F-5：仅靠字符替换时，两个不同的序列号可能被映射成同一个文件名
#      （例如 "A/B" 与 "A_B" → 都是 "A_B"），多机汇总时会互相覆盖。
#      因此追加 8 位校验和：清洗后为空则退化为纯校验和，保证唯一且可用。
sanitize_name() {
    local s="$1" cleaned sum
    cleaned="${s//[!A-Za-z0-9._-]/_}"
    # cksum 是 POSIX 标准工具，已在 check_deps 的必需列表里
    sum=$(printf '%s' "$s" | cksum 2>/dev/null | awk '{print $1}')
    [[ "$sum" =~ ^[0-9]+$ ]] || sum=0
    sum=$(printf '%08x' "$((sum % 4294967296))" 2>/dev/null)
    [[ -z "$sum" ]] && sum="00000000"
    if [[ -z "$cleaned" ]]; then
        printf 'UNKNOWN_%s' "$sum"
    else
        printf '%s_%s' "$cleaned" "$sum"
    fi
}

# sudo 可用性检查（mock 模式跳过；非交互时只用 sudo -n）
ensure_sudo() {
    [[ "$(id -u)" -eq 0 ]] && return 0
    [[ "$MOCK_MODE" == "true" ]] && return 0
    command -v sudo >/dev/null 2>&1 || { log_error "非 root 且无 sudo"; return 1; }
    sudo -n true 2>/dev/null && return 0
    if [[ -t 0 && -r /dev/tty ]]; then
        log_info "需要 sudo 权限，正在认证..."
        sudo -v 2>/dev/null && return 0
    fi
    log_error "sudo 不可用或认证失败"
    return 1
}

# 依赖自检：必需命令缺失直接失败，可选命令只告警（相关字段降级为 N/A）
check_deps() {
    local c
    local -a missing_req=() missing_opt=()
    for c in awk sed grep sort cut tr head tail ls cat mktemp readlink basename dirname cksum; do
        command -v "$c" >/dev/null 2>&1 || missing_req+=("$c")
    done
    for c in timeout lsblk dmidecode smartctl nvme strings jq tac; do
        command -v "$c" >/dev/null 2>&1 || missing_opt+=("$c")
    done
    if [[ ${#missing_req[@]} -gt 0 ]]; then
        log_error "缺少必需命令: ${missing_req[*]}"
        return 1
    fi
    [[ ${#missing_opt[@]} -gt 0 ]] && log_warn "缺少可选命令（相关字段会降级为 N/A）: ${missing_opt[*]}"
    return 0
}

# ---------------------------------------------------------------------------
# 外部工具路径查找
# ---------------------------------------------------------------------------

# 在候选列表里找可执行文件：绝对路径用 -x 判断，裸名字用 command -v
_find_tool() {
    local c
    for c in "$@"; do
        case "$c" in
            /*) [[ -x "$c" ]] && { printf '%s' "$c"; return 0; } ;;
            *)  command -v "$c" >/dev/null 2>&1 && { printf '%s' "$c"; return 0; } ;;
        esac
    done
    printf ''
}

# storcli64（MegaRAID）：脚本自带 > /opt/MegaRAID > PATH；mock 下允许裸名字
_find_storcli() {
    local c
    c=$(_find_tool "$SCRIPT_DIR/tool/storcli64" "$SCRIPT_DIR/tool/storcli" \
                   /opt/MegaRAID/storcli/storcli64 /opt/MegaRAID/storcli/storcli \
                   /opt/MegaRAID/storcli64 /opt/MegaRAID/storcli storcli64 storcli)
    [[ -z "$c" && "$MOCK_MODE" == "true" ]] && c="storcli64"
    printf '%s' "$c"
}

# sas3ircu（SAS3 HBA）：脚本自带 > /opt/MegaRAID > PATH；mock 下允许裸名字
_find_sas3ircu() {
    local c
    c=$(_find_tool "$SCRIPT_DIR/tool/sas3ircu" /opt/MegaRAID/sas3ircu \
                   /opt/MegaRAID/sas3ircu/sas3ircu sas3ircu /usr/local/bin/sas3ircu)
    [[ -z "$c" && "$MOCK_MODE" == "true" ]] && c="sas3ircu"
    printf '%s' "$c"
}

# arcconf（Adaptec）：脚本自带 > StorMan 安装目录 > PATH；mock 下允许裸名字
_find_arcconf() {
    local c
    c=$(_find_tool "$SCRIPT_DIR/tool/arcconf" /usr/StorMan/arcconf /usr/sbin/arcconf \
                   /sbin/arcconf /opt/StorMan/arcconf arcconf)
    [[ -z "$c" && "$MOCK_MODE" == "true" ]] && c="arcconf"
    printf '%s' "$c"
}

# ============================================================================
# §5 PCI 地址工具
# ============================================================================

# 归一化 PCI 地址：补全 domain，转小写；输入 "00:1f.2" / "0000:00:1f.2"
normalize_pci_addr() {
    local a domain
    a=$(printf '%s' "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    if [[ "$a" =~ ^([0-9a-f]+):([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        domain=$((16#${BASH_REMATCH[1]}))
        printf '%04x:%s:%s.%s' "$domain" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        return 0
    fi
    if [[ "$a" =~ ^([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        printf '0000:%s:%s.%s' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}"
        return 0
    fi
    printf '%s' "$a"
}

# 从任意字符串（by-path 链接名、sysfs 路径等）里提取 BDF；取不到返回空
_extract_bdf() {
    local s="$1"
    [[ -z "$s" ]] && return 0
    if [[ "$s" =~ ^[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$ ]]; then
        printf '%s' "$s"; return 0
    fi
    if [[ "$s" =~ ^[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$ ]]; then
        printf '0000:%s' "$s"; return 0
    fi
    if [[ "$s" =~ (^|-)pci-?([0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]) ]]; then
        printf '%s' "${BASH_REMATCH[2]}"; return 0
    fi
    if [[ "$s" =~ ([0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]) ]]; then
        printf '%s' "${BASH_REMATCH[1]}"; return 0
    fi
    return 0
}

# ============================================================================
# §6 容量换算
# ============================================================================

# 字节 -> 十进制 GB（四舍五入到整数 GB）
bytes_to_gb_vendor() {
    local b="$1"
    [[ -z "$b" || ! "$b" =~ ^[0-9]+$ ]] && return 0
    awk -v v="$b" 'BEGIN { printf "%d", v / 1000000000 + 0.5 }'
}

# 容量文本 -> 十进制 GB 整数。两种口径只差倍率：
#   dec（默认，smartctl 口径）：TB/GB/MB 按 1000 进制；支持 [240 GB]、bytes、MiB
#   bin（storcli / lsblk 口径）：TB/GB/MB 与单字母 T/G/M/TiB/GiB 按 1024 进制
# 无法解析时原样返回。
_size_to_gb() {
    local s="$1" mode="${2:-dec}"
    local n unit mult
    s="${s// /}"; s="${s//,/}"; s="${s//$'\r'/}"
    [[ -z "$s" ]] && return 0

    # 先剥掉 smartctl 的 "[240 GB]" 括号写法
    [[ "$s" =~ \[([0-9.]+)(TB|GB|MB)\] ]] && s="${BASH_REMATCH[1]}${BASH_REMATCH[2]}"

    # 再把单字母 / iB 后缀统一成两字母后缀
    if [[ "$mode" == "bin" ]]; then
        [[ "$s" =~ ^([0-9.]+)Ti?B?$ ]] && s="${BASH_REMATCH[1]}TB"
        [[ "$s" =~ ^([0-9.]+)Gi?B?$ ]] && s="${BASH_REMATCH[1]}GB"
        [[ "$s" =~ ^([0-9.]+)Mi?B?$ ]] && s="${BASH_REMATCH[1]}MB"
    else
        [[ "$s" =~ ^([0-9.]+)T$ ]] && s="${BASH_REMATCH[1]}TB"
        [[ "$s" =~ ^([0-9.]+)G$ ]] && s="${BASH_REMATCH[1]}GB"
        [[ "$s" =~ ^([0-9.]+)M$ ]] && s="${BASH_REMATCH[1]}MB"
    fi

    if [[ "$s" =~ ^([0-9.]+)(TB|GB|MB)$ ]]; then
        n="${BASH_REMATCH[1]}"; unit="${BASH_REMATCH[2]}"
        if [[ "$mode" == "bin" ]]; then
            case "$unit" in
                TB) mult=1099.511627776 ;;
                GB) mult=1.073741824 ;;
                MB) mult=0.001048576 ;;
            esac
        else
            case "$unit" in
                TB) mult=1000 ;;
                GB) mult=1 ;;
                MB) mult=0.001 ;;
            esac
        fi
        awk -v v="$n" -v m="$mult" 'BEGIN { printf "%d", v * m + 0.5 }'
        return 0
    fi

    if [[ "$s" =~ ^([0-9]+)bytes$ ]]; then bytes_to_gb_vendor "${BASH_REMATCH[1]}"; return 0; fi
    if [[ "$s" =~ ^([0-9]+)MiB$ ]]; then
        if [[ "$mode" == "bin" ]]; then
            awk -v v="${BASH_REMATCH[1]}" 'BEGIN { printf "%d", v * 0.001048576 + 0.5 }'
        else
            awk -v v="${BASH_REMATCH[1]}" 'BEGIN { printf "%d", v / 1000 + 0.5 }'
        fi
        return 0
    fi
    if [[ "$s" =~ ^[0-9]+$ ]]; then printf '%s' "$s"; return 0; fi
    printf '%s' "$s"
}

# smartctl 口径的容量文本（User Capacity / lsblk 的十进制写法）
convert_size_to_gb() { _size_to_gb "$1" dec; }

# storcli / lsblk 口径的容量文本（例如 "1.090 TB"、"465.8G"）
convert_gib_to_gb() { _size_to_gb "$1" bin; }

# 从 smartctl -a 文本里取 User Capacity 并换算成 GB
get_user_capacity_gb() {
    local si="$1" uc
    [[ -z "$si" ]] && return 0
    uc=$(_field_val "$si" "User Capacity:")
    [[ -z "$uc" ]] && return 0
    convert_size_to_gb "$uc"
}

# 标称容量对齐：把 457 / 601 / 6001 这类实测值贴回标称档位
# （容差 4%，取最接近的候选；用于抵消 GiB/GB 与厂商标称的差异）
#
# ---------------------------------------------------------------------------
# F-9（v62 定稿）：候选表收敛为【企业级】盘型 + 容差由 5% 收紧到 4%
# ---------------------------------------------------------------------------
# ★ 容差为什么是 4% 而不是 5%（这是本次真正修掉的缺陷）★
#
# 物理事实（用户指出）：厂商标称 ≥ 系统显示的实际容量，且两者差别很小。
#   · 十进制口径：实际 ≈ 标称（略高 0.02%，厂商不会少给）
#   · 二进制显示：显示值明显小于标称（这正是"480GB 盘只显示 447GB"的由来）
#   所以"标称 240 而实际 250"是不可能出现的——标称只会偏大，不会偏小。
#
# 这条约束的直接推论：**贴档不该向下贴**。而 5% 容差太宽，恰好会向下贴：
#     250 → 240   （|250-240|/240 = 4.17%，落在 5% 内）
#     500 → 480   （4.17%）
#   把一块 250GB 盘标成 240，正是"标称比实际小"这种不可能的情况。
#   收紧到 4% 后 250/500/256/512 全部原样保留，不再被下贴。
#
# 那为什么不能更紧？因为 lsblk 在 TB 量级只给 1 位小数，量化误差最大约 ±3.4%：
#   最紧的真实用例是 1.6TB 盘 —— lsblk 显示 "1.5T"，×1099.511627776 = 1649，
#   与标称 1600 差 3.06%。所以容差必须 > 3.06%。
#   实测区间：
#     3.0% → 1.6TB 贴不上（1649 原样保留）  ✗
#     3.5% → 可贴上，余量仅 0.44pp
#     4.0% → 可贴上，余量 0.94pp，且 250/500 不再下贴  ← 取此值
#     5.0% → 可贴上，但 250/500 被错误下贴      ✗
#   实测 4% 下：35 种企业盘 × 2 种口径 = 70 个组合，**0 个误判**。
#
# 各档位的最大贴合距离（企业盘实测，越大越危险）：
#   1.6TB 3.06% | 1.92TB 2.66% | 1.5TB Optane 2.60% | 4TB 1.05% | 2TB 1.05%
#
# ---------------------------------------------------------------------------
# 候选表的收敛过程
# ---------------------------------------------------------------------------
#   · 删除消费级档：250 500（三星 870EVO/860EVO 系）、256 512（PM871/970EVO 系）
#     以及上古 30 60 GB。（收紧容差后，这些盘的值会原样保留而非被下贴。）
#   · 删除从未命中的冗余档：9000 15000 21000。
#   · 补上 26000 28000：◆ 真实误判修复 ◆ 26TB 盘实测 26005/26058，
#     原表无 26000 档 → 被 25600 抢走（偏 1.5%），26TB 会显示成 25600。
#   · 补上 375 750 1500（Optane DC P4800X）。1500 必须存在：
#     实测 1539（2.60%），否则 1.5TB 会被 1600 抢走。
#   · 保留 1024/2048/4096/8192/16384/32768（TiB 整档）。
#
# 关于"按口径分表"（dec 表 / bin 表）：审计后【确认不需要】，原因是
# _size_to_gb 已经把两种口径都折算成同一个十进制 GB 尺度——
#   lsblk 的 GiB 值经 ×1.073741824 后，本来就落在对应的十进制档附近，
#   例如 447.1G→480、16.4T→18032(→18000)、3.6T→3958(→4000)。
# 两条路殊途同归，分表反而要多维护一份数据、且会把 512 这类档位挤掉。
#
# ★★ 改动本表或容差前【必须先跑 --test】。★★
#    审计期间我曾凭"模拟算一遍"就断定 18TB 会被 16384 抢走，并据此想改表；
#    真机+完整管线复算证明那是【审计脚本自身的缺陷】——它把 16764(GiB) 直接
#    喂进了本函数，跳过了单位换算，而真实输入是 18032。
#    也就是说：只有连 _size_to_gb 一起跑的端到端断言才算数。
# ---------------------------------------------------------------------------
readonly NOMINAL_TOL="0.04"

_round_to_nominal() {
    local gb="$1"
    [[ -z "$gb" || ! "$gb" =~ ^[0-9]+$ ]] && { printf '%s' "$gb"; return 0; }
    # 120×2^n（主流企业 SATA/SAS SSD）| 100×2^n（Intel S37xx/S36xx 系）
    # Optane DC | 企业 HDD 十进制 TB 档 | TiB 整档
    local candidates="120 240 480 960 1920 3840 7680 15360 30720 61440 122880 \
                      100 200 400 800 1600 3200 6400 12800 25600 51200 \
                      375 750 1500 \
                      1000 2000 3000 4000 6000 8000 10000 12000 14000 16000 \
                      18000 20000 22000 24000 26000 28000 \
                      1024 2048 4096 8192 16384 32768"
    # 容差 4%：见文件头 F-9 的推导——5% 过宽会把 250/500 下贴到 240/480。
    awk -v TOL="$NOMINAL_TOL" -v orig="$gb" -v cands="$candidates" 'BEGIN {
        best = orig; best_diff = 999999
        n = split(cands, a, " ")
        for (i = 1; i <= n; i++) {
            c = a[i] + 0
            if (c <= 0) continue
            d = orig - c; if (d < 0) d = -d
            pct = d / c
            if (pct <= TOL && d < best_diff) { best = c; best_diff = d }
        }
        print best
    }'
}

# ============================================================================
# §7 SMART / NVMe 缓存层（P1-1）
#   约定：
#     · *_prefetch 必须【直接调用】（在父 shell 里写缓存）
#     · *_text 可以在 $( ) 里调用；未命中缓存时现场探测但不回写
#   mock 命令 key 与原版一致：
#     smartctl.a.<devkey> / smartctl.i.<devkey>
#     smartctl.a.d.<sat|ata|scsi|nvme>.<devkey>
#     smartctl.a.megaraid.<did>.<channeldevkey>
#     nvme.smart-log.<devkey> / nvme.id-ctrl.<devkey>
# ============================================================================

declare -A SMART_A=() SMART_I=() SMART_DT=() SMART_MR=()
declare -A NVME_SMART=() NVME_ID=()
PHYS_SMART=""                          # phys_smart_pick 的输出：SMART 文本
PHYS_SMART_DEV=""                      # phys_smart_pick 的输出：文本来自哪块设备

# RAID 直通缓存键
_smart_mr_key() { printf '%s|%s' "$1" "$2"; }

# 判断 smartctl 输出是否可用（排除错误页/无法识别设备）
_smartctl_ok() {
    local s="$1"
    [[ -z "$s" ]] && return 1
    # 用 here-string：避免 printf 在 grep -q 提前退出时拿到 SIGPIPE
    grep -qE "Unable to detect device type|Unknown USB bridge|No such device|Permission denied" <<< "$s" && return 1
    grep -qiE "Device Model|Serial Number|Model Number|^Vendor:|^Product:|Logical Unit id" <<< "$s" && return 0
    return 1
}

# 只负责取文本（在子 shell 中对安全，无副作用）
_smart_probe() {
    local dev="$1" mode="${2:-a}" dt="${3:-}"
    local flag dk
    if [[ "$mode" == "i" ]]; then flag="-i"; else flag="-a"; fi
    dk=$(_dev_key "$dev")
    if [[ -n "$dt" ]]; then
        run_cmd "smartctl.${mode}.d.${dt}.${dk}" -- $SUDO smartctl "$flag" -d "$dt" "$dev"
    else
        run_cmd "smartctl.${mode}.${dk}" -- $SUDO smartctl "$flag" "$dev"
    fi
}

# 写缓存（区分 -a / -i）
_smart_store() {
    local dev="$1" mode="$2" text="$3"
    if [[ "$mode" == "i" ]]; then SMART_I["$dev"]="$text"; else SMART_A["$dev"]="$text"; fi
}

# 预取 smartctl 文本（直接调用）。已记住可用的 -d 类型时直接用，失败才逐一尝试
# sat/ata/scsi/nvme（最多 5 次，且只发生在首次遇到某类设备时）。
smart_prefetch() {
    local dev="$1" mode="${2:-a}"
    local dt out
    [[ -z "$dev" || "$dev" == "N/A" || "$dev" == "Unknown" ]] && return 0
    if [[ "$mode" == "i" ]]; then
        [[ -n "${SMART_I[$dev]+x}" ]] && return 0
    else
        [[ -n "${SMART_A[$dev]+x}" ]] && return 0
    fi
    if [[ "$MOCK_MODE" != "true" && ! -b "$dev" ]]; then
        _smart_store "$dev" "$mode" ""
        return 0
    fi

    dt="${SMART_DT[$dev]:-}"
    if [[ -n "$dt" ]]; then
        out=$(_smart_probe "$dev" "$mode" "$dt")
        if _smartctl_ok "$out"; then _smart_store "$dev" "$mode" "$out"; return 0; fi
        unset "SMART_DT[$dev]"
    fi

    out=$(_smart_probe "$dev" "$mode" "")
    if _smartctl_ok "$out"; then
        _smart_store "$dev" "$mode" "$out"
        SMART_DT["$dev"]=""
        return 0
    fi

    for dt in sat ata scsi nvme; do
        out=$(_smart_probe "$dev" "$mode" "$dt")
        if _smartctl_ok "$out"; then
            SMART_DT["$dev"]="$dt"
            _smart_store "$dev" "$mode" "$out"
            return 0
        fi
    done
    _smart_store "$dev" "$mode" ""
    return 0
}

# 只读访问 smartctl 文本：缓存命中直接用，否则现场探测
smart_text() {
    local dev="$1" mode="${2:-a}"
    [[ -z "$dev" || "$dev" == "N/A" || "$dev" == "Unknown" ]] && return 0
    if [[ "$mode" == "i" ]]; then
        [[ -n "${SMART_I[$dev]+x}" ]] && { printf '%s' "${SMART_I[$dev]}"; return 0; }
    else
        [[ -n "${SMART_A[$dev]+x}" ]] && { printf '%s' "${SMART_A[$dev]}"; return 0; }
    fi
    _smart_probe "$dev" "$mode" "${SMART_DT[$dev]:-}"
}

# RAID 直通 SMART（--device=megaraid,<DID>）：预取 / 只读
smart_megaraid_prefetch() {
    local channel="$1" did="$2" k out
    [[ -z "$channel" || -z "$did" || "$did" == "0" ]] && return 0
    k=$(_smart_mr_key "$channel" "$did")
    [[ -n "${SMART_MR[$k]+x}" ]] && return 0
    if [[ "$MOCK_MODE" != "true" && ! -b "$channel" ]]; then
        SMART_MR["$k"]=""
        return 0
    fi
    out=$(run_cmd "smartctl.a.megaraid.${did}.$(_dev_key "$channel")" -- $SUDO smartctl -a --device=megaraid,"$did" "$channel")
    _smartctl_ok "$out" || out=""
    SMART_MR["$k"]="$out"
    return 0
}

# RAID 直通 SMART：只读访问（缓存未命中时现场探测）
smart_megaraid_text() {
    local channel="$1" did="$2" k
    [[ -z "$channel" || -z "$did" || "$did" == "0" ]] && return 0
    k=$(_smart_mr_key "$channel" "$did")
    [[ -n "${SMART_MR[$k]+x}" ]] && { printf '%s' "${SMART_MR[$k]}"; return 0; }
    run_cmd "smartctl.a.megaraid.${did}.$(_dev_key "$channel")" -- $SUDO smartctl -a --device=megaraid,"$did" "$channel"
}

# nvme smart-log：预取 / 只读
nvme_smart_prefetch() {
    local dev="$1" out
    [[ -z "$dev" || "$dev" == "N/A" ]] && return 0
    [[ -n "${NVME_SMART[$dev]+x}" ]] && return 0
    if [[ "$MOCK_MODE" != "true" && ! -b "$dev" ]]; then
        NVME_SMART["$dev"]=""
        return 0
    fi
    out=$(run_cmd "nvme.smart-log.$(_dev_key "$dev")" -- $SUDO nvme smart-log "$dev")
    NVME_SMART["$dev"]="$out"
    return 0
}

# nvme smart-log：只读访问（缓存未命中时现场探测）
nvme_smart_text() {
    local dev="$1"
    [[ -z "$dev" || "$dev" == "N/A" ]] && return 0
    [[ -n "${NVME_SMART[$dev]+x}" ]] && { printf '%s' "${NVME_SMART[$dev]}"; return 0; }
    run_cmd "nvme.smart-log.$(_dev_key "$dev")" -- $SUDO nvme smart-log "$dev"
}

# nvme id-ctrl：预取 / 只读
nvme_id_prefetch() {
    local dev="$1" out
    [[ -z "$dev" || "$dev" == "N/A" ]] && return 0
    [[ -n "${NVME_ID[$dev]+x}" ]] && return 0
    if [[ "$MOCK_MODE" != "true" && ! -b "$dev" ]]; then
        NVME_ID["$dev"]=""
        return 0
    fi
    out=$(run_cmd "nvme.id-ctrl.$(_dev_key "$dev")" -- $SUDO nvme id-ctrl "$dev")
    NVME_ID["$dev"]="$out"
    return 0
}

# nvme id-ctrl：只读访问（缓存未命中时现场探测）
nvme_id_text() {
    local dev="$1"
    [[ -z "$dev" || "$dev" == "N/A" ]] && return 0
    [[ -n "${NVME_ID[$dev]+x}" ]] && { printf '%s' "${NVME_ID[$dev]}"; return 0; }
    run_cmd "nvme.id-ctrl.$(_dev_key "$dev")" -- $SUDO nvme id-ctrl "$dev"
}

# ============================================================================
# §8 SMART 字段解析
# ============================================================================

# "Serial Number: ..." -> 序列号
# F-3：v61 这里做的是 `tr -d ' \n'`，会把序列号【内部】的空格也删掉
#      （"PHYF 1296 0001" → "PHYF12960001"），而 by-id 兜底链
#      （_get_disk_serial 的 awk -F'_' 分支）保留原样 —— 两条链拿到的
#      序列号写法不一致。序列号是 emit_row 的去重键，同一块盘于是
#      可能被记成两条。这里只去掉 CR 与首尾空白，保留内部原貌。
smart_serial_of() {
    local s="$1"
    [[ -z "$s" ]] && return 0
    s=$(_field_val "$s" "^Serial [Nn]umber:")
    s="${s//$'\r'/}"
    _trim "$s"
}

# "Power On Hours": 优先 nvme smart-log，其次 smartctl -a 的 ATA/SCSI 字段
# ★ 0 是合法值（新盘），不再当成缺失
get_power_hours_text() {
    local si="$1" sl="$2" ph=""
    [[ -n "$sl" ]] && ph=$(_field_val "$sl" '^[[:space:]]*power_on_hours')
    if [[ -z "$ph" && -n "$si" ]]; then
        ph=$(printf '%s\n' "$si" | grep -i "Power_On_Hours" | head -1 | awk '{print $10}')
        [[ -z "$ph" ]] && ph=$(_field_val "$si" "Power On Hours")
        [[ -z "$ph" ]] && ph=$(printf '%s\n' "$si" | grep -i "Power_On_Time" | head -1 | awk '{print $10}')
    fi
    ph=$(_dec "$ph")
    [[ -z "$ph" ]] && { printf 'NA'; return 0; }
    printf '%s' "$ph"
}

# "Percentage Used: N" -> 剩余寿命 "NN%"（取不到返回非 0 状态，交给调用方继续兜底）
_pct_to_life() {
    local v
    [[ -z "$1" ]] && return 1
    v=$(_field_val "$1" "$2")
    v=$(_dec "$v")
    [[ -z "$v" ]] && return 1
    local r=$((100 - v))
    (( r < 0 )) && r=0
    printf '%s%%' "$r"
}

# 寿命百分比：HDD 恒为 NA；NVMe 先看 percentage_used，再看 Percentage Used；
# 其余走 ATA 属性（Media_Wearout_Indicator / Wear_Leveling_Count / SSD_Life_Left）
get_life_percent_text() {
    local si="$1" sl="$2" dt="$3" v
    [[ "$dt" == "HDD" ]] && { printf 'NA'; return 0; }

    v=$(_pct_to_life "$sl" '^[[:space:]]*percentage_used') && { printf '%s' "$v"; return 0; }
    v=$(_pct_to_life "$si" "Percentage Used")             && { printf '%s' "$v"; return 0; }
    [[ -z "$si" ]] && { printf 'NA'; return 0; }

    v=$(printf '%s\n' "$si" | grep -i "Media_Wearout_Indicator" | head -1 | awk '{print $4}')
    v=$(_dec "$v")
    if [[ -n "$v" && "$v" -le 100 ]]; then printf '%s%%' "$v"; return 0; fi

    v=$(printf '%s\n' "$si" | grep -i "Wear_Leveling_Count" | head -1 | awk '{print $10}')
    v=$(_dec "$v")
    if [[ -n "$v" ]]; then
        if (( v <= 100 ));  then printf '%s%%' "$((100 - v))";      return 0; fi
        if (( v <= 1000 )); then printf '%s%%' "$((100 - v / 10))"; return 0; fi
    fi

    v=$(printf '%s\n' "$si" | grep -i "SSD_Life_Left" | head -1 | awk '{print $10}')
    v=$(_dec "$v")
    [[ -n "$v" ]] && { printf '%s%%' "$v"; return 0; }

    printf 'NA'
}

# 取某条 ATA 属性的 RAW_VALUE（第 10 列）
get_smart_attr_raw() {
    _field_val "$1" "^[[:space:]]*$2[[:space:]]+" | awk '{print $10}'
}

# ---- 错误计数：全部登记到 ERR_PARTS，最后用 ';' 拼成一列 ----
declare -a ERR_PARTS=()

# 登记一条（同名只登记一次）
_err_add() {
    local k="$1" val="$2" p
    for p in "${ERR_PARTS[@]}"; do [[ "$p" == "${k}:"* ]] && return 0; done
    ERR_PARTS+=("${k}:${val}")
}

# 登记一条数值型计数：只接受纯数字（允许空格/千分位逗号）且 >0，其余忽略。
# 用 10# 解析，避免 "099" 被 bash 当成八进制。
_err_add_num() {
    local name="$1" raw="$2" val
    raw="${raw//[ ,]/}"
    [[ -n "$raw" && "$raw" =~ ^[0-9]+$ ]] || return 0
    val=$((10#$raw))
    [[ "$val" -gt 0 ]] && _err_add "$name" "$val"
    return 0
}

# 汇总一块盘的错误计数：
#   <smart -a 文本> <disk_type> <SMART 文本来自哪块设备> [mraid key]
# 返回 "0" 或 "Name:value;Name:value"。调用方必须传【真正取到 SMART 的那块设备】，
# 否则 NVMe smart-log 会查错对象（v59 固定传 megaraid 通道设备）。
#
# ★ v62：ATA 与 SCSI/SAS 是两套完全不同的 smartctl 输出格式，必须分开处理。
#   · 不能靠 disk_type 区分：get_disk_type 只看 NVMe/SSD，SATA 盘和 SAS 盘
#     都会被判成 "HDD"。只能看输出内容：
#       - SCSI/SAS：有 "SMART Health Status:"，没有 ATA 属性表
#       - ATA     ：有属性表，健康行是 "SMART overall-health ... result:"
#     两种特征互斥，用任一即可判别。
#   · 【修正前 SAS 盘的错误计数恒为 0】：SAS 走的是 ATA 分支，而 SCSI 文本里
#     根本没有 "ID# ATTRIBUTE_NAME" 属性表，所有 get_smart_attr_raw 都取空，
#     于是 G-list 有 12 项的坏盘被报成 errors=0，看着像全新盘。
get_errors_count() {
    local si="$1" disk_type="$2" device="$3" mraid_key="${4:-}"
    local sl fl attr_id attr_name raw_val is_scsi=false sas_health=""
    ERR_PARTS=()

    # MegaRAID 控制器侧的计数
    if [[ -n "$mraid_key" ]]; then
        _err_add_num "Predictive_Failure_Count" "${MRAID_PFC[$mraid_key]:-0}"
        _err_add_num "Media_Error_Count"        "${MRAID_MEC[$mraid_key]:-0}"
        _err_add_num "Other_Error_Count"        "${MRAID_OEC[$mraid_key]:-0}"
        [[ "${MRAID_SMART_ALERT[$mraid_key]:-No}" == "Yes" ]] && _err_add "SMART_Alert_Flagged" "1"
    fi

    if [[ -n "$si" ]]; then
        printf '%s\n' "$si" | grep -qE "^[[:space:]]*SMART Health Status" && is_scsi=true

        if [[ "$is_scsi" == "true" ]]; then
            # ================= SCSI / SAS =================
            # 模式一律用 "^[[:space:]]*" 开头：smartctl 各版本/厂商对这些行的
            # 缩进不完全一致（有的顶格、有的带前导空格），锚死 "^\S" 会漏匹配。
            # _field_val 内部按"第一个冒号"截断，所以前导空格不影响取值。

            # 增长坏道表（G-list）：SCSI 版的"重分配扇区"，非 0 即需关注
            _err_add_num "Grown_Defect_List" \
                "$(_field_val "$si" "^[[:space:]]*Elements in grown defect list")"

            # 非介质错误：SCSI 版的 Command_Timeout，多因链路/供电/机械老化。
            # 注意：这是"累计"值，一块跑了 5 年的盘有几次属正常，要配合趋势看。
            _err_add_num "Non_Medium_Errors" \
                "$(_field_val "$si" "^[[:space:]]*Non-medium error count")"

            # Error counter log 里 read/write/verify 三行的【最后一列】是
            # "Total uncorrected errors"，求和登记（= SCSI 版的不可纠正错误）
            _err_add_num "Uncorrected_Errors" \
                "$(printf '%s\n' "$si" | awk '/^[[:space:]]*(read|write|verify):/ { s += $NF } END { print s+0 }')"

            # 健康状态非 "OK" 即登记（FAILED! / WARNING / Hardware impending failure…）
            sas_health=$(_field_val "$si" "^[[:space:]]*SMART Health Status")
            if [[ -n "$sas_health" && "$sas_health" != "OK" ]]; then
                _err_add "SMART_Health_Status" "${sas_health//,/}"
            fi
        else
            # ================= ATA =================
            _err_add_num "ATA_Error_Count"               "$(_field_val "$si" "ATA Error Count")"
            _err_add_num "Error_Information_Log_Entries" "$(_field_val "$si" "Error Information Log Entries")"
            _err_add_num "Reallocated_Sector_Ct"  "$(get_smart_attr_raw "$si" 5)"
            _err_add_num "Reported_Uncorrect"     "$(get_smart_attr_raw "$si" 187)"
            # 188 Command_Timeout：命令下发后盘未在超时窗口内响应，属于【独立于
            # 介质】的失效模式（供电不足 / 线缆接触不良 / 机械老化）。一块盘完全
            # 可能 197=198=0 但 188 很大，所以必须单独看。
            # ⚠ RAW_VALUE 的语义随厂商而异：Seagate 是 3×16 位打包值
            #   （如 4295032836 = 0x1_0001_0004，即 1+1+4 次），WD/Toshiba 多为
            #   普通计数。无法可靠区分厂商，故按原始值登记，由人工判断量级。
            _err_add_num "Command_Timeout"        "$(get_smart_attr_raw "$si" 188)"
            _err_add_num "Current_Pending_Sector" "$(get_smart_attr_raw "$si" 197)"
            _err_add_num "Offline_Uncorrectable"  "$(get_smart_attr_raw "$si" 198)"
            _err_add_num "UDMA_CRC_Error_Count"   "$(get_smart_attr_raw "$si" 199)"
            # 10 Spin_Retry_Count：起转重试，机械故障前兆
            _err_add_num "Spin_Retry_Count"       "$(get_smart_attr_raw "$si" 10)"

            # WHEN_FAILED = FAILING_NOW 的属性原样登记
            while IFS= read -r fl; do
                [[ -z "$fl" ]] && continue
                attr_id=$(awk '{print $1}' <<< "$fl")
                attr_name=$(awk '{print $2}' <<< "$fl")
                raw_val=$(awk '{print $10}' <<< "$fl")
                [[ -z "$raw_val" ]] && raw_val=$(awk '{print $NF}' <<< "$fl")
                [[ -z "$attr_id" || -z "$attr_name" ]] && continue
                attr_name="${attr_name//,/}"; raw_val="${raw_val//,/}"
                _err_add "FAILING_NOW_${attr_name}" "$raw_val"
            done < <(printf '%s\n' "$si" | awk '/FAILING_NOW/ && /^[[:space:]]*[0-9]+[[:space:]]/')

            grep -qiE "SMART overall-health self-assessment test result:[[:space:]]*FAILED" <<< "$si" \
                && _err_add "SMART_FAILED" "1"
        fi
    fi

    # NVMe 侧（只读缓存，不会重复探测）
    if [[ "$disk_type" == "NVMe" && -n "$device" ]]; then
        sl=$(nvme_smart_text "$device")
        _err_add_num "Media_Errors"        "$(_field_val "$sl" "media_errors")"
        _err_add_num "Num_Err_Log_Entries" "$(_field_val "$sl" "num_err_log_entries")"
    fi

    if [[ ${#ERR_PARTS[@]} -eq 0 ]]; then
        printf '0'
    else
        local IFS=';'
        printf '%s' "${ERR_PARTS[*]}"
    fi
}

# 一次算出电源小时 / 寿命 / 错误计数，结果放 HEALTH_*（三个分支共用）
HEALTH_PH="NA"
HEALTH_LIFE="NA"
HEALTH_ERRORS="0"

# health_fields <smart -a 文本> <nvme smart-log 文本> <disk_type> <设备> [mraid key]
health_fields() {
    local si="$1" sl="$2" dt="$3" dev="$4" mk="${5:-}"
    HEALTH_PH=$(get_power_hours_text "$si" "$sl")
    HEALTH_LIFE=$(get_life_percent_text "$si" "$sl" "$dt")
    HEALTH_ERRORS=$(get_errors_count "$si" "$dt" "$dev" "$mk")
    return 0
}

# ============================================================================
# §9 厂商 / 型号映射
# ============================================================================

# PCI vendor id -> 厂商名（型号里看不出厂商时兜底）
_pci_vid_to_vendor() {
    local vid="$1"
    [[ -z "$vid" || "$vid" == "N/A" || "$vid" == "Unknown" ]] && return 0
    vid="${vid,,}"; vid="${vid#0x}"
    case "$vid" in
        8086) echo "Intel" ;; 1c5c) echo "SK Hynix" ;; 1b96) echo "Solidigm" ;;
        144d) echo "Samsung" ;; 1344) echo "Micron" ;; 1e0f|1179) echo "KIOXIA" ;;
        1bb1) echo "Seagate" ;; 15b7) echo "SanDisk" ;; 1b4b) echo "Marvell" ;;
        1000|1001) echo "LSI" ;; 10de) echo "NVIDIA" ;; 14e4) echo "Broadcom" ;;
        1d0f) echo "Amazon" ;; 1dbd) echo "Netlist" ;; 1c58) echo "HGST" ;;
        1bd4) echo "INSPUR" ;; *) : ;;
    esac
}

# 型号字符串 -> 厂商名：先按关键词，再按 PCI vendor id，最后按型号前缀
get_vendor() {
    local p="$1" pci_vid="${2:-}" u from_pci
    u="${p^^}"
    # 关键词（型号里通常直接带厂商名）
    if   [[ "$u" =~ SOLIDIGM ]];                     then echo "SOLIDIGM";         return 0; fi
    if   [[ "$u" =~ INTEL ]];                        then echo "Intel";           return 0; fi
    if   [[ "$u" =~ SAMSUNG ]];                      then echo "Samsung";         return 0; fi
    if   [[ "$u" =~ MICRON ]];                       then echo "Micron";          return 0; fi
    if   [[ "$u" =~ "SK HYNIX" || "$u" =~ HYNIX ]];  then echo "SK Hynix";        return 0; fi
    if   [[ "$u" =~ SEAGATE ]];                      then echo "Seagate";         return 0; fi
    if   [[ "$u" =~ TOSHIBA || "$u" =~ KIOXIA ]];    then echo "KIOXIA";          return 0; fi
    if   [[ "$u" =~ HGST || "$u" =~ HITACHI ]];      then echo "HGST";            return 0; fi
    if   [[ "$u" =~ "WESTERN DIGITAL" ]];            then echo "Western Digital"; return 0; fi
    if   [[ "$u" =~ SANDISK ]];                      then echo "SanDisk";         return 0; fi
    if   [[ "$u" =~ ^LSI$ || "$u" =~ "LOGICAL VOLUME" ]]; then echo "LSI";        return 0; fi
    if   [[ "$u" =~ INSPUR ]];                       then echo "INSPUR";          return 0; fi

    from_pci=$(_pci_vid_to_vendor "$pci_vid")
    [[ -n "$from_pci" ]] && { echo "$from_pci"; return 0; }

    # 型号前缀兜底（厂商关键词被去掉时仍能识别）
    if   [[ "$u" =~ ^MZ ]];                  then echo "Samsung";         return 0; fi
    if   [[ "$u" =~ ^MTFD ]];                then echo "Micron";          return 0; fi
    if   [[ "$u" =~ ^HMA || "$u" =~ ^HMC ]]; then echo "SK Hynix";        return 0; fi
    if   [[ "$u" =~ ^SSDPF|^SSDPE|^SSDSC ]]; then echo "Intel";           return 0; fi
    if   [[ "$u" =~ ^ST[0-9] ]];             then echo "Seagate";         return 0; fi
    if   [[ "$u" =~ ^WD ]];                  then echo "Western Digital"; return 0; fi
    if   [[ "$u" =~ ^MG[0-9] ]];             then echo "KIOXIA";          return 0; fi
    if   [[ "$u" =~ ^NS[0-9] ]];             then echo "INSPUR";          return 0; fi
    echo "UNKNOWN"
}

# 型号前缀 -> 产品名（数据表形式，便于维护）
declare -A MODEL_MAP=(
    ["SSDPF2KX"]="P5510" ["SSDPF2KE"]="P5620" ["SSDPF2NV"]="P5316"
    ["SSDPE2KX"]="P4510" ["SSDPE2KE"]="P4610" ["SSDPE2NV"]="P4511"
    ["SSDPE2ME"]="P3600" ["SSDPE2MX"]="P3520" ["SSDPE21K"]="P4800X"
    ["SSDPF21Q"]="P5800X" ["SSDSC2KB"]="S4510" ["SSDSC2KG"]="S4610"
    ["SSDSCKKB"]="S4510 (M.2)" ["SSDSC2BA"]="S3700" ["SSDSC2BB"]="S3710"
    ["SSDSC2BW"]="S3500" ["SSDSC2BX"]="S3610"
    ["MZ7LM"]="PM863" ["MZ7KM"]="SM863" ["MZIL"]="PM1733" ["MZWL"]="PM1735"
    ["MZQL"]="PM9A3" ["MZVL"]="PM981"
    ["MTFDDAK"]="5300" ["MTFDHBA"]="7300" ["MTFDKBA"]="7400"
)

# 型号 -> 产品名（匹配不到原样返回）。顺序敏感：先处理更具体的前缀规则
get_model() {
    local p="$1" k
    if   [[ "$p" =~ SSDPF2KX[0-9]+XZ || "$p" =~ SSDPF2KX[0-9]+HZ ]]; then echo "P5530"; return 0
    elif [[ "$p" =~ SSDPF2KX[0-9]+TZ ]]; then echo "P5510"; return 0
    elif [[ "$p" =~ MTFDDAK.*TGA ]]; then echo "5400"; return 0
    fi
    for k in SSDPF2NV SSDPF2KE SSDPF2KX SSDPE2KX SSDPE2KE SSDPE2NV SSDPE2ME \
             SSDPE2MX SSDPE21K SSDPF21Q SSDSC2KB SSDSC2KG SSDSCKKB SSDSC2BA \
             SSDSC2BB SSDSC2BW SSDSC2BX MZ7LM MZ7KM MZIL MZWL MZQL MZVL \
             MTFDDAK MTFDHBA MTFDKBA; do
        if [[ "$p" == "$k"* ]]; then
            echo "${MODEL_MAP[$k]}"; return 0
        fi
    done
    echo "$p"
}

# 去掉型号里的厂商前缀（"INTEL SSDSC2KB480G8" -> "SSDSC2KB480G8"）
clean_product() {
    local c="$1" brand
    for brand in Samsung INTEL Intel Micron Seagate WDC WD Toshiba HGST KIOXIA HPE DELL Dell Lenovo SOLIDIGM LSI INSPUR; do
        c=$(printf '%s' "$c" | sed -E "s/^[[:space:]]*${brand}[[:space:]-]*//I")
    done
    _trim "$c"
}

# 型号 -> 友好名：先按原始型号匹配；带厂商前缀匹配不上时，再用去前缀的 product 试一次，
# 避免永远拿不到 S4510 / PM863 / P5510 这类名字
resolve_model() {
    local raw="$1" product="$2" m
    m=$(get_model "$raw")
    if [[ "$m" == "$raw" && -n "$product" && "$product" != "$raw" ]]; then
        m=$(get_model "$product")
    fi
    [[ -z "$m" ]] && m="$raw"
    printf '%s' "$m"
}

# 盘型判断：NVMe > SSD(依据 Rotation Rate/型号) > HDD
get_disk_type() {
    local product="$1" rotation_rate="$2" disk_name="$3"
    if [[ "$disk_name" =~ ^nvme[0-9]+ ]]; then echo "NVMe"; return 0; fi
    if [[ "$product" =~ NVMe || "$product" =~ nvme ]]; then echo "NVMe"; return 0; fi
    if [[ "$rotation_rate" == "Solid State Device" || "$rotation_rate" == "0" || "$rotation_rate" == "SSD" ]]; then
        echo "SSD"; return 0
    fi
    if [[ "$product" =~ SSD || "$product" =~ "Solid State" || "$product" =~ SSDSC || "$product" =~ SSDPE || "$product" =~ SSDPF ]]; then
        echo "SSD"; return 0
    fi
    if [[ "$product" =~ MZ || "$product" =~ PM[0-9] || "$product" =~ MTFD ]]; then echo "SSD"; return 0; fi
    echo "HDD"
}

# ============================================================================
# §10 磁盘路径映射
# ============================================================================

declare -A PATH_BY_SD=()              # /dev/sdX -> by-path 链接名
declare -A BDF_BY_SD=()               # /dev/sdX -> 控制器/上游 BDF
declare -A OS_DEV_BY_WWN=()           # WWN  -> /dev/sdX
PATHS_LOADED=false

# 扫描 /dev/disk/by-path 与 by-id，建立 sdX -> by-path / BDF / WWN 映射
load_disk_paths() {
    [[ "$PATHS_LOADED" == "true" ]] && return 0
    PATHS_LOADED=true
    local link name target wwn dev b

    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        name=$(basename "$link")
        [[ "$name" =~ -part[0-9]+$ ]] && continue
        target=$(_fs_readlink "$link")
        [[ "$target" =~ ^/dev/(sd[a-z]+|nvme[0-9]+n[0-9]+)$ ]] || continue
        [[ -n "${PATH_BY_SD[$target]:-}" ]] && continue      # 同一设备多条 by-path 时取第一条
        PATH_BY_SD["$target"]="$name"
        b=$(_extract_bdf "$name")
        [[ -n "$b" ]] && BDF_BY_SD["$target"]="$b"
    done < <(_fs_glob "/dev/disk/by-path/pci-*")

    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        wwn=$(basename "$link" | sed 's/^wwn-//' | sed 's/^0[xX]//' | tr 'a-f' 'A-F')
        dev=$(_fs_readlink "$link")
        [[ "$dev" =~ ^/dev/(sd[a-z]+|nvme[0-9]+n[0-9]+)$ ]] && OS_DEV_BY_WWN["$wwn"]="/dev/${BASH_REMATCH[1]}"
    done < <(_fs_glob "/dev/disk/by-id/wwn-*")

    log_debug "磁盘映射: by-path=${#PATH_BY_SD[@]}, by-path-bdf=${#BDF_BY_SD[@]}, wwn=${#OS_DEV_BY_WWN[@]}"
    return 0
}

# WWID 归一化：去 naa./0x 前缀，去 . : - 分隔符，转小写
_wwid_norm() { printf '%s' "$1" | tr 'A-F' 'a-f' | sed 's/^naa\.//;s/^0x//;s/[.:-]//g'; }

# WWID 比对：exact = 归一化后完全相等；substr = 不区分大小写的子串
_wwid_hit() {
    local c="$1" w="$2" mode="$3"
    if [[ "$mode" == "exact" ]]; then
        c=$(_wwid_norm "$c")
        [[ -n "$c" && "$c" == "$w" ]]
    else
        [[ -n "$w" && "${c,,}" == *"${w,,}"* ]]
    fi
}

# 用 WWID 反查 /dev/sdX：
#   exact  用于 arcconf 的 Volume Unique Identifier（规范化后精确比较）
#   substr 用于 sas3ircu 的 Volume wwid（子串比较，可枚举 scsi-*/wwn-*）
#   先看 /sys/block/*/device/wwid，再看 by-id 链接名
_find_osdev_by_wwid() {
    local wwid="$1" mode="${2:-exact}"
    shift 2 2>/dev/null || true
    local -a globs=("$@")
    (( ${#globs[@]} )) || globs=("/dev/disk/by-id/wwn-*")

    [[ -z "$wwid" ]] && { printf ''; return 0; }
    if [[ "$mode" == "exact" ]]; then
        wwid=$(_wwid_norm "$wwid")
        [[ -z "$wwid" ]] && { printf ''; return 0; }
    fi
    log_debug "  [wwid/$mode] $wwid"

    local name b w link base t
    while IFS= read -r name; do
        [[ "$name" =~ ^sd[a-z]+$ ]] || continue
        b="/sys/block/$name"
        w=$(_fs_read "$b/device/wwid" | tr -d ' \n')
        if _wwid_hit "$w" "$wwid" "$mode"; then
            log_debug "  [wwid] ✓ /sys 命中 $b → /dev/$name"
            printf '/dev/%s' "$name"; return 0
        fi
    done < <(_fs_list_names "/sys/block")

    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        [[ "$(basename "$link")" =~ -part[0-9]+$ ]] && continue
        base=$(basename "$link" | sed 's/^wwn-//')
        if _wwid_hit "$base" "$wwid" "$mode"; then
            t=$(_fs_readlink "$link")
            [[ -n "$t" ]] && { log_debug "  [wwid] ✓ by-id 命中 $link → $t"; printf '%s' "$t"; return 0; }
        fi
    done < <(for g in "${globs[@]}"; do _fs_glob "$g"; done)

    log_debug "  [wwid] ✗ 无匹配"
    printf ''
}

# 取某个控制器 BDF 下最小的 /dev/sdX（Adaptec 与 sas3ircu 的兜底策略）
_first_sd_under_bdf() {
    local bdf="$1" link target best=""
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { printf ''; return 0; }
    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        [[ "$(basename "$link")" =~ -part[0-9]+$ ]] && continue
        target=$(_fs_readlink "$link")
        [[ "$target" =~ ^/dev/sd[a-z]+$ ]] || continue
        [[ -z "$best" || "$target" < "$best" ]] && best="$target"
    done < <(_fs_glob "/dev/disk/by-path/pci-${bdf}-scsi-*")
    [[ -n "$best" ]] && log_debug "  [fallback] $bdf 下最小 sdX: $best"
    printf '%s' "$best"
}

# ============================================================================
# §11 PCIe Slot / 链路信息
# ============================================================================

declare -A PCI_SLOT_MAP=()            # BDF -> DMI 槽位名
declare -A PCIE_SLOT_CACHE=()         # BDF -> 解析结果（父 shell 写）
declare -A LSPCI_LNK_CACHE=()         # 归一化 BDF -> lspci -vv 文本
declare -A LSPCI_SHORT_CACHE=()       # BDF -> lspci -s 单行描述
PCI_SLOT_MAP_LOADED=false

# DMI 的 Bus Address（0000:00:01 / 00:01.0 等写法）补全成 BDF
_normalize_dmi_addr() {
    local a
    a=$(printf '%s' "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    [[ "$a" =~ ^([0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2})$ ]] && a="${a}.0"
    [[ "$a" =~ ^([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]] && a="0000:$a"
    printf '%s' "$a"
}

# 解析 dmidecode -t slot，建立 BDF -> 槽位名
load_pci_slot_map() {
    [[ "$PCI_SLOT_MAP_LOADED" == "true" ]] && return 0
    PCI_SLOT_MAP_LOADED=true
    local cur="" line key
    while IFS= read -r line; do
        if [[ "$line" =~ Designation:[[:space:]]*(.+) ]]; then
            cur=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ "$line" =~ Bus[[:space:]]Address:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            key=$(_normalize_dmi_addr "${BASH_REMATCH[1]}")
            [[ -n "$key" ]] && PCI_SLOT_MAP["$key"]="$cur"
        fi
    done < <(run_cmd "dmidecode.t-slot" -- $SUDO dmidecode -t slot)
    log_debug "PCIe Slot 映射加载: ${#PCI_SLOT_MAP[@]} 条"
    return 0
}

# 解析一个 BDF 对应哪个物理槽位：
#   ① 沿 sysfs 的设备链（tac 从深到浅）找精确匹配
#   ② 退化为“同一个 bus 上有槽位就沿用”
get_pcie_slot() {
    local raw="$1" bdf realpath chain p k bus kbus result="N/A"
    [[ -z "$raw" || "$raw" == "N/A" || "$raw" == "Unknown" ]] && { printf 'N/A'; return 0; }

    bdf=$(_extract_bdf "$raw")
    [[ -z "$bdf" ]] && { printf 'N/A'; return 0; }
    bdf=$(printf '%s' "$bdf" | tr 'A-F' 'a-f')

    [[ -n "${PCIE_SLOT_CACHE[$bdf]+x}" ]] && { printf '%s' "${PCIE_SLOT_CACHE[$bdf]}"; return 0; }

    realpath=$(_fs_readlink "/sys/bus/pci/devices/$bdf")
    if [[ -z "$realpath" ]]; then
        PCIE_SLOT_CACHE["$bdf"]="N/A"
        printf 'N/A'; return 0
    fi

    chain=$(printf '%s' "$realpath" | tr '/' '\n' \
        | grep -E '^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$' | tac)

    while IFS= read -r p; do
        [[ -z "$p" ]] && continue
        if [[ -n "${PCI_SLOT_MAP[$p]+x}" ]]; then result="${PCI_SLOT_MAP[$p]}"; break; fi
    done <<< "$chain"

    if [[ "$result" == "N/A" && -n "$chain" ]]; then
        while IFS= read -r p; do
            [[ -z "$p" ]] && continue
            bus=$(printf '%s' "$p" | cut -d':' -f2); [[ -z "$bus" ]] && continue
            for k in "${!PCI_SLOT_MAP[@]}"; do
                [[ -z "$k" ]] && continue
                kbus=$(printf '%s' "$k" | cut -d':' -f2)
                if [[ -n "$kbus" && "$bus" == "$kbus" ]]; then result="${PCI_SLOT_MAP[$k]}"; break 2; fi
            done
        done <<< "$chain"
    fi

    PCIE_SLOT_CACHE["$bdf"]="$result"
    printf '%s' "$result"
}

# 预取 `lspci -s <bdf>` 单行描述（设备名过滤 / SAS 代数判定都要用）。
# 必须由父 shell 调用：命令替换是子 shell，缓存写在那里会丢。
lspci_short_prefetch() {
    local bdf="$1" info
    [[ -z "$bdf" ]] && return 0
    [[ -n "${LSPCI_SHORT_CACHE[$bdf]+x}" ]] && return 0
    info=$(run_cmd "lspci.s.$(_bdf_key "$bdf")" -- lspci -s "$bdf")
    LSPCI_SHORT_CACHE["$bdf"]="$info"
    return 0
}

# 预取 `lspci -s <bdf> -vv`（gen/cap/sta 三列共用，否则会各取一次）
lspci_lnk_prefetch() {
    local addr="$1" key info
    [[ -z "$addr" || "$addr" == "Unknown" || "$addr" == "N/A" ]] && return 0
    key=$(normalize_pci_addr "$addr")
    [[ -n "${LSPCI_LNK_CACHE[$key]+x}" ]] && return 0
    info=$(run_cmd "lspci.s.$(_bdf_key "$key").vv" -- $SUDO lspci -s "$key" -vv)
    LSPCI_LNK_CACHE["$key"]="$info"
    return 0
}

# 预取槽位解析结果（同一个 BDF 在多块盘上复用时只解析一次）
pcie_slot_prefetch() {
    local bdf="$1" v
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && return 0
    bdf=$(printf '%s' "$bdf" | tr 'A-F' 'a-f')
    [[ -n "${PCIE_SLOT_CACHE[$bdf]+x}" ]] && return 0
    v=$(get_pcie_slot "$bdf")
    PCIE_SLOT_CACHE["$bdf"]="$v"
    return 0
}

# 只读槽位缓存
pcie_slot_cached() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { printf 'N/A'; return 0; }
    bdf=$(printf '%s' "$bdf" | tr 'A-F' 'a-f')
    [[ -n "${PCIE_SLOT_CACHE[$bdf]+x}" ]] && { printf '%s' "${PCIE_SLOT_CACHE[$bdf]}"; return 0; }
    printf 'N/A'
}

# 只读 lspci -vv 文本（缓存未命中时现场探测）
_lspci_lnk_text() {
    local addr="$1" key
    [[ -z "$addr" || "$addr" == "Unknown" ]] && return 0
    key=$(normalize_pci_addr "$addr")
    [[ -n "${LSPCI_LNK_CACHE[$key]+x}" ]] && { printf '%s' "${LSPCI_LNK_CACHE[$key]}"; return 0; }
    run_cmd "lspci.s.$(_bdf_key "$key").vv" -- $SUDO lspci -s "$key" -vv
}

# GT/s -> PCIe 代数
gtps_to_pcie_ver() {
    case "$1" in
        "2.5GT/s") echo "PCIe 1.0" ;; "5GT/s")  echo "PCIe 2.0" ;;
        "8GT/s")   echo "PCIe 3.0" ;; "16GT/s") echo "PCIe 4.0" ;;
        "32GT/s")  echo "PCIe 5.0" ;; "64GT/s") echo "PCIe 6.0" ;;
        *) : ;;
    esac
}

# 取 LnkSta 里的一行字段：<文本> <LnkSta|LnkCap>
_lnk_speed() {
    printf '%s\n' "$1" | grep -E "$2:" | head -1 | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //'
}

# pcie_gen：实际协商速率（LnkSta），取不到再退回能力（LnkCap）
get_pcie_gen() {
    local a="$1" info cap v
    [[ -z "$a" || "$a" == "Unknown" ]] && { printf 'N/A'; return 0; }
    info=$(_lspci_lnk_text "$a")
    [[ -z "$info" ]] && { printf 'N/A'; return 0; }
    cap=$(_lnk_speed "$info" "LnkSta")
    [[ -z "$cap" ]] && cap=$(_lnk_speed "$info" "LnkCap")
    [[ -z "$cap" ]] && { printf 'N/A'; return 0; }
    v=$(gtps_to_pcie_ver "$cap")
    [[ -z "$v" ]] && { printf 'N/A'; return 0; }
    printf '%s' "$v"
}

# pcie_link_cap：能力（速度 + 宽度）
get_pcie_link_cap() {
    local a="$1" info cap_line speed width
    [[ -z "$a" || "$a" == "Unknown" ]] && { printf 'N/A'; return 0; }
    info=$(_lspci_lnk_text "$a")
    [[ -z "$info" ]] && { printf 'N/A'; return 0; }
    cap_line=$(printf '%s\n' "$info" | grep -E "LnkCap:" | head -1)
    speed=$(printf '%s' "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    width=$(printf '%s' "$cap_line" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    if [[ -n "$speed" && -n "$width" ]]; then printf '%s %s' "$speed" "$width"
    elif [[ -n "$speed" ]]; then printf '%s' "$speed"
    elif [[ -n "$width" ]]; then printf '%s' "$width"
    else printf 'N/A'; fi
}

# pcie_link_sta：当前状态（速度 + 降速原因、宽度 + 降宽原因）
get_pcie_link_sta() {
    local a="$1" info sta s ss w ws sstr="" wstr=""
    [[ -z "$a" || "$a" == "Unknown" ]] && { printf 'N/A'; return 0; }
    info=$(_lspci_lnk_text "$a")
    [[ -z "$info" ]] && { printf 'N/A'; return 0; }
    sta=$(printf '%s\n' "$info" | grep -E "LnkSta:" | head -1)
    s=$(printf '%s' "$sta" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    ss=$(printf '%s' "$sta" | grep -oE 'Speed [0-9.]+GT/s \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    w=$(printf '%s' "$sta" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    ws=$(printf '%s' "$sta" | grep -oE 'Width x[0-9]+ \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$ss" ]] && ss="ok"
    [[ -z "$ws" ]] && ws="ok"
    [[ -n "$s" ]] && sstr="${s} (${ss})"
    [[ -n "$w" ]] && wstr="${w} (${ws})"
    if [[ -n "$sstr" && -n "$wstr" ]]; then printf '%s %s' "$sstr" "$wstr"
    elif [[ -n "$sstr" ]]; then printf '%s' "$sstr"
    elif [[ -n "$wstr" ]]; then printf '%s' "$wstr"
    else printf 'N/A'; fi
}

# 从 sysfs 读 PCI vendor / device id
get_pcie_vid() {
    local k v
    [[ -z "$1" || "$1" == "Unknown" ]] && { printf 'N/A'; return 0; }
    k=$(normalize_pci_addr "$1")
    v=$(_fs_read "/sys/bus/pci/devices/$k/vendor" | tr -d ' \n')
    v="${v#0x}"
    [[ -n "$v" ]] && printf '%s' "$v" || printf 'N/A'
}

# 从 sysfs 读 PCI device id
get_pcie_pid() {
    local k v
    [[ -z "$1" || "$1" == "Unknown" ]] && { printf 'N/A'; return 0; }
    k=$(normalize_pci_addr "$1")
    v=$(_fs_read "/sys/bus/pci/devices/$k/device" | tr -d ' \n')
    v="${v#0x}"
    [[ -n "$v" ]] && printf '%s' "$v" || printf 'N/A'
}

# 从 /sys/block/<disk>/device 逐级向上找第一个 PCI 设备 BDF
get_pci_busid_from_sysfs() {
    local device="$1" disk_name target base
    [[ -z "$device" ]] && { printf 'Unknown'; return 0; }
    disk_name=$(basename "$device")
    target=$(_fs_readlink "/sys/block/$disk_name/device")
    [[ -z "$target" ]] && { printf 'Unknown'; return 0; }
    while [[ -n "$target" && "$target" != "/" ]]; do
        base=$(basename "$target")
        if [[ "$base" =~ ^[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$ ]]; then
            printf '%s' "$base"; return 0
        fi
        target=$(dirname "$target")
    done
    printf 'Unknown'
}

# 统一输出 BDF（P1-8）：优先 by-path 提取，其次 sysfs 向上找，都没有则 N/A
bdf_of_dev() {
    local dev="$1" b
    [[ -z "$dev" || "$dev" == "N/A" ]] && { printf 'N/A'; return 0; }
    b="${BDF_BY_SD[$dev]:-}"
    [[ -z "$b" ]] && b=$(get_pci_busid_from_sysfs "$dev")
    [[ -z "$b" || "$b" == "Unknown" ]] && b="N/A"
    printf '%s' "$b"
}

# ============================================================================
# §12 控制器探测与 SAS 代数判定
# ============================================================================

declare -a STORAGE_CTRLS=()            # 每项：bdf|vid|pid|family|class
STORAGE_CTRLS_LOADED=false

# 从 lspci -D -nn 里挑出 RAID/HBA 控制器（按 class + vid 过滤，排除 PCIe Switch 管理端点）
detect_storage_controllers() {
    [[ "$STORAGE_CTRLS_LOADED" == "true" ]] && return 0
    STORAGE_CTRLS_LOADED=true

    local lspci_out line
    lspci_out=$(run_cmd "lspci.D.nn" -- lspci -D -nn)

    while IFS= read -r line; do
        local bdf vid pid family class cls_f desc
        bdf=$(awk '{print $1}' <<< "$line")
        [[ -z "$bdf" ]] && continue
        [[ "$bdf" =~ ^[0-9a-fA-F]{4}: ]] || continue

        # ① PCI class 过滤：0x0104 RAID / 0x0106 SATA / 0x0107 SAS
        cls_f="/sys/bus/pci/devices/$bdf/class"
        _fs_exists "$cls_f" || continue
        class=$(_fs_read "$cls_f" | tr -d ' \n')
        case "$class" in
            0x0104*|0x0106*|0x0107*) ;;
            *) continue ;;
        esac

        # ② VID:PID（取设备自身的 [xxxx:xxxx]，不取 subsystem）
        vid=$(printf '%s' "$line" | grep -oE '\[[0-9a-fA-F]{4}:' | head -1 | tr -d '[:')
        pid=$(printf '%s' "$line" | grep -oE '\[[0-9a-fA-F]{4}:[0-9a-fA-F]{4}\]' | head -1 | sed 's/.*://;s/\]//')
        [[ -z "$vid" || -z "$pid" ]] && continue

        case "${vid,,}" in
            1000) family="lsi" ;;
            9005) family="adaptec" ;;
            1b4b) family="marvell" ;;
            *)    continue ;;
        esac

        # ③ 排除 PCIe Switch 的带内管理端点（class 0x0107 但不是 SAS HBA）
        lspci_short_prefetch "$bdf"
        desc="${LSPCI_SHORT_CACHE[$bdf]}"
        case "$desc" in
            *"PCIe Switch management"*|*"Switch management endpoint"*|\
            *"management endpoint"*|*"PCIe Bridge"*|*"PCIe Gen"*"Switch"*)
                log_debug "跳过 PCIe Switch 管理端点: $bdf ($desc)"
                continue
                ;;
        esac

        STORAGE_CTRLS+=("${bdf}|${vid}|${pid}|${family}|${class}")
        log_debug "  ✓ 收录 RAID/HBA: $bdf ($desc)"
    done <<< "$lspci_out"

    log_debug "检测到 ${#STORAGE_CTRLS[@]} 个 RAID/HBA 控制器"
    return 0
}

# 是否存在某厂商（lsi / adaptec / marvell）的控制器
have_storage_vendor() {
    local want="$1" c bdf vid pid family class
    detect_storage_controllers
    for c in "${STORAGE_CTRLS[@]}"; do
        IFS='|' read -r bdf vid pid family class <<< "$c"
        [[ "$family" == "$want" ]] && return 0
    done
    return 1
}

# 取某个 BDF 的 PCI class（用于区分 MegaRAID 0x0104 与 SAS HBA 0x0107）
_ctrl_class_of() {
    local want="$1" c bdf vid pid family class
    for c in "${STORAGE_CTRLS[@]}"; do
        IFS='|' read -r bdf vid pid family class <<< "$c"
        [[ "$bdf" == "$want" ]] && { printf '%s' "$class"; return 0; }
    done
    printf ''
}

# LSI/Broadcom PID -> SAS 代数（来源：Broadcom SAS HBA 产品线；新卡请在此补充）
# 这是型号名判不出来时的兜底，覆盖面天然有限（新卡不断出现）。
_lsi_pid_to_gen() {
    local pid="${1,,}"
    case "$pid" in
        00b2|00e2|00e3|00e4|00e5|00e6|00e7) echo "sas4" ;;
        0097|005d|00ac|00ad|00ae|00af|00b5) echo "sas3" ;;
        0072|0087) echo "sas2" ;;
        *) echo "unknown" ;;
    esac
}

# 型号家族号 -> 代数。
#   ★ 这里的家族→代数表与 v61 的正则【完全一致】，只把"后缀必须是两位数字"
#     放宽为"数字或字面 xx"。这样修复 SAS39xx 的漏判时，不会顺带改变
#     任何 v61 已经判对的卡（例如 SAS3816 在 v61 里就是 sas3，这里保持 sas3）。
#     · SAS30xx~SAS38xx → SAS-3
#     · SAS39xx / SAS40xx / SAS41xx / SAS50xx / SAS51xx → SAS-4
#     · SAS20xx~SAS25xx → SAS-2
_lsi_family_to_gen() {
    local fam="$1"
    case "$fam" in
        39|40|41|50|51) echo "sas4" ;;
        30|31|32|33|34|35|36|37|38) echo "sas3" ;;
        20|21|22|23|24|25) echo "sas2" ;;
        *) echo "" ;;
    esac
}

# 按单个 BDF 判定 SAS 代数（P1-2：不再用“全机最高代数”决定所有控制器）
#   ① 先从 lspci 描述里找 SAS<家族号> 形式的型号名（兼容 xx / 数字两种写法）
#   ② 再看 Broadcom 家族名（SAS3008 之外的写法，如 "Fusion-MPT SAS-3"）
#   ③ 最后退回 PID 表
lsi_gen_of_bdf() {
    local bdf="$1" pid="$2" info fam gen
    info="${LSPCI_SHORT_CACHE[$bdf]:-}"
    [[ -z "$info" ]] && info=$(run_cmd "lspci.s.$(_bdf_key "$bdf")" -- lspci -s "$bdf")

    # ① 型号名：SAS + 两位家族号，后缀可以是 "xx" 或两位数字
    if [[ "$info" =~ SAS([0-9]{2})([0-9]{2}|xx|XX) ]]; then
        fam="${BASH_REMATCH[1]}"
        gen=$(_lsi_family_to_gen "$fam")
        [[ -n "$gen" ]] && { echo "$gen"; return 0; }
    fi

    # ② "Fusion-MPT SAS-3" / "Fusion-MPT SAS-2" 这类没有具体型号的写法
    if   [[ "$info" =~ Fusion-MPT[[:space:]]+SAS-4 || "$info" =~ SAS-4[[:space:]]+\(24 ]]; then
        echo "sas4"; return 0
    elif [[ "$info" =~ Fusion-MPT[[:space:]]+SAS-3 || "$info" =~ SAS-3[[:space:]]+\(12 ]]; then
        echo "sas3"; return 0
    elif [[ "$info" =~ Fusion-MPT[[:space:]]+SAS-2 || "$info" =~ SAS-2[[:space:]]+\(6 ]]; then
        echo "sas2"; return 0
    fi

    # ③ PID 表兜底
    _lsi_pid_to_gen "$pid"
}

# ============================================================================
# §13 storcli 分支（MegaRAID / LSI RAID 卡）
#   数据来源：storcli64 /call/eall/sall show all J（物理盘）
#             storcli64 /call/vall      show all J（VD -> PD 映射）
#   键统一为 "<ctrl>|<eid>:<slt>"，与 /cX/eY/sZ 一一对应。
# ============================================================================

declare -A MRAID_SN MRAID_WWN MRAID_DID MRAID_STATE MRAID_SIZE MRAID_MODEL MRAID_MED MRAID_FW
declare -A MRAID_MEC MRAID_OEC MRAID_PFC MRAID_SMART_ALERT
declare -A MRAID_PD_DG MRAID_PD_TYPE MRAID_VD_MODE
declare -A PD_TO_OSDEV                 # ctrl|eid:slt -> /dev/sdX（该盘所在 VD 的 OS 设备）
declare -A PD_TO_VD_SIZE               # ctrl|eid:slt -> VD 容量（仅日志用，P0-2）
declare -A CTRL_CHANNEL                # ctrl -> megaraid 直通用的通道设备
MRAID_LOADED=false
VD_MAP_LOADED=false

# 解析 storcli show all J 的物理盘段（brief / State / Device attributes）
_parse_storcli_json() {
    local json="$1" line cur="" mode="" v
    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*\"Drive\ /c([0-9]+)/e([0-9]+)/s([0-9]+)\"[[:space:]]*:[[:space:]]*\[ ]]; then
            cur="${BASH_REMATCH[1]}|${BASH_REMATCH[2]}:${BASH_REMATCH[3]}"; mode="brief"; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*\"Drive\ /c([0-9]+)/e([0-9]+)/s([0-9]+)\ State\"[[:space:]]*:[[:space:]]*\{ ]]; then
            cur="${BASH_REMATCH[1]}|${BASH_REMATCH[2]}:${BASH_REMATCH[3]}"; mode="state"; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*\"Drive\ /c([0-9]+)/e([0-9]+)/s([0-9]+)\ Device\ attributes\"[[:space:]]*:[[:space:]]*\{ ]]; then
            cur="${BASH_REMATCH[1]}|${BASH_REMATCH[2]}:${BASH_REMATCH[3]}"; mode="attrs"; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*\"Drive\ /c([0-9]+)/e([0-9]+)/s([0-9]+)\ Policies/Settings\"[[:space:]]*:[[:space:]]*\{ ]]; then
            mode=""; continue
        fi

        if [[ "$mode" == "brief" ]]; then
            if   [[ "$line" =~ ^[[:space:]]*\"DID\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then MRAID_DID["$cur"]="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*\"State\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_STATE["$cur"]=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"Size\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_SIZE["$cur"]=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"Med\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_MED["$cur"]=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"Model\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_MODEL["$cur"]=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"DG\"[[:space:]]*:[[:space:]]*(-?[0-9]+|\"[^\"]*\") ]]; then v="${BASH_REMATCH[1]}"; v="${v//\"/}"; MRAID_PD_DG["$cur"]="$v"
            elif [[ "$line" =~ ^[[:space:]]*\"Type\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_PD_TYPE["$cur"]=$(_trim "$v")
            fi
            continue
        fi

        if [[ "$mode" == "state" ]]; then
            if   [[ "$line" =~ ^[[:space:]]*\"Media\ Error\ Count\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then MRAID_MEC["$cur"]="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*\"Other\ Error\ Count\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then MRAID_OEC["$cur"]="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*\"Predictive\ Failure\ Count\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then MRAID_PFC["$cur"]="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*\"S\.M\.A\.R\.T\ alert\ flagged\ by\ drive\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_SMART_ALERT["$cur"]=$(_trim "$v")
            fi
            continue
        fi

        if [[ "$mode" == "attrs" ]]; then
            if   [[ "$line" =~ ^[[:space:]]*\"SN\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_SN["$cur"]=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"WWN\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; v=$(_trim "$v"); MRAID_WWN["$cur"]="${v^^}"
            elif [[ "$line" =~ ^[[:space:]]*\"Firmware\ Revision\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; MRAID_FW["$cur"]=$(_trim "$v")
            fi
            continue
        fi
    done <<< "$json"
    return 0
}

# 加载物理盘映射（storcli 是全局的，一次拿到所有控制器）
load_megaraid_map() {
    [[ "$MRAID_LOADED" == "true" ]] && return 0
    MRAID_LOADED=true
    local storcli_cmd json
    storcli_cmd=$(_find_storcli)
    [[ -z "$storcli_cmd" ]] && return 0
    json=$(run_cmd "storcli64.call.eall.sall" -- $SUDO "$storcli_cmd" /call/eall/sall show all J)
    [[ -z "$json" ]] && return 0
    grep -q '"Drive /c' <<< "$json" || return 0
    _parse_storcli_json "$json"
    log_info "storcli 加载 ${#MRAID_SN[@]} 块物理盘"
    return 0
}

# 加载 VD -> PD 映射：OS 设备名（disk_dev_name 用）与 VD 容量（仅日志用）
load_vd_map() {
    [[ "$VD_MAP_LOADED" == "true" ]] && return 0
    VD_MAP_LOADED=true
    local storcli_cmd json
    storcli_cmd=$(_find_storcli)
    [[ -z "$storcli_cmd" ]] && return 0
    json=$(run_cmd "storcli64.call.vall" -- $SUDO "$storcli_cmd" /call/vall show all J)
    [[ -z "$json" ]] && return 0

    local line cur_ctrl="" cur_vd_id="" mode="" pd_list="" cur_osdev="" cur_vd_size="" vd_type="" v pd

    # 一个 VD 块解析结束时，把收集到的 PD 列表写进映射
    _flush_vd_pds() {
        local x
        [[ -z "$pd_list" ]] && return 0
        for x in $pd_list; do
            [[ -n "$cur_osdev" ]]   && PD_TO_OSDEV["${cur_ctrl}|${x}"]="$cur_osdev"
            [[ -n "$cur_vd_size" ]] && PD_TO_VD_SIZE["${cur_ctrl}|${x}"]="$cur_vd_size"
        done
    }

    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*\"/c([0-9]+)/v([0-9]+)\"[[:space:]]*:[[:space:]]*\[ ]]; then
            _flush_vd_pds
            cur_ctrl="${BASH_REMATCH[1]}"; cur_vd_id="${BASH_REMATCH[2]}"
            pd_list=""; cur_osdev=""; cur_vd_size=""; vd_type=""; mode="vd_brief"; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*\"PDs\ for\ VD\ [0-9]+\"[[:space:]]*:[[:space:]]*\[ ]]; then mode="pds"; continue; fi
        if [[ "$line" =~ ^[[:space:]]*\"VD[0-9]+\ Properties\"[[:space:]]*:[[:space:]]*\{ ]]; then mode="vd_props"; continue; fi

        if [[ "$mode" == "vd_brief" ]]; then
            if   [[ "$line" =~ ^[[:space:]]*\"Size\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; cur_vd_size=$(_trim "$v")
            elif [[ "$line" =~ ^[[:space:]]*\"TYPE\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; vd_type=$(_trim "$v"); MRAID_VD_MODE["${cur_ctrl}|${cur_vd_id}"]="$vd_type"
            fi
            continue
        fi
        if [[ "$mode" == "pds" ]]; then
            if [[ "$line" =~ ^[[:space:]]*\"EID:Slt\"[[:space:]]*:[[:space:]]*\"([0-9]+:[0-9]+)\" ]]; then pd_list+="${BASH_REMATCH[1]} "; fi
            continue
        fi
        if [[ "$mode" == "vd_props" ]]; then
            if [[ "$line" =~ ^[[:space:]]*\"OS\ Drive\ Name\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then v="${BASH_REMATCH[1]}"; cur_osdev=$(_trim "$v"); fi
            continue
        fi
    done <<< "$json"
    _flush_vd_pds

    log_info "VD → PD 映射: osdev=${#PD_TO_OSDEV[@]}, vdsize=${#PD_TO_VD_SIZE[@]}, vdmode=${#MRAID_VD_MODE[@]}"
    return 0
}

# 每个控制器挑一个 OS 设备作为 megaraid 直通通道
# F-7：用独立的布尔量表示"已加载"，不再拿"关联数组非空"当标志——
#      后者语义混淆（数组【天然】可能为空，比如一块盘都没有），
#      也容易被后来的读者误当成真正的缓存判断。
CTRL_CHANNELS_BUILT=false

build_ctrl_channels() {
    [[ "$CTRL_CHANNELS_BUILT" == "true" ]] && return 0
    CTRL_CHANNELS_BUILT=true
    local k ctrl
    for k in "${!PD_TO_OSDEV[@]}"; do
        ctrl="${k%%|*}"
        [[ -n "${CTRL_CHANNEL[$ctrl]:-}" ]] && continue
        CTRL_CHANNEL["$ctrl"]="${PD_TO_OSDEV[$k]}"
    done
    return 0
}

# 挑出与期望序列号匹配的 SMART 文本（直接调用：把结果写进全局）
#   ① 先试 OS 设备直连；② 再试 --device=megaraid,DID 直通
# 这样 errors 才会基于“真正取到 SMART 的那块设备”计算（P0-4）
phys_smart_pick() {
    local os_dev="$1" did="$2" channel="$3" expect_sn="$4"
    local direct_info direct_sn mega_info mega_sn
    PHYS_SMART=""; PHYS_SMART_DEV=""

    if [[ -n "$os_dev" ]]; then
        direct_info=$(smart_text "$os_dev" a)
        if [[ -n "$direct_info" ]]; then
            direct_sn=$(smart_serial_of "$direct_info")
            if [[ -n "$direct_sn" && "$direct_sn" == "$expect_sn" ]]; then
                log_debug "  直连命中: $os_dev SN=$direct_sn"
                PHYS_SMART="$direct_info"; PHYS_SMART_DEV="$os_dev"; return 0
            fi
            log_debug "  直连 SN 不匹配 ($direct_sn != $expect_sn)"
        fi
    fi

    if [[ -n "$did" && "$did" != "0" && -n "$channel" ]]; then
        mega_info=$(smart_megaraid_text "$channel" "$did")
        if [[ -n "$mega_info" ]]; then
            mega_sn=$(smart_serial_of "$mega_info")
            if [[ -n "$mega_sn" && "$mega_sn" == "$expect_sn" ]]; then
                log_debug "  megaraid 命中: DID=$did channel=$channel SN=$mega_sn"
                PHYS_SMART="$mega_info"; PHYS_SMART_DEV="$channel"; return 0
            fi
            log_debug "  megaraid SN 不匹配 ($mega_sn != $expect_sn)"
        fi
    fi
    return 1
}

# 物理盘状态/类型 -> disk_raid_mode
#   优先按 PD Type/State 判定（JBOD/Hotspare/Rebuild/Offline...）；
#   都判不出来时用所属 DG 的 VD RAID 级别，最后才退回 "RAID"
_compute_raid_mode() {
    local ctrl="$1" eid_slt="$2" pd_state="$3" pd_type="$4" dg vd_type
    case "$pd_type" in
        JBOD*) echo "JBOD"; return 0 ;;
        "Global Hotspare"*|GHS*) echo "Global Hotspare"; return 0 ;;
        "Dedicated Hotspare"*|DHS*) echo "Dedicated Hotspare"; return 0 ;;
        Rbld*|Rebuild*) echo "Rebuild"; return 0 ;;
    esac
    case "$pd_state" in
        JBOD*) echo "JBOD"; return 0 ;;
        UGood*|UG*|"Unconfigured(good)"*|Unconfigured\(good\)*) echo "Unconfigured(good)"; return 0 ;;
        UBad*|"Unconfigured(bad)"*|Unconfigured\(bad\)*) echo "Unconfigured(bad)"; return 0 ;;
        Unconfigured*) echo "Unconfigured"; return 0 ;;
        GHS*|"Global Hotspare"*) echo "Global Hotspare"; return 0 ;;
        DHS*|"Dedicated Hotspare"*) echo "Dedicated Hotspare"; return 0 ;;
        Rbld*|Rebuild*) echo "Rebuild"; return 0 ;;
        Offln*|Offline*) echo "Offline"; return 0 ;;
        Msng*|Missing*) echo "Missing"; return 0 ;;
        Cpybck*|Copyback*) echo "Copyback"; return 0 ;;
    esac
    dg="${MRAID_PD_DG["${ctrl}|${eid_slt}"]:-}"
    if [[ -n "$dg" && "$dg" =~ ^[0-9]+$ ]]; then
        vd_type="${MRAID_VD_MODE["${ctrl}|${dg}"]:-}"
        [[ -n "$vd_type" ]] && { echo "$vd_type"; return 0; }
    fi
    [[ "$pd_state" =~ Onln ]] && { echo "RAID"; return 0; }
    echo "${pd_state:-Unknown}"
}

# 输出 storcli 分支的每一块物理盘
collect_from_storcli() {
    local serial="$1"
    build_ctrl_channels

    local keys; keys=$(printf '%s\n' "${!MRAID_SN[@]}" | sort -t'|' -k1,1n -k2,2V)
    local key ctrl eid_slt eid slt sn wwn did model_raw med fw size_str vd_size
    local os_dev channel smart_info smart_info_dev nvme_sl disk_type size_gb
    local vendor disk_model disk_product pd_state pd_type raid_mode pci_busid
    local pcie_slot_val user_cap_gb raid_loc model_smart

    for key in $keys; do
        ctrl="${key%%|*}"; eid_slt="${key#*|}"
        eid="${eid_slt%%:*}"; slt="${eid_slt##*:}"
        sn="${MRAID_SN[$key]}"; wwn="${MRAID_WWN[$key]}"; did="${MRAID_DID[$key]}"
        model_raw="${MRAID_MODEL[$key]:-Unknown}"
        med="${MRAID_MED[$key]:-}"; fw="${MRAID_FW[$key]:-N/A}"
        # ★ P0-2：物理盘容量优先；VD 容量只用于日志
        size_str="${MRAID_SIZE[$key]:-}"
        vd_size="${PD_TO_VD_SIZE[$key]:-}"
        pd_state="${MRAID_STATE[$key]:-}"; pd_type="${MRAID_PD_TYPE[$key]:-}"
        raid_loc="C${ctrl}:E${eid}:S${slt}"

        os_dev="${PD_TO_OSDEV[$key]:-}"
        [[ -z "$os_dev" && -n "$wwn" ]] && os_dev="${OS_DEV_BY_WWN[$wwn]:-}"
        channel="${CTRL_CHANNEL[$ctrl]:-}"

        # 预取（父 shell 写缓存）后挑选与该 SN 匹配的 SMART
        smart_prefetch "$os_dev" a
        smart_megaraid_prefetch "$channel" "$did"
        phys_smart_pick "$os_dev" "$did" "$channel" "$sn"
        smart_info="$PHYS_SMART"; smart_info_dev="$PHYS_SMART_DEV"

        if [[ -n "$smart_info" ]]; then
            model_smart=$(_field_val "$smart_info" "Device Model:")
            [[ -n "$model_smart" ]] && model_raw="$model_smart"
        fi

        disk_type="${med:-HDD}"
        nvme_sl=""
        if [[ "$disk_type" == "NVMe" && -n "$smart_info_dev" ]]; then
            nvme_smart_prefetch "$smart_info_dev"
            nvme_sl=$(nvme_smart_text "$smart_info_dev")
        fi

        user_cap_gb=$(get_user_capacity_gb "$smart_info")
        if [[ -n "$user_cap_gb" && "$user_cap_gb" != "0" ]]; then
            size_gb="$user_cap_gb"
        else
            size_gb=$(convert_gib_to_gb "$size_str")
        fi
        [[ -z "$size_gb" || "$size_gb" == "0" ]] && size_gb="Unknown"
        size_gb=$(_round_to_nominal "$size_gb")

        health_fields "$smart_info" "$nvme_sl" "$disk_type" "$smart_info_dev" "$key"

        vendor=$(get_vendor "$model_raw")
        disk_product=$(clean_product "$model_raw"); [[ -z "$disk_product" ]] && disk_product="$model_raw"
        disk_model=$(resolve_model "$model_raw" "$disk_product")

        pci_busid=$(bdf_of_dev "$os_dev")
        pcie_slot_prefetch "$pci_busid"
        pcie_slot_val=$(pcie_slot_cached "$pci_busid")
        [[ -z "$wwn" ]] && wwn="N/A"
        raid_mode=$(_compute_raid_mode "$ctrl" "$eid_slt" "$pd_state" "$pd_type")

        emit_row "${sn:-loc:$raid_loc}" "$serial" "$disk_type" "$vendor" "$disk_model" "$disk_product" "$sn" \
                 "$size_gb" "$fw" "${os_dev:-N/A}" "$wwn" "$raid_mode" "$pci_busid" "$pcie_slot_val" \
                 "$raid_loc" "N/A" "N/A" "N/A" "N/A" "N/A" \
                 "$HEALTH_PH" "$HEALTH_LIFE" "$HEALTH_ERRORS"
        log_info "✓ $raid_loc DID=$did: sn=$sn, vendor=$vendor, model=$disk_model, product=$disk_product, size=${size_gb}GB, vd=${vd_size:-N/A}, state=$pd_state, type=$pd_type, mode=$raid_mode, dev=${os_dev:-N/A}, err=$HEALTH_ERRORS"
    done
    return 0
}

# ============================================================================
# §14 sas3ircu 分支（LSI SAS3 HBA，IT/IR 模式）
#   数据来源：sas3ircu list / sas3ircu <idx> display
#   键统一为 "<ctrl_idx>|<eid>:<slt>"
# ============================================================================

declare -A SAS3_SN SAS3_WWN SAS3_MODEL SAS3_FW SAS3_STATE SAS3_SIZE_MB SAS3_MED
declare -A SAS3_SIZE_SECTORS SAS3_PD_TO_VD SAS3_VD_WWID SAS3_CTRL_BDF SAS3_VD_MODE
SAS3_LOADED=false

# 解析 sas3ircu <idx> display：Controller information / IR Volume information /
# Physical device information 三段，用 _flush_pd / _flush_vd 在块结束处落库
_parse_sas3ircu_display() {
    local out="$1" ctrl_idx="$2"
    local in_pd=0 in_vd=0 in_ctrl=0
    local eid="" slt="" sn="" wwn="" model="" fw="" state="" size_mb="" size_sectors="" med=""
    local vd_id="" vd_wwid="" vd_phys="" vd_raid_level=""
    local ctrl_bus="" ctrl_dev="" ctrl_func="" line

    _flush_pd() {
        [[ -z "$slt" ]] && return 0
        local key="${ctrl_idx}|${eid}:${slt}"
        SAS3_SN["$key"]="$sn"; SAS3_WWN["$key"]="$wwn"; SAS3_MODEL["$key"]="$model"
        SAS3_FW["$key"]="$fw"; SAS3_STATE["$key"]="$state"
        SAS3_SIZE_MB["$key"]="$size_mb"; SAS3_SIZE_SECTORS["$key"]="$size_sectors"
        SAS3_MED["$key"]="$med"
    }

    _flush_vd() {
        [[ -z "$vd_id" ]] && return 0
        local vkey="${ctrl_idx}|${vd_id}" phys
        SAS3_VD_WWID["$vkey"]="$vd_wwid"
        [[ -n "$vd_raid_level" ]] && SAS3_VD_MODE["$vkey"]="$vd_raid_level"
        for phys in $vd_phys; do SAS3_PD_TO_VD["${ctrl_idx}|${phys}"]="$vd_id"; done
    }

    while IFS= read -r line; do
        if [[ "$line" =~ ^Controller[[:space:]]+information ]]; then
            _flush_pd; _flush_vd
            eid=""; slt=""; sn=""; wwn=""; model=""; fw=""; state=""; size_mb=""; size_sectors=""; med=""
            vd_id=""; vd_wwid=""; vd_phys=""; vd_raid_level=""
            in_ctrl=1; in_pd=0; in_vd=0; continue
        fi
        if [[ "$line" =~ ^IR[[:space:]]+Volume[[:space:]]+information ]]; then
            _flush_pd; _flush_vd
            eid=""; slt=""; sn=""; wwn=""; model=""; fw=""; state=""; size_mb=""; size_sectors=""; med=""
            vd_id=""; vd_wwid=""; vd_phys=""; vd_raid_level=""
            in_ctrl=0; in_pd=0; in_vd=1; continue
        fi
        if [[ "$line" =~ ^Physical[[:space:]]+(device|drive)[[:space:]]+information ]]; then
            _flush_pd; _flush_vd
            eid=""; slt=""; sn=""; wwn=""; model=""; fw=""; state=""; size_mb=""; size_sectors=""; med=""
            vd_id=""; vd_wwid=""; vd_phys=""; vd_raid_level=""
            in_ctrl=0; in_pd=1; in_vd=0; continue
        fi
        if [[ "$line" =~ ^Enclosure[[:space:]]+information ]]; then
            _flush_pd; _flush_vd; in_ctrl=0; in_pd=0; in_vd=0; continue
        fi

        # Controller information：拿 Bus/Device/Function 拼出控制器 BDF
        if [[ $in_ctrl -eq 1 ]]; then
            [[ "$line" =~ ^[[:space:]]*Bus[[:space:]]*:[[:space:]]*([0-9]+) ]]      && ctrl_bus="${BASH_REMATCH[1]}"
            [[ "$line" =~ ^[[:space:]]*Device[[:space:]]*:[[:space:]]*([0-9]+) ]]   && ctrl_dev="${BASH_REMATCH[1]}"
            [[ "$line" =~ ^[[:space:]]*Function[[:space:]]*:[[:space:]]*([0-9]+) ]] && ctrl_func="${BASH_REMATCH[1]}"
            continue
        fi

        # IR Volume information：VD wwid / RAID 级别 / 成员 PD
        if [[ $in_vd -eq 1 ]]; then
            if [[ "$line" =~ ^IR[[:space:]]+volume[[:space:]]+([0-9]+) ]]; then
                _flush_vd; vd_id="${BASH_REMATCH[1]}"; vd_wwid=""; vd_phys=""; vd_raid_level=""; continue
            fi
            if   [[ "$line" =~ ^[[:space:]]*Volume[[:space:]]+wwid[[:space:]]*:[[:space:]]*([0-9a-fA-F]+) ]]; then vd_wwid="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*RAID[[:space:]]+level[[:space:]]*:[[:space:]]*([A-Za-z0-9-]+) ]]; then vd_raid_level="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ ^[[:space:]]*PHY\[[0-9]+\][[:space:]]+Enclosure#/Slot#[[:space:]]*:[[:space:]]*([0-9]+):([0-9]+) ]]; then vd_phys+="${BASH_REMATCH[1]}:${BASH_REMATCH[2]} "
            fi
            continue
        fi

        [[ $in_pd -eq 1 ]] || continue

        # 一块盘结束：出现 "Device is a ..." 或下一个 Enclosure #
        if [[ "$line" =~ ^[[:space:]]*Device[[:space:]]+is[[:space:]]+a[[:space:]] ]]; then
            _flush_pd; eid=""; slt=""; sn=""; wwn=""; model=""; fw=""; state=""; size_mb=""; size_sectors=""; med=""; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*Enclosure[[:space:]]*#[[:space:]]*:[[:space:]]*([0-9]+) ]]; then
            _flush_pd; eid="${BASH_REMATCH[1]}"; slt=""; sn=""; wwn=""; model=""; fw=""; state=""; size_mb=""; size_sectors=""; med=""; continue
        fi

        if   [[ "$line" =~ ^[[:space:]]*Slot[[:space:]]*#[[:space:]]*:[[:space:]]*([0-9]+) ]]; then slt="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^[[:space:]]*Serial[[:space:]]+No[[:space:]]*:[[:space:]]*(.+) ]]; then sn=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Model[[:space:]]+Number[[:space:]]*:[[:space:]]*(.+) ]]; then model=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Firmware[[:space:]]+Revision[[:space:]]*:[[:space:]]*(.+) ]]; then fw=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*State[[:space:]]*:[[:space:]]*(.+) ]]; then state=$(_trim "${BASH_REMATCH[1]%%(*}")
        elif [[ "$line" =~ ^[[:space:]]*Size[^:]*:[[:space:]]*([0-9]+)/([0-9]+) ]]; then size_mb="${BASH_REMATCH[1]}"; size_sectors="${BASH_REMATCH[2]}"
        elif [[ "$line" =~ ^[[:space:]]*Size[^:]*:[[:space:]]*([0-9]+) ]]; then size_mb="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^[[:space:]]*Drive[[:space:]]+Type[[:space:]]*:[[:space:]]*(.+) ]]; then med=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*GUID[[:space:]]*:[[:space:]]*([0-9a-fA-F]+) ]]; then
            wwn="${BASH_REMATCH[1]}"; wwn="${wwn#0x}"; wwn="${wwn#0X}"; wwn=$(printf '%s' "$wwn" | tr 'a-f' 'A-F')
        fi
    done <<< "$out"

    _flush_pd; _flush_vd
    if [[ -n "$ctrl_bus" && -n "$ctrl_dev" && -n "$ctrl_func" ]]; then
        SAS3_CTRL_BDF["$ctrl_idx"]=$(printf "%04x:%02x:%02x.%x" 0 "$ctrl_bus" "$ctrl_dev" "$ctrl_func")
    fi
    return 0
}

# 加载 sas3ircu 映射：list 拿控制器索引，逐个 display 解析
load_sas3ircu_map() {
    [[ "$SAS3_LOADED" == "true" ]] && return 0
    SAS3_LOADED=true
    local sas3ircu_cmd list_out ctrl_idx line
    sas3ircu_cmd=$(_find_sas3ircu)
    [[ -z "$sas3ircu_cmd" ]] && return 0
    list_out=$(run_cmd "sas3ircu.list" -- $SUDO "$sas3ircu_cmd" list)
    [[ -z "$list_out" ]] && return 0

    local -a ctrls=()
    while IFS= read -r line; do
        [[ "$line" =~ ^[[:space:]]*([0-9]+)[[:space:]] ]] && ctrls+=("${BASH_REMATCH[1]}")
    done <<< "$list_out"
    [[ ${#ctrls[@]} -eq 0 ]] && ctrls=(0)

    for ctrl_idx in "${ctrls[@]}"; do
        local display_out
        display_out=$(run_cmd "sas3ircu.${ctrl_idx}.display" -- $SUDO "$sas3ircu_cmd" "$ctrl_idx" display)
        [[ -z "$display_out" ]] && continue
        grep -q "Physical device" <<< "$display_out" || continue
        _parse_sas3ircu_display "$display_out" "$ctrl_idx"
    done
    [[ ${#SAS3_SN[@]} -gt 0 ]] && log_info "sas3ircu 加载 ${#SAS3_SN[@]} 块物理盘"
    return 0
}

# 输出 sas3ircu 分支的每一块物理盘
collect_from_sas3ircu() {
    local serial="$1"

    # 先算 VD -> OS 设备、控制器 -> 兜底 OS 设备（供 disk_dev_name 使用）
    local -A vd_osdev=() ctrl_fallback=()
    local vkey vd_wwid vd_os ckey bdf fd
    for vkey in "${!SAS3_VD_WWID[@]}"; do
        vd_wwid="${SAS3_VD_WWID[$vkey]}"; [[ -z "$vd_wwid" ]] && continue
        vd_os=$(_find_osdev_by_wwid "$vd_wwid" substr "/dev/disk/by-id/scsi-*" "/dev/disk/by-id/wwn-*")
        [[ -n "$vd_os" ]] && vd_osdev["$vkey"]="$vd_os"
    done
    for ckey in "${!SAS3_CTRL_BDF[@]}"; do
        bdf="${SAS3_CTRL_BDF[$ckey]}"
        fd=$(_first_sd_under_bdf "$bdf")
        [[ -n "$fd" ]] && ctrl_fallback["$ckey"]="$fd"
    done

    local keys; keys=$(printf '%s\n' "${!SAS3_SN[@]}" | sort -t'|' -k1,1n -k2,2V)
    local key ctrl eid_slt eid slt sn wwn model fw state size_mb size_sectors med
    local size_gb os_dev disk_type vendor disk_model disk_product pci_busid
    local pcie_slot_val raid_loc raid_mode bytes si sl vd_id vk vdm

    for key in $keys; do
        ctrl="${key%%|*}"; eid_slt="${key#*|}"
        eid="${eid_slt%%:*}"; slt="${eid_slt##*:}"
        sn="${SAS3_SN[$key]}"; wwn="${SAS3_WWN[$key]}"; model="${SAS3_MODEL[$key]}"
        fw="${SAS3_FW[$key]}"; state="${SAS3_STATE[$key]}"
        size_mb="${SAS3_SIZE_MB[$key]}"; size_sectors="${SAS3_SIZE_SECTORS[$key]}"
        med="${SAS3_MED[$key]}"
        raid_loc="C${ctrl}:E${eid}:S${slt}"

        # 已被 storcli 采过的盘直接跳过（混合机型）
        [[ -n "$sn" && -n "${SEEN[$sn]+x}" ]] && continue

        # 容量：优先扇区数（512B/扇区），其次 MB
        if [[ -n "$size_sectors" && "$size_sectors" =~ ^[0-9]+$ ]]; then
            bytes=$((10#$size_sectors * 512)); size_gb=$(bytes_to_gb_vendor "$bytes")
        elif [[ "$size_mb" =~ ^[0-9]+$ ]]; then
            size_gb=$((10#$size_mb / 1000))
        else
            size_gb="Unknown"
        fi
        [[ -z "$size_gb" || "$size_gb" == "0" ]] && size_gb="Unknown"

        # OS 设备：VD 映射 > 控制器兜底 > WWID/序列号反查
        os_dev=""
        vd_id="${SAS3_PD_TO_VD["${ctrl}|${eid}:${slt}"]:-}"
        [[ -n "$vd_id" ]] && os_dev="${vd_osdev["${ctrl}|${vd_id}"]:-}"
        [[ -z "$os_dev" ]] && os_dev="${ctrl_fallback[$ctrl]:-}"
        [[ -z "$os_dev" ]] && os_dev=$(_find_osdev_by_wwid "$wwn" substr "/dev/disk/by-id/scsi-*" "/dev/disk/by-id/wwn-*")

        case "$med" in
            *SSD*|*ssd*) disk_type="SSD" ;;
            *HDD*|*hdd*) disk_type="HDD" ;;
            *) disk_type="Unknown" ;;
        esac

        # 预取（父 shell 写缓存）
        if [[ -n "$os_dev" ]]; then
            smart_prefetch "$os_dev" a
            smart_prefetch "$os_dev" i
            [[ "$disk_type" == "NVMe" ]] && nvme_smart_prefetch "$os_dev"
        fi
        si=$(smart_text "$os_dev" a)
        sl=$(nvme_smart_text "$os_dev")

        size_gb=$(_round_to_nominal "$size_gb")

        vendor=$(get_vendor "$model"); disk_product=$(clean_product "$model")
        [[ -z "$disk_product" ]] && disk_product="$model"
        disk_model=$(resolve_model "$model" "$disk_product")

        raid_mode="SAS"
        if [[ -n "$vd_id" ]]; then
            vdm="${SAS3_VD_MODE["${ctrl}|${vd_id}"]:-}"
            [[ -n "$vdm" ]] && raid_mode="$vdm"
        fi

        health_fields "$si" "$sl" "$disk_type" "$os_dev"

        pci_busid=$(bdf_of_dev "$os_dev")
        pcie_slot_prefetch "$pci_busid"
        pcie_slot_val=$(pcie_slot_cached "$pci_busid")
        [[ -z "$wwn" ]] && wwn="N/A"

        emit_row "${sn:-loc:$raid_loc}" "$serial" "$disk_type" "$vendor" "$disk_model" "$disk_product" "$sn" \
                 "$size_gb" "$fw" "${os_dev:-N/A}" "$wwn" "$raid_mode" "$pci_busid" "$pcie_slot_val" \
                 "$raid_loc" "N/A" "N/A" "N/A" "N/A" "N/A" \
                 "$HEALTH_PH" "$HEALTH_LIFE" "$HEALTH_ERRORS"
        log_info "✓ $raid_loc sn=$sn, vendor=$vendor, model=$disk_model, product=$disk_product, size=${size_gb}GB, state=$state, mode=$raid_mode, dev=${os_dev:-N/A}, wwn=$wwn, err=$HEALTH_ERRORS"
    done
    return 0
}

# ============================================================================
# §15 arcconf 分支（Adaptec）
#   PD 以序列号为键；LD 相关映射以 "<ctrl>|<ld>" / "<ctrl>|<devnum>" 为键，
#   支持多控制器。
# ============================================================================

declare -A ADP_PD_STATE ADP_PD_MODEL ADP_PD_FW ADP_PD_SN
declare -A ADP_PD_WWN ADP_PD_SIZE_MB ADP_PD_LOC ADP_PD_TYPE ADP_PD_SSD
declare -A ADP_PD_POH ADP_PD_USAGE ADP_PD_RAID
declare -A ADP_PD_CHANNEL ADP_PD_DEVNUM ADP_PD_CTRL
declare -A ADP_LD_RAID ADP_LD_WWID ADP_LD_DEVNAME ADP_PD_TO_LD
declare -a ADP_CTRL_LIST=()            # 探测到的 Adaptec 控制器 BDF（排序后）
ADP_LOADED=false

# 枚举控制器编号：优先 arcconf GETVERSION 的 "Controllers found: N"，缺省按单控制器 1
_arcconf_controllers() {
    local cmd="$1" out n i
    out=$(run_cmd "arcconf.GETVERSION" -- $SUDO "$cmd" GETVERSION)
    n=$(printf '%s\n' "$out" | grep -oiE 'Controllers found[: ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
    if [[ ! "$n" =~ ^[0-9]+$ || "$n" -lt 1 ]]; then
        printf '1\n'
        return 0
    fi
    for ((i = 1; i <= n; i++)); do printf '%s\n' "$i"; done
    return 0
}

# 收集 Adaptec 控制器 BDF 并按 BDF 排序（arcconf 的编号顺序无从得知，
# 按排序后的次序做启发式对应，仅用于 pcie_slot 与兜底设备查找）
build_adaptec_ctrl_bdfs() {
    local c bdf vid pid family class sorted
    ADP_CTRL_LIST=()
    for c in "${STORAGE_CTRLS[@]}"; do
        IFS='|' read -r bdf vid pid family class <<< "$c"
        [[ "$family" == "adaptec" ]] && ADP_CTRL_LIST+=("$bdf")
    done
    [[ ${#ADP_CTRL_LIST[@]} -eq 0 ]] && return 0
    sorted=$(printf '%s\n' "${ADP_CTRL_LIST[@]}" | sort)
    ADP_CTRL_LIST=()
    while IFS= read -r bdf; do
        [[ -n "$bdf" ]] && ADP_CTRL_LIST+=("$bdf")
    done <<< "$sorted"
    return 0
}

# arcconf 控制器编号 -> BDF
_adaptec_ctrl_bdf() {
    local ctrl="$1" idx
    idx=$((ctrl - 1))
    if [[ $idx -ge 0 && $idx -lt ${#ADP_CTRL_LIST[@]} ]]; then
        printf '%s' "${ADP_CTRL_LIST[$idx]}"
    else
        printf 'N/A'
    fi
}

# 解析 arcconf GETCONFIG <ctrl> PD
_parse_arcconf_pd() {
    local out="$1" ctrl="$2" line
    local channel="" dev="" state="" model="" fw="" sn="" wwn="" size_mb="" loc=""
    local dtype="" ssd="" poh="" usage=""
    local in_pd=0

    # 一块 PD 结束（下一个 Channel/Device 或文本结束）时落库；
    # 序列号不可用、Enclosure Services 设备都不记
    _flush_pd() {
        [[ -z "$dev" ]] && return 0
        [[ -z "$sn" || "$sn" == "Not Available" ]] && return 0
        [[ "$dtype" == *"Enclosure Services"* ]] && return 0
        ADP_PD_STATE["$sn"]="$state"; ADP_PD_MODEL["$sn"]="$model"
        ADP_PD_FW["$sn"]="$fw"; ADP_PD_SN["$sn"]="$sn"; ADP_PD_WWN["$sn"]="$wwn"
        ADP_PD_SIZE_MB["$sn"]="$size_mb"; ADP_PD_LOC["$sn"]="$loc"; ADP_PD_TYPE["$sn"]="$dtype"
        ADP_PD_SSD["$sn"]="$ssd"; ADP_PD_POH["$sn"]="$poh"; ADP_PD_USAGE["$sn"]="$usage"
        ADP_PD_CHANNEL["$sn"]="$channel"; ADP_PD_DEVNUM["$sn"]="$dev"; ADP_PD_CTRL["$sn"]="$ctrl"
    }

    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*Channel[[:space:]]+#([0-9]+)[[:space:]]*: ]]; then
            _flush_pd; channel="${BASH_REMATCH[1]}"
            dev=""; state=""; model=""; fw=""; sn=""; wwn=""
            size_mb=""; loc=""; dtype=""; ssd=""; poh=""; usage=""
            in_pd=0; continue
        fi
        if [[ "$line" =~ ^[[:space:]]*Device[[:space:]]+#([0-9]+)[[:space:]]*$ ]]; then
            _flush_pd; dev="${BASH_REMATCH[1]}"
            state=""; model=""; fw=""; sn=""; wwn=""
            size_mb=""; loc=""; dtype=""; ssd=""; poh=""; usage=""
            in_pd=1; continue
        fi
        [[ $in_pd -eq 1 && -n "$dev" ]] || continue

        if   [[ "$line" =~ ^[[:space:]]*Device[[:space:]]+is[[:space:]]+a[n]?[[:space:]]+(.+)$ ]]; then dtype=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*State[[:space:]]*:[[:space:]]*(.+)$ ]]; then state=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Model[[:space:]]*:[[:space:]]*(.+)$ ]]; then model=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Firmware[[:space:]]*:[[:space:]]*(.+)$ ]]; then fw=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Serial[[:space:]]+number[[:space:]]*:[[:space:]]*(.+)$ ]]; then sn=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*World-wide[[:space:]]+name[[:space:]]*:[[:space:]]*(.+)$ ]]; then wwn=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Total[[:space:]]+Size[[:space:]]*:[[:space:]]*([0-9]+)[[:space:]]*MB ]]; then size_mb="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^[[:space:]]*Reported[[:space:]]+Location[[:space:]]*:[[:space:]]*(.+)$ ]]; then loc=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*SSD[[:space:]]*:[[:space:]]*(Yes|No) ]]; then ssd="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^[[:space:]]*Power[[:space:]]+On[[:space:]]+Hours[[:space:]]*:[[:space:]]*([0-9]+) ]]; then poh="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^[[:space:]]*Usage[[:space:]]+Remaining[[:space:]]*:[[:space:]]*([0-9]+)[[:space:]]*percent ]]; then usage="${BASH_REMATCH[1]}"
        fi
    done <<< "$out"
    _flush_pd
    return 0
}

# 解析 arcconf GETCONFIG <ctrl> LD：RAID 级别、LD wwid、/dev/sdX、成员 PD
_parse_arcconf_ld() {
    local out="$1" ctrl="$2" line
    local cur_ld="" cur_raid="" cur_wwid="" cur_devname="" in_ld=0
    local -a members=()

    _flush_ld() {
        [[ -z "$cur_ld" ]] && return 0
        local ck="${ctrl}|${cur_ld}" m
        [[ -n "$cur_raid"    ]] && ADP_LD_RAID["$ck"]="$cur_raid"
        [[ -n "$cur_wwid"    ]] && ADP_LD_WWID["$ck"]="$cur_wwid"
        [[ -n "$cur_devname" ]] && ADP_LD_DEVNAME["$ck"]="$cur_devname"
        for m in "${members[@]}"; do ADP_PD_TO_LD["${ctrl}|${m}"]="$cur_ld"; done
    }

    while IFS= read -r line; do
        if [[ "$line" =~ ^Logical[[:space:]]+Device[[:space:]]+number[[:space:]]+([0-9]+) ]]; then
            _flush_ld; cur_ld="${BASH_REMATCH[1]}"
            cur_raid=""; cur_wwid=""; cur_devname=""
            members=(); in_ld=1; continue
        fi
        [[ $in_ld -eq 1 ]] || continue

        if   [[ "$line" =~ ^[[:space:]]*Disk[[:space:]]+Name[[:space:]]*:[[:space:]]*(/dev/sd[a-z]+) ]]; then
            cur_devname="${BASH_REMATCH[1]}"; log_debug "  [LD$cur_ld] Disk Name = $cur_devname"
        elif [[ "$line" =~ ^[[:space:]]*RAID[[:space:]]+level[[:space:]]*:[[:space:]]*(.+)$ ]]; then cur_raid=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Volume[[:space:]]+Unique[[:space:]]+Identifier[[:space:]]*:[[:space:]]*(.+)$ ]]; then cur_wwid=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Unique[[:space:]]+Identifier[[:space:]]*:[[:space:]]*(.+)$ ]]; then cur_wwid=$(_trim "${BASH_REMATCH[1]}")
        elif [[ "$line" =~ ^[[:space:]]*Device[[:space:]]+([0-9]+)[[:space:]]*:[[:space:]]*Present ]]; then
            members+=("${BASH_REMATCH[1]}")
        fi
    done <<< "$out"
    _flush_ld

    log_debug "arcconf LD 映射: ld_raid=${#ADP_LD_RAID[@]}, ld_wwid=${#ADP_LD_WWID[@]}, ld_devname=${#ADP_LD_DEVNAME[@]}, pd_to_ld=${#ADP_PD_TO_LD[@]}"
    return 0
}

# 加载 arcconf 映射：逐控制器取 PD/LD，并用 LD 的 RAID 级别补齐每块盘的模式
load_adaptec_map() {
    [[ "$ADP_LOADED" == "true" ]] && return 0
    ADP_LOADED=true
    local arcconf_cmd ctrl pd_out ld_out
    arcconf_cmd=$(_find_arcconf)
    [[ -z "$arcconf_cmd" ]] && return 0

    while IFS= read -r ctrl; do
        [[ -z "$ctrl" ]] && continue
        pd_out=$(run_cmd "arcconf.GETCONFIG.${ctrl}.PD" -- $SUDO "$arcconf_cmd" GETCONFIG "$ctrl" PD)
        if [[ -n "$pd_out" ]]; then
            _parse_arcconf_pd "$pd_out" "$ctrl"
        else
            log_debug "arcconf 控制器 $ctrl 无 PD 输出"
        fi
        ld_out=$(run_cmd "arcconf.GETCONFIG.${ctrl}.LD" -- $SUDO "$arcconf_cmd" GETCONFIG "$ctrl" LD)
        [[ -n "$ld_out" ]] && _parse_arcconf_ld "$ld_out" "$ctrl"
    done < <(_arcconf_controllers "$arcconf_cmd")

    # 反向表 "<ctrl>|<devnum>" -> 序列号，供 PD→LD 补齐使用
    local -A dev_sn=()
    local sn_x k ck ld_num lvl
    for sn_x in "${!ADP_PD_DEVNUM[@]}"; do
        dev_sn["${ADP_PD_CTRL[$sn_x]:-}|${ADP_PD_DEVNUM[$sn_x]}"]="$sn_x"
    done
    for k in "${!ADP_PD_TO_LD[@]}"; do
        ck="${k%%|*}"; ld_num="${ADP_PD_TO_LD[$k]}"
        lvl="${ADP_LD_RAID["${ck}|${ld_num}"]:-}"
        [[ -z "$lvl" ]] && continue
        sn_x="${dev_sn[$k]:-}"
        [[ -n "$sn_x" && -z "${ADP_PD_RAID[$sn_x]:-}" ]] && ADP_PD_RAID["$sn_x"]="$lvl"
    done

    log_info "arcconf 加载 ${#ADP_PD_SN[@]} 块物理盘"
    return 0
}

# Adaptec 的 RAID 级别写法 -> disk_raid_mode
_adaptec_raid_level_to_mode() {
    case "$1" in
        "0"|"RAID 0"|"RAID0") echo "RAID0" ;;
        "1"|"RAID 1"|"RAID1") echo "RAID1" ;;
        "5"|"RAID 5"|"RAID5") echo "RAID5" ;;
        "6"|"RAID 6"|"RAID6") echo "RAID6" ;;
        "10"|"RAID 10"|"RAID10") echo "RAID10" ;;
        "50"|"RAID 50"|"RAID50") echo "RAID50" ;;
        "60"|"RAID 60"|"RAID60") echo "RAID60" ;;
        "Simple Volume"|"Simple") echo "JBOD" ;;
        "") : ;;
        *) echo "$1" ;;
    esac
}

# 输出 arcconf 分支的每一块物理盘
#   注意：POH/寿命直接取 arcconf 字段；errors 固定为 0 —— 这里的 disk_dev_name
#   是 LD 设备（多块 PD 共享同一个 /dev/sdX），对它取 SMART 会把逻辑卷的
#   SMART 重复算到每块 PD 上，反而失真。
collect_from_adaptec() {
    local serial="$1"
    local keys sn; keys=$(printf '%s\n' "${!ADP_PD_SN[@]}" | sort)

    for sn in $keys; do
        local state="${ADP_PD_STATE[$sn]:-}"
        local model_raw="${ADP_PD_MODEL[$sn]:-}"
        local fw="${ADP_PD_FW[$sn]:-N/A}"
        local wwn="${ADP_PD_WWN[$sn]:-N/A}"
        local size_mb="${ADP_PD_SIZE_MB[$sn]:-}"
        local loc="${ADP_PD_LOC[$sn]:-}"
        local dtype_raw="${ADP_PD_TYPE[$sn]:-}"
        local ssd_flag="${ADP_PD_SSD[$sn]:-}"
        local poh="${ADP_PD_POH[$sn]:-NA}"
        local usage="${ADP_PD_USAGE[$sn]:-NA}"
        local raid_lvl="${ADP_PD_RAID[$sn]:-}"
        local ch="${ADP_PD_CHANNEL[$sn]:-}"
        local dn="${ADP_PD_DEVNUM[$sn]:-}"
        local ctrl="${ADP_PD_CTRL[$sn]:-1}"
        local ctrl_bdf; ctrl_bdf=$(_adaptec_ctrl_bdf "$ctrl")

        local disk_dev_name="N/A"
        local ld_num="${ADP_PD_TO_LD["${ctrl}|${dn}"]:-}"

        # disk_dev_name 三级兜底：LD 的 Disk Name → LD wwid 反查 → 控制器下最小 sdX
        if [[ -n "$ld_num" ]]; then
            local ld_dev="${ADP_LD_DEVNAME["${ctrl}|${ld_num}"]:-}"
            [[ -n "$ld_dev" ]] && { disk_dev_name="$ld_dev"; log_debug "  AD-PD${dn} → LD${ld_num} → [1]Disk Name=$disk_dev_name"; }
        fi
        if [[ "$disk_dev_name" == "N/A" && -n "$ld_num" ]]; then
            local ld_wwid="${ADP_LD_WWID["${ctrl}|${ld_num}"]:-}"
            if [[ -n "$ld_wwid" ]]; then
                local os_dev; os_dev=$(_find_osdev_by_wwid "$ld_wwid" exact)
                [[ -n "$os_dev" ]] && { disk_dev_name="$os_dev"; log_debug "  AD-PD${dn} → LD${ld_num} → [2]wwid 反查=$disk_dev_name"; }
            fi
        fi
        if [[ "$disk_dev_name" == "N/A" && "$ctrl_bdf" != "N/A" ]]; then
            local fallback_dev; fallback_dev=$(_first_sd_under_bdf "$ctrl_bdf")
            [[ -n "$fallback_dev" ]] && { disk_dev_name="$fallback_dev"; log_debug "  AD-PD${dn} → [3]控制器兜底=$disk_dev_name"; }
        fi

        [[ -z "$sn" || "$sn" == "Not Available" ]] && continue

        local size_gb="Unknown"
        [[ "$size_mb" =~ ^[0-9]+$ ]] && size_gb=$(awk -v v="$size_mb" 'BEGIN { printf "%d", v * 0.001048576 + 0.5 }')

        local disk_type="Unknown"
        if [[ "$ssd_flag" == "Yes" ]]; then disk_type="SSD"
        elif [[ "$dtype_raw" == *"Solid State"* ]]; then disk_type="SSD"
        elif [[ "$dtype_raw" == *"Hard drive"* ]]; then disk_type="HDD"
        fi
        size_gb=$(_round_to_nominal "$size_gb")

        local disk_vendor disk_model disk_product
        disk_vendor=$(get_vendor "$model_raw")
        disk_product=$(clean_product "$model_raw"); [[ -z "$disk_product" ]] && disk_product="$model_raw"
        disk_model=$(resolve_model "$model_raw" "$disk_product")

        local raid_mode; raid_mode=$(_adaptec_raid_level_to_mode "$raid_lvl")
        if [[ -z "$raid_mode" ]]; then
            case "$state" in
                Online) raid_mode="RAID" ;;
                Ready)  raid_mode="Unconfigured(good)" ;;
                Failed) raid_mode="Unconfigured(bad)" ;;
                *) raid_mode="${state:-Unknown}" ;;
            esac
        fi

        local life_percent="NA"
        [[ "$usage" =~ ^[0-9]+$ ]] && life_percent="${usage}%"

        local pcie_slot_val="N/A"
        pcie_slot_prefetch "$ctrl_bdf"
        pcie_slot_val=$(pcie_slot_cached "$ctrl_bdf")

        emit_row "$sn" "$serial" "$disk_type" "$disk_vendor" "$disk_model" "$disk_product" "$sn" \
                 "$size_gb" "$fw" "$disk_dev_name" "$wwn" "$raid_mode" "$ctrl_bdf" "$pcie_slot_val" \
                 "C${ctrl}:PD${dn}" "N/A" "N/A" "N/A" "N/A" "N/A" \
                 "$poh" "$life_percent" "0"
        log_info "✓ AD-C${ctrl}:PD${dn} (ch${ch}, ${loc}): sn=$sn, vendor=$disk_vendor, model=$disk_model, size=${size_gb}GB, state=$state, mode=$raid_mode, dev=$disk_dev_name, fw=$fw, poh=$poh, life=$life_percent"
    done
    return 0
}

# ============================================================================
# §16 fallback 分支（lsblk + sysfs + smartctl）
#   用于没有 RAID/HBA 的机器，以及证明不了归属的盘；也负责补齐其它分支漏掉的盘。
# ============================================================================

# 从 /sys/block/<disk>/device 沿目录逐级向上，找第一个非桥（class != 0x0604）的
# PCI 设备，返回 "BDF|class"
find_upstream_pci_controller() {
    local device="$1" disk_name cur base cls
    disk_name=$(basename "$device")
    cur=$(_fs_readlink "/sys/block/$disk_name/device")
    [[ -z "$cur" ]] && return 1
    while [[ "$cur" != "/" && -n "$cur" ]]; do
        base=$(basename "$cur")
        if [[ "$base" =~ ^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
            cls=$(_fs_read "/sys/bus/pci/devices/$base/class" | tr -d ' \n')
            if [[ -n "$cls" && ! "$cls" =~ ^0x0604 ]]; then printf '%s|%s' "$base" "$cls"; return 0; fi
        fi
        cur=$(dirname "$cur")
    done
    return 1
}

# PCI class -> 控制器类型
class_to_ctrl_type() {
    case "$1" in
        0x0104*) echo "RAID" ;; 0x0106*) echo "SATA" ;;
        0x0107*) echo "SAS"  ;; 0x0108*) echo "NVMe" ;;
        *) echo "Unknown" ;;
    esac
}

# 返回 "<控制器类型>|<BDF>"，取不到则 "Unknown|Unknown"
get_upstream_ctrl_info() {
    local info; info=$(find_upstream_pci_controller "$1")
    [[ -z "$info" ]] && { printf 'Unknown|Unknown'; return 0; }
    printf '%s|%s' "$(class_to_ctrl_type "${info#*|}")" "${info%|*}"
}

# 从 /dev/disk/by-id/wwn-* 反查某设备的 WWN
get_disk_wwn() {
    local device="$1" link t
    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        [[ "$(basename "$link")" =~ -part[0-9]+$ ]] && continue
        t=$(_fs_readlink "$link")
        if [[ "$t" == "$device" ]]; then
            basename "$link" | sed 's/^wwn-//'
            return 0
        fi
    done < <(_fs_glob "/dev/disk/by-id/wwn-*")
    printf 'N/A'
}

# 序列号兜底链：sysfs serial → vpd_pg80 → smartctl -i → by-id 链接名 → WWN → UNKNOWN
_get_disk_serial() {
    local dev="$1" disk_name serial="" info link base raw
    [[ -z "$dev" ]] && { printf ''; return 0; }
    disk_name=$(basename "$dev")

    if _fs_exists "/sys/block/$disk_name/device/serial"; then
        serial=$(_norm_serial "$(_fs_read "/sys/block/$disk_name/device/serial")")
    fi
    [[ -n "$serial" && "$serial" != "0" ]] && { printf '%s' "$serial"; return 0; }

    if _fs_exists "/sys/block/$disk_name/device/vpd_pg80"; then
        raw=$(_fs_read "/sys/block/$disk_name/device/vpd_pg80")
        if command -v strings >/dev/null 2>&1; then
            serial=$(_norm_serial "$(printf '%s' "$raw" | strings 2>/dev/null | grep -vE '^[[:space:]]*$' | tail -1)")
        fi
        [[ -z "$serial" ]] && serial=$(_norm_serial "$(printf '%s' "$raw" | tr -cd '[:print:]')")
    fi
    [[ -n "$serial" && "$serial" != "0" ]] && { printf '%s' "$serial"; return 0; }

    info=$(smart_text "$dev" i)
    [[ -n "$info" ]] && serial=$(smart_serial_of "$info")
    [[ -n "$serial" && "$serial" != "0" ]] && { printf '%s' "$serial"; return 0; }

    [[ -n "$info" ]] && serial=$(_norm_serial "$(_field_val "$info" "^Logical Unit id:")" | sed 's/^0[xX]//')
    [[ -n "$serial" ]] && { printf '%s' "$serial"; return 0; }

    serial=$(_norm_serial "$(run_cmd "lsblk.d.n.SERIAL.$(_dev_key "$dev")" -- lsblk -d -n -o SERIAL "$dev")")
    [[ -n "$serial" && "$serial" != "0" ]] && { printf '%s' "$serial"; return 0; }

    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        [[ "$(_fs_readlink "$link")" == "$dev" ]] || continue
        base=$(basename "$link")
        case "$base" in
            wwn-*|scsi-3*|scsi-2*) ;;
            *)
                serial=$(printf '%s' "$base" | sed -E 's/^(scsi|ata|nvme)-//' | awk -F'_' '{print $NF}')
                [[ -n "$serial" ]] && break
                ;;
        esac
    done < <(_fs_glob "/dev/disk/by-id/*")
    [[ -n "$serial" && "$serial" != "0" ]] && { printf '%s' "$serial"; return 0; }

    while IFS= read -r link; do
        [[ -n "$link" ]] || continue
        if [[ "$(_fs_readlink "$link")" == "$dev" ]]; then
            serial="WWN_$(basename "$link" | sed 's/^wwn-//')"
            break
        fi
    done < <(_fs_glob "/dev/disk/by-id/wwn-*")
    [[ -n "$serial" ]] && { printf '%s' "$serial"; return 0; }
    printf 'UNKNOWN_%s' "$disk_name"
}

# ---- NVMe：id-ctrl / sysfs 解析（直接调用，结果写全局，避免 KEY=VALUE 往返）----
NVME_P_MODEL=""
NVME_P_SERIAL=""
NVME_P_FW=""
NVME_P_BYTES=""

# 解析 NVMe 的 id-ctrl 与容量，结果放 NVME_P_*（直接调用，父 shell 写全局）
nvme_scan() {
    local disk="$1" device="/dev/$disk" ctrl_device="$device" ctrl_info sectors
    NVME_P_MODEL=""; NVME_P_SERIAL=""; NVME_P_FW=""; NVME_P_BYTES=""

    [[ "$device" =~ ^(/dev/nvme[0-9]+)n[0-9]+$ ]] && ctrl_device="${BASH_REMATCH[1]}"
    ctrl_info=$(nvme_id_text "$ctrl_device")
    grep -qE '^mn[[:space:]]*:' <<< "$ctrl_info" || ctrl_info=$(nvme_id_text "$device")
    if [[ -n "$ctrl_info" ]]; then
        NVME_P_MODEL=$(_field_val "$ctrl_info" "^mn[[:space:]]*:")
        NVME_P_SERIAL=$(_field_val "$ctrl_info" "^sn[[:space:]]*:")
        NVME_P_FW=$(_field_val "$ctrl_info" "^fr[[:space:]]*:")
    fi

    if _fs_exists "/sys/block/$disk/size"; then
        sectors=$(_fs_read "/sys/block/$disk/size" | tr -d ' ')
        [[ "$sectors" =~ ^[0-9]+$ ]] && NVME_P_BYTES=$((sectors * 512))
    fi
    return 0
}

# RAID/SAS/SATA 上游时隐藏 PCIe 链路列（链路信息属于控制器，不属于单块盘）
should_hide_pcie() {
    case "$1" in RAID|SAS|SATA) return 0 ;; *) return 1 ;; esac
}

# 输出 fallback 分支的每一块盘
collect_from_fallback() {
    local serial="$1"
    log_info "通过 lsblk 获取磁盘列表（fallback 模式）..."
    local disks
    disks=$(run_cmd "lsblk.d.n.NAME,TYPE" -- lsblk -d -n -o NAME,TYPE | grep -E "disk|nvme" | awk '{print $1}')
    [[ -z "$disks" ]] && { log_warn "未找到任何磁盘设备"; return 1; }
    log_info "找到磁盘设备: $(printf '%s' "$disks" | tr '\n' ' ')"

    local disk device upstream_info upstream_ctrl upstream_bdf disk_wwn
    local raw_product disk_serial firmware size_raw size_gb_from_bytes size rotation_rate
    local disk_type product vendor disk_model si_i sl
    local pci_busid pcie_vid pcie_pid pcie_gen pcie_link_cap pcie_link_sta pcie_slot_val
    local raid_mode pci_vid_for_vendor up_vid ls_model ls_size sc ctrl_dev

    for disk in $disks; do
        device="/dev/$disk"
        log_debug "处理: $device"

        upstream_info=$(get_upstream_ctrl_info "$device")
        upstream_ctrl="${upstream_info%|*}"
        upstream_bdf="${upstream_info#*|}"
        disk_wwn=$(get_disk_wwn "$device")

        # 已被专门分支采过的盘直接跳过（按上游控制器类型判断）
        if [[ "$upstream_ctrl" == "RAID" && ${#MRAID_SN[@]} -gt 0 ]]; then
            log_debug "跳过 RAID 上游设备 $device（已由 storcli 处理）"; continue
        fi
        if [[ "$upstream_ctrl" == "SAS" && ${#SAS3_SN[@]} -gt 0 ]]; then
            log_debug "跳过 SAS 上游设备 $device（已由 sas3ircu 处理）"; continue
        fi
        if [[ ${#ADP_PD_SN[@]} -gt 0 && -n "$upstream_bdf" && "$upstream_bdf" != "Unknown" ]]; then
            up_vid=$(get_pcie_vid "$upstream_bdf")
            if [[ "$up_vid" == "9005" ]]; then
                log_debug "跳过 Adaptec 上游设备 $device（BDF=$upstream_bdf, VID=9005）"; continue
            fi
        fi

        raw_product=""; disk_serial=""; firmware=""; size_raw=""; size_gb_from_bytes=""; rotation_rate=""

        # ---- 预取 SMART/NVMe（父 shell 写缓存）----
        smart_prefetch "$device" a
        smart_prefetch "$device" i
        if [[ "$disk" =~ ^nvme[0-9]+ ]]; then
            ctrl_dev="$device"
            [[ "$device" =~ ^(/dev/nvme[0-9]+)n[0-9]+$ ]] && ctrl_dev="${BASH_REMATCH[1]}"
            nvme_id_prefetch "$ctrl_dev"
            [[ "$ctrl_dev" != "$device" ]] && nvme_id_prefetch "$device"
            nvme_smart_prefetch "$device"
        fi

        # ---- 型号/序列号/固件/容量：NVMe → smartctl -i → lsblk ----
        if [[ "$disk" =~ ^nvme[0-9]+ ]]; then
            nvme_scan "$disk"
            [[ -n "$NVME_P_MODEL"  ]] && raw_product="$NVME_P_MODEL"
            [[ -n "$NVME_P_SERIAL" ]] && disk_serial="$NVME_P_SERIAL"
            [[ -n "$NVME_P_FW"     ]] && firmware="$NVME_P_FW"
            if [[ -n "$NVME_P_BYTES" && "$NVME_P_BYTES" =~ ^[0-9]+$ ]]; then
                size_gb_from_bytes=$(bytes_to_gb_vendor "$NVME_P_BYTES")
                size_raw="${NVME_P_BYTES} bytes"
            fi
        fi

        si_i=$(smart_text "$device" i)
        if [[ -n "$si_i" ]]; then
            [[ -z "$raw_product" ]] && raw_product=$(_field_val "$si_i" "Device Model:")
            [[ -z "$raw_product" ]] && raw_product=$(_field_val "$si_i" "Model Number:")
            [[ -z "$raw_product" ]] && raw_product=$(_field_val "$si_i" "^Product:")
            [[ -z "$disk_serial" ]] && disk_serial=$(smart_serial_of "$si_i")
            [[ -z "$firmware" ]] && firmware=$(_field_val "$si_i" "Firmware Version:")
            [[ -z "$firmware" ]] && firmware=$(_field_val "$si_i" "^Revision:")
            [[ -z "$size_raw" ]] && size_raw=$(_field_val "$si_i" "User Capacity:")
            [[ -z "$rotation_rate" ]] && rotation_rate=$(_field_val "$si_i" "Rotation Rate:")
        fi
        raw_product=$(_trim "$raw_product")
        firmware=$(_trim "$firmware")
        disk_serial=$(_trim "$disk_serial")

        if [[ -z "$disk_serial" || "$disk_serial" == "None" || "$disk_serial" == "N/A" ]]; then
            disk_serial=$(_get_disk_serial "$device")
        fi
        if [[ -z "$raw_product" ]]; then
            ls_model=$(run_cmd "lsblk.d.n.MODEL.$(_dev_key "$device")" -- lsblk -d -n -o MODEL "$device")
            raw_product=$(_trim "$ls_model")
        fi
        [[ -z "$disk_serial" || "$disk_serial" == "None" || "$disk_serial" == "N/A" ]] && disk_serial="UNKNOWN_${disk}"

        if [[ -n "${SEEN[$disk_serial]+x}" ]]; then
            log_debug "设备 $device (sn=$disk_serial) 已采集，跳过"; continue
        fi

        disk_type=$(get_disk_type "$raw_product" "$rotation_rate" "$disk")
        product=$(clean_product "$raw_product")

        # ---- 容量 ----
        if [[ -n "$size_gb_from_bytes" ]]; then
            size="$size_gb_from_bytes"
        else
            size=$(convert_size_to_gb "$size_raw")
        fi
        if [[ -z "$size" || "$size" == "0" || "$size" == "$size_raw" ]]; then
            if [[ "$disk" =~ ^nvme[0-9]+ ]]; then
                if _fs_exists "/sys/block/$disk/size"; then
                    sc=$(_fs_read "/sys/block/$disk/size" | tr -d ' ')
                    [[ "$sc" =~ ^[0-9]+$ ]] && size=$(bytes_to_gb_vendor "$((sc * 512))")
                fi
            else
                ls_size=$(run_cmd "lsblk.d.n.SIZE.$(_dev_key "$device")" -- lsblk -d -n -o SIZE "$device")
                ls_size=$(_trim "$ls_size")
                [[ -n "$ls_size" ]] && size=$(convert_gib_to_gb "$ls_size")
            fi
        fi
        [[ -z "$size" || "$size" == "0" ]] && size="Unknown"
        size=$(_round_to_nominal "$size")

        # ---- 健康度 ----
        sl=$(nvme_smart_text "$device")
        health_fields "$(smart_text "$device" a)" "$sl" "$disk_type" "$device"

        # ---- 厂商/型号/PCIe ----
        pci_busid=$(bdf_of_dev "$device")
        pci_vid_for_vendor=""
        if ! should_hide_pcie "$upstream_ctrl"; then
            pci_vid_for_vendor=$(get_pcie_vid "$pci_busid")
            [[ "$pci_vid_for_vendor" == "N/A" ]] && pci_vid_for_vendor=""
        fi
        vendor=$(get_vendor "$raw_product" "$pci_vid_for_vendor")
        log_debug "  vendor=$vendor (model=$raw_product, pci_vid=${pci_vid_for_vendor:-<empty>})"
        disk_model=$(resolve_model "$raw_product" "$product")

        pcie_slot_val="N/A"
        if should_hide_pcie "$upstream_ctrl"; then
            pcie_vid="N/A"; pcie_pid="N/A"; pcie_gen="N/A"; pcie_link_cap="N/A"; pcie_link_sta="N/A"
        else
            lspci_lnk_prefetch "$pci_busid"
            pcie_vid=$(get_pcie_vid "$pci_busid")
            pcie_pid=$(get_pcie_pid "$pci_busid")
            pcie_gen=$(get_pcie_gen "$pci_busid")
            pcie_link_cap=$(get_pcie_link_cap "$pci_busid")
            pcie_link_sta=$(get_pcie_link_sta "$pci_busid")
            pcie_slot_prefetch "$pci_busid"
            pcie_slot_val=$(pcie_slot_cached "$pci_busid")
        fi

        case "$upstream_ctrl" in
            NVMe) raid_mode="N/A" ;;
            *)    raid_mode="$upstream_ctrl" ;;
        esac

        emit_row "$disk_serial" "$serial" "$disk_type" "$vendor" "$disk_model" "$product" "$disk_serial" \
                 "$size" "$firmware" "$device" "$disk_wwn" "$raid_mode" "$pci_busid" \
                 "$pcie_slot_val" "N/A" "$pcie_vid" "$pcie_pid" "$pcie_gen" \
                 "$pcie_link_cap" "$pcie_link_sta" "$HEALTH_PH" "$HEALTH_LIFE" "$HEALTH_ERRORS"
        log_info "✓ $device: vendor=$vendor, model=$disk_model, product=$product, serial=$disk_serial, size=${size}GB, mode=$raid_mode, ph=$HEALTH_PH, life=$HEALTH_LIFE, err=$HEALTH_ERRORS"
    done
    return 0
}

# 系统序列号：dmidecode → /sys/class/dmi/id/product_serial → UNKNOWN
get_system_serial() {
    local s
    s=$(run_cmd "dmidecode.system-serial-number" -- $SUDO dmidecode -s system-serial-number | head -1)
    s=$(_trim "$s")
    [[ -n "$s" && "$s" != "Not Specified" && "$s" != "Unknown" ]] && { printf '%s' "$s"; return 0; }
    s=$(_trim "$(_fs_read /sys/class/dmi/id/product_serial)")
    [[ -n "$s" && "$s" != "Not Specified" ]] && { printf '%s' "$s"; return 0; }
    printf 'UNKNOWN'
}

# ============================================================================
# §17 主流程与输出
# ============================================================================

# 调度：Adaptec → LSI(storcli / sas3ircu) → Marvell → fallback 补齐
collect_all_disk_info() {
    local serial="$1" c bdf vid pid family class gen

    detect_storage_controllers
    load_pci_slot_map
    load_disk_paths

    if [[ ${#STORAGE_CTRLS[@]} -eq 0 ]]; then
        log_info "未检测到 RAID/HBA 控制器，直接走 fallback"
        collect_from_fallback "$serial"
        return 0
    fi

    log_info "检测到 ${#STORAGE_CTRLS[@]} 个 RAID/HBA 控制器"
    for c in "${STORAGE_CTRLS[@]}"; do
        IFS='|' read -r bdf vid pid family class <<< "$c"
        log_info "  · BDF=$bdf, VID=$vid, PID=$pid, family=$family, class=$class"
    done

    # ---------------- ① Adaptec ----------------
    if have_storage_vendor adaptec; then
        local acmd; acmd=$(_find_arcconf)
        if [[ -n "$acmd" ]]; then
            log_info "========== Adaptec 分支（arcconf）=========="
            build_adaptec_ctrl_bdfs
            load_adaptec_map
            if [[ ${#ADP_PD_SN[@]} -gt 0 ]]; then
                collect_from_adaptec "$serial"
            else
                log_warn "arcconf 未枚举到物理盘"
            fi
        else
            log_warn "检测到 Adaptec 控制器，但未安装 arcconf，跳过"
        fi
    fi

    # ---------------- ② LSI / Broadcom ----------------
    local -a lsi_sas3_bdfs=() lsi_sas4_bdfs=() lsi_sas2_bdfs=() lsi_unknown_bdfs=()
    if have_storage_vendor lsi; then
        # 先按 BDF 判定每张卡的 SAS 代数（P1-2）
        for c in "${STORAGE_CTRLS[@]}"; do
            IFS='|' read -r bdf vid pid family class <<< "$c"
            [[ "$family" == "lsi" ]] || continue
            gen=$(lsi_gen_of_bdf "$bdf" "$pid")
            case "$gen" in
                sas3) lsi_sas3_bdfs+=("$bdf") ;;
                sas4) lsi_sas4_bdfs+=("$bdf") ;;
                sas2) lsi_sas2_bdfs+=("$bdf") ;;
                *)    lsi_unknown_bdfs+=("$bdf") ;;
            esac
            log_debug "  LSI $bdf → $gen"
        done

        # storcli 是全局的，一次覆盖所有 MegaRAID
        local storcli_cmd; storcli_cmd=$(_find_storcli)
        if [[ -n "$storcli_cmd" ]]; then
            log_info "========== LSI/Broadcom 分支（storcli64 / MegaRAID）=========="
            load_megaraid_map
            load_vd_map
            if [[ ${#MRAID_SN[@]} -gt 0 ]]; then
                collect_from_storcli "$serial"
            else
                log_warn "storcli 未枚举到物理盘"
            fi
        else
            log_warn "未找到 storcli64/storcli"
        fi

        # sas3ircu 目标：
        #   ① class=0x0107（SAS HBA）的 SAS3 卡：sas3ircu 是对的工具
        #   ② class=0x0104（MegaRAID）由 storcli 负责，避免白跑一次 + 超时风险
        #   ③ 只有 storcli 一块盘都没拿到时，才把"代数未知"的卡交给它兜底
        # F-1：③ 必须同样排除 class=0x0104 —— 否则一张判不出代数的 MegaRAID 卡
        #      在 storcli 不可用时仍会被丢给 sas3ircu（v60 明确要避免的场景），
        #      白白等一个 CMD_TIMEOUT。MegaRAID 卡最终由 fallback 的 lsblk 兜住。
        local -a sas3_targets=()
        local b cls
        for b in "${lsi_sas3_bdfs[@]}"; do
            cls=$(_ctrl_class_of "$b")
            [[ "$cls" == 0x0104* ]] && continue
            sas3_targets+=("$b")
        done
        if [[ ${#MRAID_SN[@]} -eq 0 && ${#sas3_targets[@]} -eq 0 ]]; then
            local -a unknown_targets=()
            for b in "${lsi_unknown_bdfs[@]}"; do
                cls=$(_ctrl_class_of "$b")
                [[ "$cls" == 0x0104* ]] && { log_debug "跳过 0x0104 卡（MegaRAID 不归 sas3ircu 管）: $b"; continue; }
                unknown_targets+=("$b")
            done
            if [[ ${#unknown_targets[@]} -gt 0 ]]; then
                sas3_targets=("${unknown_targets[@]}")
                log_debug "storcli 无结果，兜底尝试 sas3ircu: ${sas3_targets[*]}"
            fi
        fi

        if [[ ${#sas3_targets[@]} -gt 0 ]]; then
            local sas3_cmd; sas3_cmd=$(_find_sas3ircu)
            if [[ -n "$sas3_cmd" ]]; then
                log_info "========== LSI/Broadcom 分支（sas3ircu，SAS3 BDF: ${sas3_targets[*]}）=========="
                load_sas3ircu_map
                if [[ ${#SAS3_SN[@]} -gt 0 ]]; then
                    collect_from_sas3ircu "$serial"
                else
                    log_warn "sas3ircu 未枚举到物理盘"
                fi
            else
                log_warn "检测到 SAS3 HBA，但未安装 sas3ircu，跳过"
            fi
        fi

        # F-2：SAS4 告警按 PCI class 区分措辞。
        #   在 MegaRAID(0x0104) 上，"sas4" 指的是 RAID 卡芯片（如 SAS39xx），
        #   它由 storcli64 正常采集，说"当前脚本不支持 / 建议改用 storcli64"
        #   是错的，只会误导使用者。只有 0x0107（SAS HBA）才是"不支持"。
        if [[ ${#lsi_sas4_bdfs[@]} -gt 0 ]]; then
            local -a sas4_hba=() sas4_raid=()
            for b in "${lsi_sas4_bdfs[@]}"; do
                cls=$(_ctrl_class_of "$b")
                if [[ "$cls" == 0x0104* ]]; then sas4_raid+=("$b"); else sas4_hba+=("$b"); fi
            done
            if [[ ${#sas4_raid[@]} -gt 0 ]]; then
                # MegaRAID：走 storcli64，属于正常路径，不需要"不支持"告警
                log_info "SAS4 代 RAID 卡（MegaRAID，由 storcli64 采集）: ${sas4_raid[*]}"
            fi
            if [[ ${#sas4_hba[@]} -gt 0 ]]; then
                log_warn "═══════════════════════════════════════════════════"
                log_warn "检测到 SAS4（24Gb/s）HBA，sas3ircu 不支持：${sas4_hba[*]}"
                log_warn "  · 已安全跳过 sas3ircu，这些卡上的盘将由 lsblk 兜底"
                log_warn "  · 若要可靠的 RAID/直通信息，建议改用 storcli64 或装 sas4ircu"
                log_warn "═══════════════════════════════════════════════════"
            fi
        fi
        if [[ ${#lsi_sas2_bdfs[@]} -gt 0 ]]; then
            log_warn "检测到 SAS2（6Gb/s）HBA，本脚本不支持 sas2ircu，跳过：${lsi_sas2_bdfs[*]}"
        fi
    fi

    # ---------------- ③ Marvell ----------------
    if have_storage_vendor marvell; then
        if [[ "$MOCK_MODE" == "true" ]] || command -v mvcli >/dev/null 2>&1; then
            log_info "========== Marvell 分支（mvcli）=========="
            local mvout; mvout=$(run_cmd "mvcli.info.o.hba" -- $SUDO mvcli info -o hba)
            if [[ -n "$mvout" ]]; then
                [[ "$QUIET" == "true" ]] || printf '%s\n' "$mvout"
            else
                log_warn "mvcli 无输出（未安装或未枚举到 HBA）"
            fi
        else
            log_warn "检测到 Marvell 控制器，但未安装 mvcli，跳过"
        fi
    fi

    # ---------------- ④ fallback 补齐 ----------------
    collect_from_fallback "$serial"
    return 0
}

TMP_FILES=()

# 退出时清理临时文件
cleanup() {
    local f
    for f in "${TMP_FILES[@]}"; do
        [[ -n "$f" && -f "$f" ]] && rm -f "$f"
    done
    # mock 缺失记录（命令层 / 文件层）
    [[ -n "$MOCK_MISS_FILE" && -f "$MOCK_MISS_FILE" ]] && rm -f "$MOCK_MISS_FILE"
    [[ -n "$MOCK_FS_MISS_FILE" && -f "$MOCK_FS_MISS_FILE" ]] && rm -f "$MOCK_FS_MISS_FILE"
    return 0
}

# 把暂存结果排序后落成最终 CSV（表头 + 按 serial/dev 排序的行）
finalize_output() {
    local rec=0
    {
        printf '%s\n' "$CSV_HEADER"
        [[ -s "$ROWS_FILE" ]] && sort -t$'\t' -k1,1 -k2,2 "$ROWS_FILE" | cut -f3-
    } > "$OUTPUT_FILE"
    rec=$(wc -l < "$OUTPUT_FILE")
    rec=$((rec - 1))
    (( rec < 0 )) && rec=0
    printf '%s' "$rec"
}

# 主流程：检查环境 → 定位输出 → 采集 → 落盘 → 汇总退出码
main() {
    print_separator
    printf '%s服务器硬盘信息收集工具 v%s%s\n' "$GREEN" "$SCRIPT_VERSION" "$NC"
    print_separator

    if [[ "$MOCK_MODE" == "true" ]]; then
        if [[ ! -d "$MOCK_DIR" ]]; then
            log_error "mock 目录不存在: $MOCK_DIR"
            return 2
        fi
        load_mock_links
        log_info "🧪 Mock 模式: MOCK_DIR=$MOCK_DIR (strict=${MOCK_STRICT})"
    elif [[ "$MOCK_STRICT" == "true" ]]; then
        log_warn "--mock-strict 只在 mock 模式下生效"
    fi

    check_deps || return 1
    TIMEOUT_BIN=$(command -v timeout 2>/dev/null)
    [[ -z "$TIMEOUT_BIN" ]] && log_warn "未找到 timeout：外部命令的超时保护失效（smartctl/arcconf 卡住时会一起挂住）"

    ensure_sudo || return 1
    log_info "执行用户: $(id -un) (UID=$(id -u)), SUDO='${SUDO:-<empty>}'"
    log_info "脚本目录: $SCRIPT_DIR"
    log_info "输出目录: $OUTPUT_DIR"

    # ★ P0-1：-s 指定过就不再自动探测
    if [[ -z "$SYSTEM_SERIAL" ]]; then
        SYSTEM_SERIAL=$(get_system_serial)
    else
        log_info "使用 -s/--serial 指定的系统序列号"
    fi
    log_info "系统序列号: $SYSTEM_SERIAL"

    local safe_serial; safe_serial=$(sanitize_name "$SYSTEM_SERIAL")
    # F-5：sanitize_name 现在返回 "<清洗后的序列号>_<8 位校验和>"，
    #      未探测到序列号时返回 "UNKNOWN_<校验和>"，故用前缀判断
    if [[ "$safe_serial" == UNKNOWN_* ]]; then
        OUTPUT_FILE="${OUTPUT_DIR}/disk_info.csv"
    else
        OUTPUT_FILE="${OUTPUT_DIR}/disk_info_${safe_serial}.csv"
    fi

    [[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR" 2>/dev/null || { log_error "无法创建 $OUTPUT_DIR"; return 1; }

    ROWS_FILE=$(mktemp "${OUTPUT_DIR}/.disk_rows.XXXXXX") || { log_error "无法创建临时文件"; return 1; }
    TMP_FILES+=("$ROWS_FILE")

    collect_all_disk_info "$SYSTEM_SERIAL"

    local rec; rec=$(finalize_output)

    print_separator
    printf '%s✅ 完成！%s\n' "$GREEN" "$NC"
    print_separator
    printf '📁 输出文件: %s%s%s\n' "$BLUE" "$OUTPUT_FILE" "$NC"
    printf '📊 硬盘记录: %s%s%s 条\n' "$BLUE" "$rec" "$NC"
    print_separator

    if [[ "$QUIET" != "true" && "$rec" -gt 0 ]]; then
        cat "$OUTPUT_FILE"
        print_separator
    fi

    # --mock-strict：汇总缺失的 mock 命令 key
    if [[ "$MOCK_MODE" == "true" && "$MOCK_STRICT" == "true" && -n "$MOCK_MISS_FILE" && -s "$MOCK_MISS_FILE" ]]; then
        local k
        local -a misses=()
        while IFS= read -r k; do misses+=("$k"); done < <(sort -u "$MOCK_MISS_FILE")
        log_error "mock 缺失 ${#misses[@]} 个 key:"
        for k in "${misses[@]}"; do log_error "  · $k"; done
        log_error "请补齐 mock 数据，或去掉 --mock-strict"
        return 4
    fi

    # F-8：文件层的未命中【只提示不报错】。
    #   脚本会合法地探测大量不存在的路径（各种可选 sysfs 节点、多个 -d 变体、
    #   可选的 links.tsv 等），把它们判为失败会让 --mock-strict 永远返回 4。
    #   但 0 条记录时，这份清单能立刻区分"夹具没搭"与"逻辑就是没采到"。
    if [[ "$MOCK_STRICT" == "true" && -n "$MOCK_FS_MISS_FILE" && -s "$MOCK_FS_MISS_FILE" ]]; then
        local -a fsmiss=()
        while IFS= read -r k; do fsmiss+=("$k"); done < <(sort -u "$MOCK_FS_MISS_FILE")
        local n=${#fsmiss[@]}
        if (( rec == 0 )); then
            log_error "mock 文件层未命中 $n 项（0 条记录时通常说明夹具不完整）："
            for k in "${fsmiss[@]}"; do log_error "  · $k"; done
        else
            log_info "mock 文件层未命中 $n 项（多数是可选探测，正常）：${fsmiss[0]} …"
            for k in "${fsmiss[@]}"; do log_debug "  fs miss: $k"; done
        fi
    fi

    (( rec == 0 )) && { log_warn "没有采集到任何硬盘记录"; return 3; }
    return 0
}

# ============================================================================
# §18 自测（--test，F-10）
#   只测【纯函数】：不访问 /sys、不跑外部命令、不需要 root、不需要真机。
#   目的是把最容易悄悄改坏、又最难在真机上发现的核心逻辑钉住：
#     容量换算 / 标称对齐 / SAS 代数判定 / CSV 转义与列数 / 序列号归一化 /
#     去重键 / PCI 地址与 BDF 提取 / SMART 数值解析
#   任何一种模式（--mock-dir）都不影响本节。
# ============================================================================

TEST_PASS=0
TEST_FAIL=0

# _assert_eq <说明> <期望> <实际>
_assert_eq() {
    local desc="$1" want="$2" got="$3"
    if [[ "$want" == "$got" ]]; then
        TEST_PASS=$((TEST_PASS + 1))
        printf '  %s✓%s %s\n' "$GREEN" "$NC" "$desc"
    else
        TEST_FAIL=$((TEST_FAIL + 1))
        printf '  %s✗%s %s\n' "$RED" "$NC" "$desc" >&2
        printf '      期望: [%s]\n' "$want" >&2
        printf '      实际: [%s]\n' "$got" >&2
    fi
}

# CSV 表头列数必须与 CSV_COLUMNS 一致（防呆：改表头忘了改常量）
# 注意：字段数 = 分隔符数 + 1。直接 `tr ',' '\n' | wc -l` 数的是【逗号个数】，
#       会永远比真实列数少 1 —— 首版自测就踩了这个坑。
_test_csv_header_columns() {
    local ncommas nfields
    ncommas=$(printf '%s' "$CSV_HEADER" | tr -cd ',' | wc -c)
    ncommas=${ncommas//[!0-9]/}
    nfields=$((ncommas + 1))
    _assert_eq "CSV 表头字段数 == CSV_COLUMNS($CSV_COLUMNS)" "$CSV_COLUMNS" "$nfields"

    # 同时验证：按逗号拆开后正好 CSV_COLUMNS 个字段。
    # ★ 必须用带守卫的 while read（`|| [[ -n $f ]]`）：`printf '%s' | tr ',' '\n'`
    #   的最后一段【没有换行符】，而 `read` 遇到无换行的末行会返回非 0，
    #   普通 `while read; do ...; done` 会直接丢掉最后一个字段（22 → 21）。
    local -a hdr=()
    local f
    while IFS= read -r f || [[ -n "$f" ]]; do hdr+=("$f"); done < <(printf '%s' "$CSV_HEADER" | tr ',' '\n')
    _assert_eq "CSV 表头拆分后的字段数" "$CSV_COLUMNS" "${#hdr[@]}"
}

_test_sizes() {
    # smartctl 口径（十进制）：真实取值来自 report.html
    _assert_eq "dec: 480,103,981,056 bytes [480 GB] → 480" "480" "$(convert_size_to_gb '480,103,981,056 bytes [480 GB]')"
    _assert_eq "dec: 7,681,501,126,656 bytes [7.68 TB] → 7680" "7680" "$(convert_size_to_gb '7,681,501,126,656 bytes [7.68 TB]')"
    _assert_eq "dec: 240 GB → 240" "240" "$(convert_size_to_gb '240 GB')"
    _assert_eq "dec: 前导 0 不触发八进制 (099)" "99" "$(_dec '099')"

    # storcli / lsblk 口径（二进制）
    _assert_eq "bin: 1.090 TB → 1198" "1198" "$(convert_gib_to_gb '1.090 TB')"
    _assert_eq "bin: 465.8G → 500" "500" "$(convert_gib_to_gb '465.8G')"
    _assert_eq "bin: 447.13GiB → 480" "480" "$(convert_gib_to_gb '447.13GiB')"
    _assert_eq "bin: 76.8TB → 84442" "84442" "$(convert_gib_to_gb '76.8TB')"

    # 解析不了时原样返回，不能变成空串
    _assert_eq "无法解析时原样返回" "weird" "$(convert_size_to_gb 'weird')"
    _assert_eq "空输入返回空" "" "$(convert_size_to_gb '')"
}

_test_nominal() {
    # ★ 容差是 4%（NOMINAL_TOL），且每项都要真正落在容差内才会被贴档。
    #   写断言前先算清楚，不要凭"应该能贴上"的直觉：
    #     |465-480|/480 = 3.13%  ✓ 贴 480
    #     |457-480|/480 = 4.79%  ✗ 超出 4% → 原样保留 457
    #     |447-480|/480 = 6.88%  ✗ 超出 4% → 原样保留 447
    #   （首版断言把 447 写成贴 480，就是没算容差；真机才暴露）
    _assert_eq "465 → 480（3.13%，在 4% 容差内）" "480" "$(_round_to_nominal 465)"
    _assert_eq "476 → 480"   "480"  "$(_round_to_nominal 476)"
    _assert_eq "457 → 457（4.79% 超 4% 容差，原样保留）" "457" "$(_round_to_nominal 457)"
    _assert_eq "447 → 447（6.88% 超容差，原样保留）" "447" "$(_round_to_nominal 447)"
    _assert_eq "894 → 894（6.88% 超容差不动）" "894" "$(_round_to_nominal 894)"
    _assert_eq "7681 → 7680" "7680" "$(_round_to_nominal 7681)"
    _assert_eq "3726 → 3840（2.97%，在容差内；4TB 盘的 GiB 口径）" "3840" "$(_round_to_nominal 3726)"
    _assert_eq "非数字原样返回" "Unknown" "$(_round_to_nominal Unknown)"

    # --- ★ 容差 4% 的核心作用：不向下贴 ---
    # 物理事实：厂商标称 ≥ 实际，所以"标称 240 而实际 250"不可能出现。
    # 5% 容差会把 250 下贴到 240（4.17%），正是这种不可能的情况；4% 挡住了它。
    _assert_eq "250 → 250（4.17% > 4%，不得下贴到 240）" "250" "$(_round_to_nominal 250)"
    _assert_eq "500 → 500（4.17% > 4%，不得下贴到 480）" "500" "$(_round_to_nominal 500)"
    _assert_eq "256 → 256（6.67%，不得下贴）" "256" "$(_round_to_nominal 256)"
    _assert_eq "512 → 512（不得下贴到 480）" "512" "$(_round_to_nominal 512)"
    # 另一侧的上界：容差不能紧到 3%，否则 1.6TB 盘（lsblk "1.5T"→1649）贴不上
    _assert_eq "1649 → 1600（3.06%，最紧的企业档；容差须 > 3.06%）" "1600" "$(_round_to_nominal 1649)"

    # --- 企业档位（F-9 定稿后的表）---
    _assert_eq "238 → 240" "240" "$(_round_to_nominal 238)"
    _assert_eq "1024 → 1024（TiB 整档）" "1024" "$(_round_to_nominal 1024)"
    _assert_eq "375 → 375（Optane）" "375" "$(_round_to_nominal 375)"
    # 26TB 是真实误判修复：旧表无 26000 → 被 25600 抢走
    _assert_eq "26005 → 26000（26TB，旧表误判为 25600）" "26000" "$(_round_to_nominal 26005)"
    _assert_eq "28006 → 28000（28TB，旧表无此档）" "28000" "$(_round_to_nominal 28006)"
    # 1500 必须存在：否则 1.5TB Optane 会被 1600 抢走
    _assert_eq "1539 → 1500（Optane，旧表被 1600 抢走）" "1500" "$(_round_to_nominal 1539)"

    # --- ★ 端到端：必须连 _size_to_gb 一起跑 ★ ---
    # 历史教训：审计时我曾把 16764(GiB) 直接喂给 _round_to_nominal，
    # 跳过了单位换算，据此误判"18TB 会被 16384 抢走"。真实输入是 18032。
    # 下面这些断言覆盖"工具原文 → 换算 → 贴档"的完整链路。
    _assert_eq "e2e lsblk 447.1G → 480（480GB SSD）" \
        "480" "$(_round_to_nominal "$(convert_gib_to_gb '447.1G')")"
    _assert_eq "e2e lsblk 223.6G → 240（240GB SSD）" \
        "240" "$(_round_to_nominal "$(convert_gib_to_gb '223.6G')")"
    _assert_eq "e2e lsblk 894.2G → 960（960GB SSD）" \
        "960" "$(_round_to_nominal "$(convert_gib_to_gb '894.2G')")"
    _assert_eq "e2e lsblk 3.6T → 4000（4TB HDD）" \
        "4000" "$(_round_to_nominal "$(convert_gib_to_gb '3.6T')")"
    # 18TB：GiB 值换算后是 18032，离 18000 只有 0.18%，不会被 16384 抢走
    _assert_eq "e2e lsblk 16.4T → 18000（18TB，不得撞 16384）" \
        "18000" "$(_round_to_nominal "$(convert_gib_to_gb '16.4T')")"
    _assert_eq "e2e lsblk 12.7T → 14000（14TB）" \
        "14000" "$(_round_to_nominal "$(convert_gib_to_gb '12.7T')")"
    _assert_eq "e2e lsblk 23.7T → 26000（26TB，旧表误判为 25600）" \
        "26000" "$(_round_to_nominal "$(convert_gib_to_gb '23.7T')")"
    _assert_eq "e2e lsblk 349.3G → 375（Optane）" \
        "375" "$(_round_to_nominal "$(convert_gib_to_gb '349.3G')")"
    _assert_eq "e2e smartctl bytes 480GB → 480" \
        "480" "$(_round_to_nominal "$(convert_size_to_gb '480,103,981,056 bytes [480 GB]')")"
}

_test_lsi_gen() {
    # 本机 report.html 实测的真实字符串：SAS39xx（家族号 + 字面 xx）
    local old_cache
    old_cache="${LSPCI_SHORT_CACHE[0000:31:00.0]:-}"
    LSPCI_SHORT_CACHE["0000:31:00.0"]="RAID bus controller: Broadcom / LSI MegaRAID 12GSAS/PCIe Secure SAS39xx"
    _assert_eq "report.html 实测: SAS39xx → sas4" "sas4" "$(lsi_gen_of_bdf '0000:31:00.0' '10e2')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS3916 PCI-Express Fusion-MPT SAS-4"
    _assert_eq "SAS3916 → sas4" "sas4" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS3008 PCI-Express Fusion-MPT SAS-3"
    _assert_eq "SAS3008 → sas3" "sas3" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS3408 PCI-Express Fusion-MPT SAS-3"
    _assert_eq "SAS3408 → sas3" "sas3" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS3516 PCI-Express Fusion-MPT SAS-3"
    _assert_eq "SAS3516 → sas3" "sas3" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS2008 PCI-Express Fusion-MPT SAS-2"
    _assert_eq "SAS2008 → sas2" "sas2" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    # 与 v61 保持一致的家族映射（只放宽了 "xx" 后缀，不改变任何原本判对的卡）
    LSPCI_SHORT_CACHE["0000:31:00.0"]="Broadcom / LSI SAS3816 PCI-Express Fusion-MPT SAS-4"
    _assert_eq "SAS3816 → sas3（与 v61 家族表一致，未擅自改动）" "sas3" "$(lsi_gen_of_bdf '0000:31:00.0' '')"

    # 型号名判不出来时退回 PID 表
    LSPCI_SHORT_CACHE["0000:31:00.0"]="Some unknown LSI storage controller"
    _assert_eq "型号判不出 → PID 表 sas3(0097)" "sas3" "$(lsi_gen_of_bdf '0000:31:00.0' '0097')"
    _assert_eq "型号判不出 → PID 表 sas4(00e2)" "sas4" "$(lsi_gen_of_bdf '0000:31:00.0' '00e2')"
    _assert_eq "完全未知 → unknown" "unknown" "$(lsi_gen_of_bdf '0000:31:00.0' 'ffff')"

    LSPCI_SHORT_CACHE["0000:31:00.0"]="$old_cache"
}

_test_csv() {
    _assert_eq "普通字段不加引号" "abc" "$(csv_escape 'abc')"
    _assert_eq "含逗号加引号" '"a,b"' "$(csv_escape 'a,b')"
    # 注意：不能写成 $(csv_escape 'a"b') —— 内层的单引号会提前闭合外层引号。
    # 用变量传递含引号的输入，避免嵌套引号的歧义。
    local q_in='a"b'
    _assert_eq "含引号转义为两个引号" '"a""b"' "$(csv_escape "$q_in")"
    _assert_eq "CR 被去掉" "ab" "$(csv_escape $'a\rb')"
    _assert_eq "空字段返回空" "" "$(csv_escape '')"

    # F-6：字段数不等于 22 时必须失败（返回非 0 且不输出内容）
    local out rc
    out=$(output_row a b c 2>/dev/null); rc=$?
    _assert_eq "output_row 字段数不足时返回非 0" "1" "$rc"
    _assert_eq "output_row 字段数不足时不输出行" "" "$out"

    # 正好 22 个字段：应成功并得到 21 个逗号
    local -a f=()
    local i
    for ((i = 1; i <= CSV_COLUMNS; i++)); do f+=("v$i"); done
    out=$(output_row "${f[@]}"); rc=$?
    _assert_eq "output_row 22 字段返回 0" "0" "$rc"
    _assert_eq "output_row 22 字段产生 21 个逗号" "21" "$(printf '%s' "$out" | tr -cd ',' | wc -c | tr -d ' ')"
}

_test_serial() {
    # F-3：内部空格必须保留（旧实现 tr -d ' \n' 会删掉）
    local si='Serial Number: PHYF 1296 0001'
    _assert_eq "序列号保留内部空格（F-3）" "PHYF 1296 0001" "$(smart_serial_of "$si")"
    _assert_eq "序列号去首尾空白" "PHYF1" "$(smart_serial_of 'Serial Number:    PHYF1   ')"
    _assert_eq "无序列号返回空" "" "$(smart_serial_of 'Device Model: X')"
    _assert_eq "_norm_serial 去掉 CR" "PHYF1" "$(_norm_serial $'PHYF1\r')"
    _assert_eq "_norm_serial 去掉换行但保留内部空格" "A B" "$(_norm_serial $'A B\n')"
}

_test_pci() {
    _assert_eq "补全 domain: 00:1f.2 → 0000:00:1f.2" "0000:00:1f.2" "$(normalize_pci_addr '00:1f.2')"
    _assert_eq "大写转小写" "0000:00:1f.2" "$(normalize_pci_addr '0000:00:1F.2')"
    _assert_eq "提取 4 段 BDF" "0000:2d:00.0" "$(_extract_bdf '0000:2d:00.0')"
    _assert_eq "提取 2 段 BDF 并补 domain" "0000:2d:00.0" "$(_extract_bdf '2d:00.0')"
    _assert_eq "从 by-path 名字里提取" "0000:2d:00.0" "$(_extract_bdf 'pci-0000:2d:00.0-scsi-0:0:0:0')"
    _assert_eq "无 BDF 返回空" "" "$(_extract_bdf 'not-a-bdf')"
    _assert_eq "mock 命令 key 片段" "0000_2d_00_0" "$(_bdf_key '0000:2d:00.0')"
    _assert_eq "mock 设备 key 片段" "dev.sda" "$(_dev_key '/dev/sda')"
}

_test_smart_parse() {
    # ATA 属性行：列序为 id name flag value worst thresh type updated when raw
    # 所以 RAW_VALUE 在第 10 列（awk '{print $10}'）
    local si='  5 Reallocated_Sector_Ct   0x0033   100   100   010    Pre-fail  Always       -       0'
    _assert_eq "ATA 属性 RAW_VALUE 取第 10 列" "0" "$(get_smart_attr_raw "$si" 5)"

    _assert_eq "ATA Error Count 缺失时为空" "" "$(_field_val 'nothing here' 'ATA Error Count')"
    _assert_eq "_field_val 去冒号前后空白" "Value" "$(_field_val 'Key:     Value   ' 'Key')"

    # P1-6：0 小时 / 0% 是合法值，不能被当成"缺失"
    _assert_eq "Power On Hours: 0 不是缺失" "0" "$(get_power_hours_text 'Power On Hours: 0' '')"
    _assert_eq "取不到 Power On Hours 时为 NA" "NA" "$(get_power_hours_text '' '')"
    _assert_eq "NVMe percentage_used → 剩余寿命" "97%" "$(get_life_percent_text '' 'percentage_used : 3' 'SSD')"
    _assert_eq "0% 磨损 → 100%" "100%" "$(get_life_percent_text '' 'percentage_used : 0' 'SSD')"
    _assert_eq "HDD 寿命恒为 NA" "NA" "$(get_life_percent_text 'x' '' 'HDD')"
}

# v62 新增：errors 列的 ATA / SCSI(SAS) 双分支
_test_errors() {
    # ---------- SATA/ATA：188 Command_Timeout 必须被登记 ----------
    # 构造块盘：197/198/199 全 0，只有 188 非 0。
    # 修复前这种盘会报 errors=0（看着像完美新盘），修复后必须报出 188。
    local ata_only_188='
SMART overall-health self-assessment test result: PASSED

ID# ATTRIBUTE_NAME          FLAG     VALUE WORST THRESH TYPE      UPDATED  WHEN_FAILED RAW_VALUE
  5 Reallocated_Sector_Ct   0x0033   100   100   010    Pre-fail  Always       -       0
188 Command_Timeout         0x0032   100   099   000    Old_age   Always       -       4295032836
197 Current_Pending_Sector  0x0012   100   100   000    Old_age   Always       -       0
198 Offline_Uncorrectable   0x0010   100   100   000    Old_age   Offline      -       0
199 UDMA_CRC_Error_Count    0x003e   200   200   000    Old_age   Always       -       0'
    _assert_eq "ATA: 仅 188 非 0 时能报出 Command_Timeout" \
        "Command_Timeout:4295032836" "$(get_errors_count "$ata_only_188" HDD /dev/sda)"

    # 187 Reported_Uncorrect 同样必须登记
    local ata_187='
ID# ATTRIBUTE_NAME          FLAG     VALUE WORST THRESH TYPE      UPDATED  WHEN_FAILED RAW_VALUE
 10 Spin_Retry_Count        0x0013   100   100   097    Pre-fail  Always       -       3
187 Reported_Uncorrect      0x0032   100   100   000    Old_age   Always       -       7'
    _assert_eq "ATA: 187 与 10 都被登记" \
        "Reported_Uncorrect:7;Spin_Retry_Count:3" \
        "$(get_errors_count "$ata_187" HDD /dev/sdb)"

    # 全 0 的盘仍必须是 "0"（不能因为新增检查就把健康盘报成有错）
    local ata_clean='
ID# ATTRIBUTE_NAME          FLAG     VALUE WORST THRESH TYPE      UPDATED  WHEN_FAILED RAW_VALUE
  5 Reallocated_Sector_Ct   0x0033   100   100   010    Pre-fail  Always       -       0
 10 Spin_Retry_Count        0x0013   100   100   097    Pre-fail  Always       -       0
187 Reported_Uncorrect      0x0032   100   100   000    Old_age   Always       -       0
188 Command_Timeout         0x0032   100   100   000    Old_age   Always       -       0
197 Current_Pending_Sector  0x0012   100   100   000    Old_age   Always       -       0
198 Offline_Uncorrectable   0x0010   100   100   000    Old_age   Offline      -       0
199 UDMA_CRC_Error_Count    0x003e   200   200   000    Old_age   Always       -       0'
    _assert_eq "ATA: 全 0 的健康盘仍返回 0" "0" \
        "$(get_errors_count "$ata_clean" HDD /dev/sdc)"

    # ---------- SCSI/SAS：修复前恒为 0 ----------
    # 真实 SAS 盘 smartctl -a 是 SCSI 格式，没有属性表。
    # 构造块 G-list=12、非介质错误=3 的坏盘：修复前报 0（严重漏报）。
    local sas_bad='
SMART Health Status: OK

Error counter log:
           Errors Corrected by           Total   Correction     Gigabytes    Total
               ECC          rereads/    errors   algorithm      processed    uncorrected
           fast | delayed   rewrites  corrected  invocations   [10^9 bytes]  errors
read:          0        0         0         0          0        120.000      5
write:         0        0         0         0          0         40.000      7
verify:        0        0         0         0          0          0.000      0

Current Drive Temperature:     34 C
Elements in grown defect list: 12
Non-medium error count:        3'
    _assert_eq "SAS: G-list / 非介质 / 不可纠正错误都被登记" \
        "Grown_Defect_List:12;Non_Medium_Errors:3;Uncorrected_Errors:12" \
        "$(get_errors_count "$sas_bad" HDD /dev/sdd)"

    # SAS 健康状态非 OK 要登记
    local sas_failed='
SMART Health Status: FAILED!  Hardware impending failure, general
Elements in grown defect list: 0'
    _assert_eq "SAS: Health Status 非 OK 被登记" \
        "SMART_Health_Status:FAILED!  Hardware impending failure general" \
        "$(get_errors_count "$sas_failed" HDD /dev/sde)"

    # SAS 全好的盘返回 0（Health=OK，G-list=0，无不可纠正错误）
    local sas_ok='
SMART Health Status: OK
Elements in grown defect list: 0
Non-medium error count:        0
read:          0        0         0         0          0        120.000      0'
    _assert_eq "SAS: 健康盘返回 0" "0" "$(get_errors_count "$sas_ok" HDD /dev/sdf)"

    # ---------- 判别依据：SCSI 有 "SMART Health Status"，ATA 没有 ----------
    # 一块 ATA 盘绝不能误入 SCSI 分支（否则 188 等检查全失效）
    _assert_eq "ATA 文本不会误判为 SCSI" \
        "Command_Timeout:1" \
        "$(get_errors_count '188 Command_Timeout 0x0032 100 099 000 Old_age Always - 1' HDD /dev/sdg)"

    # 缩进容错：smartctl 各版本/厂商对这些行的缩进不一致，不能锚死 ^\S
    local sas_indented='
  SMART Health Status: OK
	Elements in grown defect list: 9
    Non-medium error count:        4'
    _assert_eq "SAS: 带前导空格/制表符的行仍能解析" \
        "Grown_Defect_List:9;Non_Medium_Errors:4" \
        "$(get_errors_count "$sas_indented" HDD /dev/sdh)"
}

_test_misc() {
    _assert_eq "_trim 去首尾空白" "abc" "$(_trim '   abc   ')"
    _assert_eq "_trim 保留内部空格" "a  b" "$(_trim ' a  b ')"
    _assert_eq "_dec 非数字返回空" "" "$(_dec 'abc')"
    _assert_eq "_norm_path 解析 .." "/a/c" "$(_norm_path '/a/b/../c')"
    _assert_eq "_norm_path 解析 ." "/a/b" "$(_norm_path '/a/./b')"
    _assert_eq "比例/型号：INTEL SSDSC2KB480G8 → S4510" "S4510" "$(resolve_model 'INTEL SSDSC2KB480G8' 'SSDSC2KB480G8')"
    _assert_eq "厂商：Intel" "Intel" "$(get_vendor 'INTEL SSDSC2KB480G8')"
    _assert_eq "厂商：Samsung(前缀兜底)" "Samsung" "$(get_vendor 'MZ7LM480HCHP')"
    _assert_eq "厂商：未知" "UNKNOWN" "$(get_vendor 'SOMETHING ODD')"

    # F-5：清洗后的文件名必须唯一且可作文件名
    if command -v cksum >/dev/null 2>&1; then
        local a b
        a=$(sanitize_name 'A/B'); b=$(sanitize_name 'A_B')
        if [[ "$a" != "$b" ]]; then
            TEST_PASS=$((TEST_PASS + 1)); printf '  %s✓%s %s\n' "$GREEN" "$NC" "sanitize_name 对 A/B 与 A_B 产生不同名字（F-5）"
        else
            TEST_FAIL=$((TEST_FAIL + 1)); printf '  %s✗%s %s\n' "$RED" "$NC" "sanitize_name 唯一性（F-5）：两者都是 [$a]" >&2
        fi
        _assert_eq "sanitize_name 去掉路径分隔符" "yes" "$(case "$(sanitize_name 'a b/c')" in */*) echo no ;; *) echo yes ;; esac)"
        _assert_eq "sanitize_name 空输入仍可用" "yes" "$(case "$(sanitize_name '')" in UNKNOWN_*) echo yes ;; *) echo no ;; esac)"
    else
        printf '  %s-%s 跳过 sanitize_name 用例（未找到 cksum）\n' "$YELLOW" "$NC"
    fi
}

# 自测入口：返回 0 全部通过，返回 6 有失败
run_self_test() {
    print_separator
    printf '%s内置自测（--test）v%s%s\n' "$GREEN" "$SCRIPT_VERSION" "$NC"
    print_separator

    TEST_PASS=0; TEST_FAIL=0

    printf '%s[1/8]%s CSV 列数\n' "$BLUE" "$NC";        _test_csv_header_columns
    printf '%s[2/8]%s 容量换算\n' "$BLUE" "$NC";        _test_sizes
    printf '%s[3/8]%s 标称容量对齐\n' "$BLUE" "$NC";    _test_nominal
    printf '%s[4/8]%s SAS 代数判定\n' "$BLUE" "$NC";    _test_lsi_gen
    printf '%s[5/8]%s CSV 转义与列数防呆\n' "$BLUE" "$NC"; _test_csv
    printf '%s[6/8]%s 序列号与 PCI 地址\n' "$BLUE" "$NC"; _test_serial; _test_pci
    printf '%s[7/8]%s SMART 解析与杂项\n' "$BLUE" "$NC"; _test_smart_parse; _test_misc
    printf '%s[8/8]%s errors 列（ATA / SAS 双分支）\n' "$BLUE" "$NC"; _test_errors

    print_separator
    printf '通过 %s%d%s 项，失败 %s%d%s 项\n' "$GREEN" "$TEST_PASS" "$NC" "$RED" "$TEST_FAIL" "$NC"
    print_separator
    (( TEST_FAIL > 0 )) && return 6
    return 0
}

# ============================================================================
# §19 命令行与入口
# ============================================================================

show_help() {
    cat << 'EOF'
服务器硬盘信息收集工具 v62（支持 MegaRAID / LSI sas3ircu / Adaptec arcconf）

用法: sudo ./collect_disk.sh [选项]

选项:
    -h, --help            帮助
    -v, --version         版本
    -t, --test            运行内置自测（纯函数，无副作用，不需要 root / 真机）
    -d, --debug           调试模式（打印外部命令的非零退出码、vendor 判定、mock 缺失等）
    -q, --quiet           不把 CSV 内容打到 stdout
    -o, --output DIR      输出目录（默认: <脚本目录>/report）
    -s, --serial SN       手动指定系统序列号（不会被自动探测覆盖）
    --mock-dir DIR        Mock 模式：从 DIR 读取命令输出和文件系统镜像
    --mock-strict         Mock 模式下结束时汇总缺失的命令 key 并以退出码 4 结束

环境变量:
    DEBUG=true            等价于 -d
    MOCK_DIR=DIR          等价于 --mock-dir DIR
    OUTPUT_DIR=DIR        等价于 -o DIR
    CMD_TIMEOUT=秒        单个外部命令超时（默认 20 秒），依赖 timeout
    STDERR_CAPTURE=1      把外部命令的 stderr（首次出现）记入 DEBUG 日志，
                          用于区分"权限不足"与"设备不响应"（默认 0，保持丢弃）
    NO_COLOR=1            强制关闭彩色输出（默认两个流都重定向时自动关闭）
    FORCE_COLOR=1         强制开启彩色输出

退出码:
    0 成功    1 致命错误（sudo/目录/依赖）
    2 参数或 mock 目录错误   3 未采集到任何硬盘   4 mock 数据缺失（--mock-strict）
    5 脚本自身换行符为 CRLF（无法在 Linux 运行）   6 自测（--test）失败

Mock 模式说明:
    命令层：<MOCK_DIR>/cmd/<key>.txt
    文件系统层：<MOCK_DIR>/fs/<原路径> + <MOCK_DIR>/fs/links.tsv（符号链接记录，
                支持 "目标 -> 目标" 多级链，也支持相对路径；未记录但 fs/ 下存在的
                路径按 readlink -f 语义返回自身，不存在则返回空）

    关键命令 key：
      lspci.D.nn
      lspci.s.<bdfkey>                 （单行描述，用于设备名过滤/代数判定）
      lspci.s.<bdfkey>.vv              （LnkCap/LnkSta）
      dmidecode.system-serial-number
      dmidecode.t-slot
      lsblk.d.n.NAME,TYPE
      lsblk.d.n.{SIZE,MODEL,SERIAL}.<devkey>
      smartctl.{a,i}.<devkey>
      smartctl.{a,i}.d.<sat|ata|scsi|nvme>.<devkey>
      smartctl.a.megaraid.<did>.<channeldevkey>
      nvme.id-ctrl.<devkey>
      nvme.smart-log.<devkey>
      arcconf.GETVERSION                      （可选，缺失时按单控制器 1 处理）
      arcconf.GETCONFIG.<ctrl>.{PD,LD}
      storcli64.call.eall.sall
      storcli64.call.vall
      sas3ircu.list
      sas3ircu.<idx>.display
      mvcli.info.o.hba

    <bdfkey> 例：0000:2d:00.0 → 0000_2d_00_0
    <devkey> 例：/dev/sda → dev.sda
    <channeldevkey> 例：/dev/sda → dev.sda（MegaRAID 直通通道设备）
    注意：mock 下 smartctl 的 base key 若不含 Device Model/Serial Number 等标识行，
          脚本会继续尝试 4 个 -d 变体，因此建议 base key 也放完整输出。

CSV 列（22 列，自 v59 起未变）:
    server_serial,disk_type,disk_vendor,disk_model,disk_product,disk_serial,
    disk_size_gb,disk_firmware,disk_dev_name,disk_wwn,disk_raid_mode,disk_pci_busid,
    pcie_slot,raid_ctrl_slot,pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,
    pcie_link_sta,disk_power_hours,disk_life_percent,errors

v62 变更:
    P0-7  ★ 换行统一为 LF + 运行时 CR 自检（CRLF 会让 heredoc 不闭合、
          脚本"成功退出但什么都不做"；详见文件头 P0-7）
    F-1  SAS 代数判定按型号前缀+家族号，修复 "SAS39xx" 判不出导致
         误报"SAS4 不支持"、以及 MegaRAID 卡被丢给 sas3ircu 白跑超时
    F-2  SAS4/SAS2 告警按 PCI class 区分 HBA 与 MegaRAID，不再给出错误建议
    F-3  序列号不再删除内部空格（去重键不一致会把同一块盘记成两条）
    F-4  可捕获 stderr（STDERR_CAPTURE=1）以区分权限不足与设备不响应
    F-5  sanitize_name 增加 8 位校验和，避免不同序列号映射到同一文件名
    F-6  output_row 强制校验字段数 == 22，杜绝静默错列
    F-7  build_ctrl_channels 改用独立"已加载"标志
    F-8  mock 文件层未命中纳入 --mock-strict 提示（分"夹具没搭/逻辑没采到"）
    F-9  标称容量：容差 5%→4%（修掉 250→240 / 500→480 的向下误贴），
         候选表收敛为企业级 46 档：删消费级与冗余档，补 26000/28000
         （修复 26TB→25600）与 Optane 375/750/1500（修复 1.5TB→1600）
    F-10 新增 --test 内置自测（退出码 6）
    F-11 errors 列拆成 ATA / SCSI(SAS) 两条分支：修复 SAS 盘错误计数恒为 0 的
         漏报（G-list/非介质错误/不可纠正错误/Health Status），ATA 侧补
         188 Command_Timeout、187 Reported_Uncorrect、10 Spin_Retry_Count

v61 变更（精简与可读性，无功能变更）:
    - 合并重复实现：_find_tool / _size_to_gb / _first_sd_under_bdf /
      _find_osdev_by_wwid / _err_add_num / _field_val / health_fields / nvme_scan
    - 目录 + 编号分节 + 每个函数一行注释；CSV 列与各 mock key 均不变

v60 变更:
    P0-1  -s/--serial 不再被自动探测覆盖
    P0-2  MegaRAID 分支改用物理盘容量（原取到 VD 容量）
    P0-3  去重改为内存表（原 grep ",$sn," 会误杀缺序列号的盘）
    P0-4  errors 基于真正取到 SMART 的设备（原丢掉 --device=megaraid,DID）
    P0-5  PCIe slot 缓存键统一为 BDF
    P0-6  删除把 "Present" 当序列号的死逻辑
    P1-1  SMART/NVMe 缓存 + 记住可用 -d 类型（单盘 smartctl 调用大幅下降）
    P1-2  分支按控制器判定：MegaRAID+SAS3、SAS3+SAS4 混插不再整类丢盘
    P1-3  arcconf 支持多控制器；mvcli 走 run_cmd（mock 可用）
    P1-4  run_cmd 统一 timeout + 非零退出码记录
    P1-5  容量换算支持 lsblk 单字母后缀与 bytes；标称容量表补齐
    P1-6  统一 SMART 字段解析；0 小时/0% 磨损不再当成缺失
    P1-7  pcie_gen 取实际协商速率(LnkSta)
    P1-8  disk_pci_busid 统一输出 BDF
    P1-9  依赖自检、LC_ALL=C、mktemp+trap、退出码、文件名清洗、--quiet
    P1-10 mock links.tsv 预载 + 精确匹配 + 链式解析；--mock-strict
    - 颜色改用 $'...' 真实 ESC 字节；重定向时自动去色，NO_COLOR/FORCE_COLOR 可覆盖
    - disk_model：带厂商前缀的型号也能拿到友好名（INTEL SSDSC2KB480G8 → S4510）
    - SMART 属性前导 0（099）不再触发 bash 八进制解析错误
    - sas3ircu 只在 class=0x0107 的 SAS HBA 上运行，MegaRAID(0x0104) 交给 storcli

v59 变更:
    - 新增 --mock-dir / MOCK_DIR 支持
    - 所有外部命令、sysfs 访问、符号链接解析均可 mock

v58 变更:
    - Adaptec disk_dev_name 三级兜底
    - arcconf LD 字段名 "Volume Unique Identifier"
    - naa. 前缀剥离修复
EOF
}

# 命令行解析（-o/-s 等只赋值，不在解析阶段做校验以外的动作）
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)     show_help; exit 0 ;;
            -v|--version)  printf 'collect_disk.sh v%s\n' "$SCRIPT_VERSION"; exit 0 ;;
            -t|--test)     SELF_TEST=true; shift ;;
            -d|--debug)    DEBUG="true"; shift ;;
            -q|--quiet)    QUIET=true; shift ;;
            -o|--output)
                [[ -n "${2:-}" ]] || { log_error "-o/--output 需要目录参数"; exit 2; }
                OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial)
                [[ -n "${2:-}" ]] || { log_error "-s/--serial 需要序列号参数"; exit 2; }
                SYSTEM_SERIAL="$2"; shift 2 ;;
            --mock-dir)
                [[ -n "${2:-}" ]] || { log_error "--mock-dir 需要目录参数"; exit 2; }
                MOCK_DIR="$2"; MOCK_MODE=true; shift 2 ;;
            --mock-strict) MOCK_STRICT=true; shift ;;
            *) log_error "未知选项: $1"; show_help; exit 2 ;;
        esac
    done
    return 0
}

trap cleanup EXIT

parse_args "$@"

# --test：只跑纯函数自测，不碰系统、不需要 root、不创建输出目录
if [[ "$SELF_TEST" == "true" ]]; then
    run_self_test
    exit $?
fi

main
exit $?
