#!/bin/bash
# ============================================================================
# 硬件信息收集总控脚本
# 自动切到脚本所在目录，依次执行所有子脚本
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"

SCRIPTS=(
    collect_cpu.sh
    collect_memory.sh
    collect_disk.sh
    collect_nic.sh
    collect_ib.sh
    collect_gpu.sh
    collect_raid.sh
    collect_psu.sh
    collect_fan.sh
    collect_server.sh
)

failed=()

for s in "${SCRIPTS[@]}"; do
    path="$SCRIPT_DIR/$s"
    if [[ ! -x "$path" ]]; then
        echo "[WARN] 跳过（不存在或不可执行）: $s"
        failed+=("$s")
        continue
    fi
    echo "===== $s ====="
    if "$path"; then
        echo "[OK] $s"
    else
        echo "[FAIL] $s (exit=$?)"
        failed+=("$s")
    fi
done

echo
if [[ ${#failed[@]} -gt 0 ]]; then
    echo "⚠️  以下脚本未成功执行: ${failed[*]}"
    exit 1
fi
echo "✅ 全部完成"
