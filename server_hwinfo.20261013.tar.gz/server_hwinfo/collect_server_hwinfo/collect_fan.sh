#!/bin/bash
# ============================================================================
# 服务器风扇信息收集脚本 - v6
# 输出列（9 列）:
#   server_serial,fan_index,fan_name,fan_status,
#   fan_lower_speed_rpm,fan_upper_speed_rpm,fan_current_speed_rpm,
#   fan_vendor,fan_model
#
# 支持的风扇命名:
#   InFAN<n>_Speed / OutFAN<n>_Speed    （旧机器）
#   FAN<n>_F_Speed / FAN<n>_R_Speed     （新机器）
#   FAN_<非数字>_Speed（如 FAN_M2_Speed） 单独一条
#
# 过滤规则:
#   - 合并后的 current_speed 为 0 或 N/A → 不写入 CSV
#
# 判定规则:
#   fan_status 直接由 Speed 行的 Status 列决定：
#     "ok"               → ok
#     空 / "N/A"          → warning
#     其他（nc/cr/nr/ns）→ critical
# ============================================================================

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
DEBUG="${DEBUG:-false}"
SKIP_IPMI="${SKIP_IPMI:-false}"

DMIDECODE_CACHE=""
IPMITOOL_SENSOR_CACHE=""
IPMITOOL_SDR_CACHE=""
FAN_LIST_CACHE=""

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

# ============================================================================
# 日志
# ============================================================================

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2; return 0; }

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ============================================================================
# CSV 转义
# ============================================================================

csv_escape() {
    local field="$1"
    [[ -z "$field" ]] && { echo ""; return; }
    if echo "$field" | grep -qE '[, "]' ; then
        field=$(echo "$field" | sed 's/"/""/g')
        echo "\"$field\""
    else
        echo "$field"
    fi
}

# ============================================================================
# 缓存
# ============================================================================

cache_dmidecode() {
    if [[ -z "$DMIDECODE_CACHE" ]]; then
        log_debug "执行 dmidecode 并缓存结果..."
        DMIDECODE_CACHE=$(sudo dmidecode 2>/dev/null)
    fi
    echo "$DMIDECODE_CACHE"
}

cache_ipmitool_sensor() {
    if [[ -z "$IPMITOOL_SENSOR_CACHE" ]]; then
        if [[ "$SKIP_IPMI" == "true" ]]; then
            log_debug "SKIP_IPMI=true，跳过 ipmitool sensor"
            IPMITOOL_SENSOR_CACHE="__SKIPPED__"
        elif command -v ipmitool &>/dev/null; then
            log_debug "执行 ipmitool sensor 并缓存结果..."
            IPMITOOL_SENSOR_CACHE=$(sudo ipmitool sensor 2>/dev/null)
        fi
    fi
    if [[ "$IPMITOOL_SENSOR_CACHE" == "__SKIPPED__" ]]; then
        echo ""
    else
        echo "$IPMITOOL_SENSOR_CACHE"
    fi
}

cache_ipmitool_sdr() {
    if [[ -z "$IPMITOOL_SDR_CACHE" ]]; then
        if [[ "$SKIP_IPMI" == "true" ]]; then
            log_debug "SKIP_IPMI=true，跳过 ipmitool sdr"
            IPMITOOL_SDR_CACHE="__SKIPPED__"
        elif command -v ipmitool &>/dev/null; then
            log_debug "执行 ipmitool sdr list 并缓存结果..."
            IPMITOOL_SDR_CACHE=$(sudo ipmitool sdr list 2>/dev/null)
        fi
    fi
    if [[ "$IPMITOOL_SDR_CACHE" == "__SKIPPED__" ]]; then
        echo ""
    else
        echo "$IPMITOOL_SDR_CACHE"
    fi
}

get_ipmi_data() {
    local data
    data=$(cache_ipmitool_sensor)
    if [[ -n "$data" ]] && printf '%s\n' "$data" | grep -qE '(InFAN|OutFAN|FAN[0-9]+_[FR]_Speed|FAN_[A-Za-z0-9]+_Speed)'; then
        log_debug "使用 ipmitool sensor 输出（含阈值）"
        printf '%s\n' "$data"
        return
    fi
    log_debug "ipmitool sensor 无风扇数据，回退到 ipmitool sdr list"
    cache_ipmitool_sdr
}

# ============================================================================
# 系统序列号
# ============================================================================

get_serial_from_dmidecode() {
    local serial
    serial=$(sudo dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" && "$serial" != "Not Specified" && "$serial" != "Unknown" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(sudo cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" && "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" && "$serial" != "00000000" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(get_serial_from_dmidecode get_serial_from_sysfs get_serial_from_hostid)
    log_info "正在获取系统序列号..."
    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            local method_name="${method#get_serial_from_}"
            log_info "通过 ${method_name} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done
    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# 判定 fan_status
# ============================================================================

determine_fan_status() {
    local speed_status="$1"

    if [[ -z "$speed_status" || "$speed_status" == "N/A" ]]; then
        echo "warning"; return
    fi

    if [[ "$speed_status" == "ok" ]]; then
        echo "ok"; return
    fi

    echo "critical"
}

# ============================================================================
# 解析风扇信息（兼容多种命名）
# 输出格式:
#   IN_SPEED|n|current|status|LNC|UNC
#   OUT_SPEED|n|current|status
#   SINGLE_SPEED|<name>|current|status|LNC|UNC
# ============================================================================

parse_fans() {
    local data
    data=$(get_ipmi_data)
    [[ -z "$data" ]] && { echo ""; return; }

    printf '%s\n' "$data" | awk -F'|' '
        function trim(s) { gsub(/^[ \t]+|[ \t]+$/, "", s); return s }
        function num(s,   v) {
            if (s !~ /[0-9]/) return ""
            match(s, /[0-9]+/)
            return substr(s, RSTART, RLENGTH) + 0
        }
        {
            name = trim($1)
            v4 = trim($4)
            if (v4 != "") {
                status = v4
                lnc = trim($7)
                unc = trim($8)
            } else {
                status = trim($3)
                lnc = ""
                unc = ""
            }

            # InFAN<n>_Speed
            if (match(name, /^InFAN[0-9]+_Speed$/)) {
                n = name; gsub(/[^0-9]/, "", n)
                cur = num(trim($2))
                l = num(lnc)
                u = num(unc)
                print "IN_SPEED|" n "|" cur "|" status "|" l "|" u
                next
            }
            # OutFAN<n>_Speed
            if (match(name, /^OutFAN[0-9]+_Speed$/)) {
                n = name; gsub(/[^0-9]/, "", n)
                cur = num(trim($2))
                print "OUT_SPEED|" n "|" cur "|" status
                next
            }
            # FAN<n>_F_Speed
            if (match(name, /^FAN[0-9]+_F_Speed$/)) {
                n = name; gsub(/[^0-9]/, "", n)
                cur = num(trim($2))
                l = num(lnc)
                u = num(unc)
                print "IN_SPEED|" n "|" cur "|" status "|" l "|" u
                next
            }
            # FAN<n>_R_Speed
            if (match(name, /^FAN[0-9]+_R_Speed$/)) {
                n = name; gsub(/[^0-9]/, "", n)
                cur = num(trim($2))
                print "OUT_SPEED|" n "|" cur "|" status
                next
            }
            # FAN_<非数字>_Speed（如 FAN_M2_Speed）
            if (name ~ /^FAN_[A-Za-z0-9]+_Speed$/ && name !~ /^FAN[0-9]+_[FR]_Speed$/) {
                sn = name
                sub(/_Speed$/, "", sn)
                cur = num(trim($2))
                l = num(lnc)
                u = num(unc)
                print "SINGLE_SPEED|" sn "|" cur "|" status "|" l "|" u
                next
            }
        }
    '
}

# ============================================================================
# 构建 FAN_LIST_CACHE
# 每行格式（以 | 分隔）:
#   idx | name | status | current_speed | vendor | model | lower_rpm | upper_rpm
#
# 过滤：合并后的 current_speed 为 0 或 N/A → 不写入
# ============================================================================

build_fan_cache() {
    local parsed
    parsed=$(parse_fans)

    if [[ -z "$parsed" ]]; then
        FAN_LIST_CACHE=""
        echo ""
        return
    fi

    declare -A in_speed=()
    declare -A in_speed_status=()
    declare -A out_speed=()
    declare -A out_speed_status=()
    declare -A in_lower=()
    declare -A in_upper=()

    local single_names=()
    declare -A single_speed=()
    declare -A single_status=()
    declare -A single_lower=()
    declare -A single_upper=()

    while IFS='|' read -r type n f1 f2 f3 f4; do
        [[ -z "$n" ]] && continue
        case "$type" in
            IN_SPEED)
                in_speed["$n"]="$f1"
                in_speed_status["$n"]="$f2"
                in_lower["$n"]="$f3"
                in_upper["$n"]="$f4"
                ;;
            OUT_SPEED)
                out_speed["$n"]="$f1"
                out_speed_status["$n"]="$f2"
                ;;
            SINGLE_SPEED)
                single_names+=("$n")
                single_speed["$n"]="$f1"
                single_status["$n"]="$f2"
                single_lower["$n"]="$f3"
                single_upper["$n"]="$f4"
                ;;
        esac
    done <<< "$parsed"

    # numbered 部分（IN/OUT 配对）
    local all_n=""
    for k in "${!in_speed[@]}";  do all_n="$all_n $k"; done
    for k in "${!out_speed[@]}"; do all_n="$all_n $k"; done

    local result=""
    local idx=0

    if [[ -n "$all_n" ]]; then
        local sorted_n
        sorted_n=$(echo "$all_n" | tr ' ' '\n' | sort -n | uniq)

        for n in $sorted_n; do
            local current="${in_speed[$n]:-}"
            if [[ -z "$current" || "$current" == "N/A" ]]; then
                current="${out_speed[$n]:-N/A}"
            fi
            [[ -z "$current" ]] && current="N/A"

            # ★ 过滤：current_speed 为 0 / N/A → 跳过
            if [[ "$current" == "0" || "$current" == "N/A" ]]; then
                log_debug "FAN$n 无有效转速 (current=$current)，跳过"
                continue
            fi

            local sp_status="${in_speed_status[$n]:-}"
            if [[ -z "$sp_status" || "$sp_status" == "N/A" ]]; then
                sp_status="${out_speed_status[$n]:-}"
            fi

            local lower="${in_lower[$n]:-}"
            local upper="${in_upper[$n]:-}"
            [[ -z "$lower" ]] && lower="N/A"
            [[ -z "$upper" ]] && upper="N/A"

            local status
            status=$(determine_fan_status "$sp_status")

            local name="FAN$n"

            result="$result"$'\n'"$idx|$name|$status|$current|||$lower|$upper"

            log_debug "FAN$n -> idx=$idx, status=$status (speed_status=$sp_status), current=$current, lower=$lower, upper=$upper"
            ((idx++))
        done
    fi

    # single 部分
    if [[ ${#single_names[@]} -gt 0 ]]; then
        for sn in "${single_names[@]}"; do
            [[ -z "$sn" ]] && continue
            local current="${single_speed[$sn]:-N/A}"
            [[ -z "$current" ]] && current="N/A"

            # ★ 过滤：current_speed 为 0 / N/A → 跳过
            if [[ "$current" == "0" || "$current" == "N/A" ]]; then
                log_debug "$sn 无有效转速 (current=$current)，跳过"
                continue
            fi

            local sp_status="${single_status[$sn]:-}"
            local lower="${single_lower[$sn]:-N/A}"
            local upper="${single_upper[$sn]:-N/A}"
            [[ -z "$lower" ]] && lower="N/A"
            [[ -z "$upper" ]] && upper="N/A"

            local status
            status=$(determine_fan_status "$sp_status")

            result="$result"$'\n'"$idx|$sn|$status|$current|||$lower|$upper"

            log_debug "$sn -> idx=$idx, status=$status (speed_status=$sp_status), current=$current, lower=$lower, upper=$upper"
            ((idx++))
        done
    fi

    FAN_LIST_CACHE=$(printf '%s\n' "$result" | sed '/^$/d')
    echo "$FAN_LIST_CACHE"
}

# ============================================================================
# 从缓存取字段
# ============================================================================

get_fan_info_from_cache() {
    local fan_idx="$1" field="$2"

    [[ -z "$FAN_LIST_CACHE" ]] && build_fan_cache > /dev/null
    [[ -z "$FAN_LIST_CACHE" ]] && { echo ""; return; }

    local line
    line=$(printf '%s\n' "$FAN_LIST_CACHE" | sed -n "$((fan_idx + 1))p")
    [[ -z "$line" ]] && { echo ""; return; }

    case "$field" in
        name)          echo "$line" | cut -d'|' -f2 ;;
        status)        echo "$line" | cut -d'|' -f3 ;;
        current_speed) echo "$line" | cut -d'|' -f4 ;;
        vendor)        echo "$line" | cut -d'|' -f5 ;;
        model)         echo "$line" | cut -d'|' -f6 ;;
        lower_speed)   echo "$line" | cut -d'|' -f7 ;;
        upper_speed)   echo "$line" | cut -d'|' -f8 ;;
        *)             echo "" ;;
    esac
}

# ============================================================================
# 风扇数量
# ============================================================================

get_fan_count() {
    [[ -z "$FAN_LIST_CACHE" ]] && build_fan_cache > /dev/null
    if [[ -n "$FAN_LIST_CACHE" ]]; then
        local c
        c=$(printf '%s\n' "$FAN_LIST_CACHE" | grep -c '.')
        echo "${c:-0}"
    else
        echo "0"
    fi
}

# ============================================================================
# 字段 getter
# ============================================================================

get_fan_name() {
    local v; v=$(get_fan_info_from_cache "$1" "name")
    [[ -n "$v" ]] && echo "$v" || echo "FAN$1"
}

get_fan_status() {
    local v; v=$(get_fan_info_from_cache "$1" "status")
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_fan_current_speed_rpm() {
    local v; v=$(get_fan_info_from_cache "$1" "current_speed")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_fan_lower_speed_rpm() {
    local v; v=$(get_fan_info_from_cache "$1" "lower_speed")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_fan_upper_speed_rpm() {
    local v; v=$(get_fan_info_from_cache "$1" "upper_speed")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_fan_vendor() {
    local v; v=$(get_fan_info_from_cache "$1" "vendor")
    if [[ -n "$v" && "$v" != "UNKNOWN" ]]; then
        echo "$v"
    else
        echo ""
    fi
}

get_fan_model() {
    local v; v=$(get_fan_info_from_cache "$1" "model")
    if [[ -n "$v" && "$v" != "UNKNOWN" ]]; then
        echo "$v"
    else
        echo ""
    fi
}

# ============================================================================
# CSV
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"
    local clean_serial
    clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    if [[ -z "$clean_serial" || "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/fan_info.csv"
    else
        echo "${dir}/fan_info_${clean_serial}.csv"
    fi
}

write_csv_header() {
    local output_file="$1"
    local header="server_serial,fan_index,fan_name,fan_status,fan_lower_speed_rpm,fan_upper_speed_rpm,fan_current_speed_rpm,fan_vendor,fan_model"
    if ! printf '%s\n' "$header" > "$output_file" 2>/dev/null; then
        log_error "无法写入CSV文件: $output_file"
        return 1
    fi
    log_debug "CSV头已写入: $output_file"
    return 0
}

# ============================================================================
# 主收集
# ============================================================================

collect_fan_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集风扇信息..."

    cache_dmidecode
    build_fan_cache > /dev/null

    local fan_count
    fan_count=$(get_fan_count)

    log_info "检测到 $fan_count 个物理风扇（已过滤无转速的）"

    if [[ "$fan_count" -eq 0 ]]; then
        log_warn "未检测到有效物理风扇设备！"
        return 0
    fi

    local record_count=0

    for ((fan_idx=0; fan_idx<fan_count; fan_idx++)); do
        log_debug "正在处理风扇 $fan_idx"

        local name status current lower upper vendor model
        name=$(get_fan_name "$fan_idx")
        status=$(get_fan_status "$fan_idx")
        current=$(get_fan_current_speed_rpm "$fan_idx")
        lower=$(get_fan_lower_speed_rpm "$fan_idx")
        upper=$(get_fan_upper_speed_rpm "$fan_idx")
        vendor=$(get_fan_vendor "$fan_idx")
        model=$(get_fan_model "$fan_idx")

        local line
        line="$(csv_escape "$serial"),$(csv_escape "$fan_idx"),$(csv_escape "$name"),$(csv_escape "$status"),$(csv_escape "$lower"),$(csv_escape "$upper"),$(csv_escape "$current"),$(csv_escape "$vendor"),$(csv_escape "$model")"

        if ! printf '%s\n' "$line" >> "$output_file" 2>/dev/null; then
            log_error "无法写入CSV文件: $output_file"
            break
        fi

        ((record_count++))

        log_info "✅ 风扇 $fan_idx ($name): status=$status, current=${current}RPM, lower=${lower}RPM, upper=${upper}RPM"
    done

    echo "$record_count"
}

# ============================================================================
# main
# ============================================================================

main() {
    print_header "服务器风扇信息收集工具 - v6"

    SYSTEM_SERIAL=$(get_system_serial)
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    command -v dmidecode &>/dev/null || {
        log_warn "dmidecode 未安装，部分信息可能无法获取"
    }

    if [[ "$SKIP_IPMI" != "true" ]]; then
        command -v ipmitool &>/dev/null || {
            log_warn "ipmitool 未安装，风扇信息可能无法获取"
        }
    fi

    if ! sudo -n true 2>/dev/null; then
        if [[ -t 0 && -r /dev/tty ]]; then
            log_warn "需要sudo权限获取硬件信息，尝试获取..."
            if ! sudo -v 2>/dev/null; then
                log_warn "无法获取sudo权限，部分信息可能不完整"
                read -p "是否继续执行（部分信息可能不完整）？[y/N] " -n 1 -r < /dev/tty
                echo >&2
                if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                    exit 1
                fi
            fi
        else
            log_warn "非交互环境，且当前无免密sudo，部分信息可能不完整，将继续执行"
        fi
    fi

    if [[ ! -d "$OUTPUT_DIR" ]]; then
        if ! mkdir -p "$OUTPUT_DIR" 2>/dev/null; then
            log_error "无法创建输出目录: $OUTPUT_DIR"
            exit 1
        fi
    fi

    if ! write_csv_header "$OUTPUT_FILE"; then
        exit 1
    fi

    local record_count
    record_count=$(collect_fan_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")
    record_count=${record_count:-0}

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ -f "$OUTPUT_FILE" ]]; then
        local line_count
        line_count=$(($(wc -l < "$OUTPUT_FILE") - 1))
        [[ "$line_count" -lt 0 ]] && line_count=0
        echo -e "📊 风扇记录: ${BLUE}$line_count${NC} 条" >&2
        print_separator
        echo -e "${YELLOW}📄 内容预览:${NC}" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 入口
# ============================================================================

set -o pipefail 2>/dev/null || true

show_help() {
    cat << EOF
服务器风扇信息收集工具 - v6

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录 (默认: 当前目录)
    -s, --serial SN     手动指定系统序列号
        --skip-ipmi     跳过 ipmitool 调用

输出列（9 列）:
    server_serial,fan_index,fan_name,fan_status,
    fan_lower_speed_rpm,fan_upper_speed_rpm,fan_current_speed_rpm,
    fan_vendor,fan_model

支持的风扇命名:
    InFAN<n>_Speed / OutFAN<n>_Speed    （旧机器）
    FAN<n>_F_Speed / FAN<n>_R_Speed     （新机器）
    FAN_<非数字>_Speed（如 FAN_M2_Speed） 单独一条

过滤规则:
    合并后的 current_speed 为 0 或 N/A → 不写入 CSV

fan_status 判定规则:
    Speed 行的 Status 列:
      "ok"                → ok
      空 / "N/A"           → warning
      其他（nc/cr/nr/ns）→ critical
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)      show_help; exit 0 ;;
            -d|--debug)     DEBUG="true"; shift ;;
            -o|--output)    OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial)    SYSTEM_SERIAL="$2"; shift 2 ;;
            --skip-ipmi)    SKIP_IPMI="true"; shift ;;
            *)              log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
}

parse_args "$@"
main

# ============================================================================
# 结束
# ============================================================================
