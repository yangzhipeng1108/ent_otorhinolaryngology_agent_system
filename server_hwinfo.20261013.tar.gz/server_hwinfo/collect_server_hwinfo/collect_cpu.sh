#!/bin/bash

# ============================================================================
# 服务器CPU信息收集脚本 - 函数化版本（含CPU温度）
# 功能：收集服务器CPU硬件信息及温度，生成CSV格式报告
# 支持：多颗CPU，每颗CPU输出一条记录
# 输出列：server_serial,cpu_socket_name,cpu_vendor,cpu_family,cpu_model,cpu_core_num,cpu_base_mhz,cpu_temperature_c
# 优化：dmidecode和lscpu结果缓存，避免重复执行
# cpu_vendor从lscpu的Vendor ID获取并映射简化
# cpu_temperature从ipmitool sdr list获取，兼容CPU编号从0和1开始
# 支持格式: CPU0_Temp | 36 degrees C | ok  /  CPU1_Temp | 34 degrees C | ok
# ============================================================================

# 全局变量 - 设置默认值
SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_FILE=""
SYSTEM_SERIAL=""
DEBUG="${DEBUG:-false}"

# dmidecode缓存变量
DMIDECODE_PROCESSOR_CACHE=""
# lscpu缓存变量
LSCPU_CACHE=""
# /proc/cpuinfo缓存变量
PROC_CPUINFO_CACHE=""
# 温度采集缓存（每颗CPU独立）
declare -A CPU_TEMP_CACHE
# ipmitool输出缓存
IPMITOOL_SDR_CACHE=""
# CPU温度编号偏移量（0表示从0开始，1表示从1开始）
CPU_TEMP_OFFSET=""

# 颜色定义（用于输出）
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m' # No Color

# ============================================================================
# CPU Vendor映射表
# ============================================================================

declare -A CPU_VENDOR_MAP

init_cpu_vendor_map() {
    log_debug "初始化CPU Vendor映射表..."
    
    CPU_VENDOR_MAP["GenuineIntel"]="Intel"
    CPU_VENDOR_MAP["AuthenticAMD"]="AMD"
    CPU_VENDOR_MAP["HygonGenuine"]="Hygon"
    CPU_VENDOR_MAP["ARM"]="ARM"
    CPU_VENDOR_MAP["aarch64"]="ARM"
    CPU_VENDOR_MAP["PowerPC"]="PowerPC"
    
    log_debug "CPU Vendor映射表初始化完成，共 ${#CPU_VENDOR_MAP[@]} 条映射"
}

# ============================================================================
# 日志和输出函数
# ============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $*" >&2
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*" >&2
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*" >&2
}

log_debug() {
    if [[ "${DEBUG}" == "true" ]]; then
        echo -e "${BLUE}[DEBUG]${NC} $*" >&2
    fi
}

print_separator() {
    echo "=========================================" >&2
}

print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ============================================================================
# CSV转义函数
# ============================================================================

csv_escape() {
    local field="$1"
    
    if [[ -z "$field" ]]; then
        echo ""
        return
    fi
    
    if echo "$field" | grep -qE '[, "]' ; then
        field=$(echo "$field" | sed 's/"/""/g')
        echo "\"$field\""
    else
        echo "$field"
    fi
}

# ============================================================================
# 命令结果缓存管理函数
# ============================================================================

# 执行dmidecode -t processor并缓存结果
cache_dmidecode_processor() {
    if [[ -z "$DMIDECODE_PROCESSOR_CACHE" ]]; then
        log_debug "执行 dmidecode -t processor 并缓存结果..."
        DMIDECODE_PROCESSOR_CACHE=$(sudo dmidecode -t processor 2>/dev/null)
    fi
    echo "$DMIDECODE_PROCESSOR_CACHE"
}

# 执行lscpu并缓存结果
cache_lscpu() {
    if [[ -z "$LSCPU_CACHE" ]]; then
        if command -v lscpu &>/dev/null; then
            log_debug "执行 lscpu 并缓存结果..."
            LSCPU_CACHE=$(lscpu 2>/dev/null)
        else
            LSCPU_CACHE=""
        fi
    fi
    echo "$LSCPU_CACHE"
}

# 读取/proc/cpuinfo并缓存
cache_proc_cpuinfo() {
    if [[ -z "$PROC_CPUINFO_CACHE" ]]; then
        if [[ -f "/proc/cpuinfo" ]]; then
            log_debug "读取 /proc/cpuinfo 并缓存..."
            PROC_CPUINFO_CACHE=$(cat /proc/cpuinfo 2>/dev/null)
        else
            PROC_CPUINFO_CACHE=""
        fi
    fi
    echo "$PROC_CPUINFO_CACHE"
}

# 执行ipmitool sdr list并缓存（只过滤CPU相关行）
cache_ipmitool_sdr() {
    if [[ -z "$IPMITOOL_SDR_CACHE" ]]; then
        if command -v ipmitool &>/dev/null; then
            log_debug "执行 ipmitool sdr list 并缓存..."
            IPMITOOL_SDR_CACHE=$(sudo ipmitool sdr list 2>/dev/null | grep -i "CPU" | grep -i "Temp")
        else
            IPMITOOL_SDR_CACHE=""
            log_debug "ipmitool命令未找到"
        fi
    fi
    echo "$IPMITOOL_SDR_CACHE"
}

# ============================================================================
# 系统序列号获取函数
# ============================================================================

get_serial_from_dmidecode() {
    local serial=""
    serial=$(sudo dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]] && [[ "$serial" != "Unknown" ]]; then
        echo "$serial"
        return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial=""
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(sudo cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]]; then
            echo "$serial"
            return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial=""
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" ]] && [[ "$serial" != "00000000" ]]; then
        echo "$serial"
        return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(
        "get_serial_from_dmidecode"
        "get_serial_from_sysfs"
        "get_serial_from_hostid"
    )
    
    log_info "正在获取系统序列号..."
    
    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            local method_name="${method#get_serial_from_}"
            log_info "通过 ${method_name} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done
    
    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# CPU温度获取函数（从ipmitool获取，兼容CPU编号从0和1开始）
# ============================================================================

# 检查是否为CPU温度行（从ipmitool输出）
is_cpu_temp_line() {
    local line="$1"
    local cpu_idx="$2"
    
    # 匹配格式：
    # CPU0_Temp        | 36 degrees C      | ok
    # CPU1_Temp        | 34 degrees C      | ok
    # CPU1_Temp        | 36 degrees C      | ok
    # CPU2_Temp        | 44 degrees C      | ok
    
    # 支持 CPU[数字]_Temp 或 CPU[数字] Temp 或 CPU[数字]Temp 格式
    local pattern="CPU[[:space:]_]*${cpu_idx}[[:space:]_]*Temp"
    
    if echo "$line" | grep -qiE "${pattern}"; then
        return 0
    fi
    return 1
}

# 从CPU温度行提取温度数值（支持整数和小数）
extract_temp_from_line() {
    local line="$1"
    local temp=""
    
    # 尝试多种提取方式
    
    # 方式1: 提取 "37 degrees C" 格式的数字（支持整数和小数）
    temp=$(echo "$line" | grep -oE '[0-9]+(\.[0-9]+)?[[:space:]]+degrees[[:space:]]+C' | head -1 | sed 's/[[:space:]]*degrees[[:space:]]*C//')
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式2: 提取 "37°C" 格式（支持整数和小数）
    temp=$(echo "$line" | grep -oE '[0-9]+(\.[0-9]+)?°C' | head -1 | sed 's/°C//')
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式3: 提取 "37 C" 格式（支持整数和小数）
    temp=$(echo "$line" | grep -oE '[0-9]+(\.[0-9]+)?[[:space:]]+C' | head -1 | sed 's/[[:space:]]*C//')
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式4: 提取 "+37.0°C" 格式
    temp=$(echo "$line" | grep -oE '[+-]?[0-9]+(\.[0-9]+)?°C' | head -1 | sed 's/°C//' | sed 's/+//')
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式5: 提取 "+37.0 C" 格式
    temp=$(echo "$line" | grep -oE '[+-]?[0-9]+(\.[0-9]+)?[[:space:]]+C' | head -1 | sed 's/[[:space:]]*C//' | sed 's/+//')
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式6: 提取竖线后的第一个数字（针对 "CPU0_Temp | 36 degrees C | ok" 格式）
    temp=$(echo "$line" | awk -F'|' '{print $2}' | grep -oE '[0-9]+(\.[0-9]+)?' | head -1)
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    # 方式7: 提取行中任意位置的第一个数字（最后备选）
    temp=$(echo "$line" | grep -oE '[0-9]+(\.[0-9]+)?' | head -1)
    if [[ -n "$temp" ]]; then
        echo "$temp"
        return
    fi
    
    echo ""
}

# 检测CPU温度编号起始值（从0还是从1开始）
detect_cpu_temp_offset() {
    local ipmi_output="$1"
    local offset="0"
    local first_num=""
    local first_line=""
    
    log_debug "检测CPU温度编号起始值..."
    
    # 提取所有CPU温度行
    local temp_lines=()
    while IFS= read -r line; do
        if [[ -n "$line" ]] && echo "$line" | grep -qiE "CPU[[:space:]_]*[0-9]+[[:space:]_]*Temp"; then
            temp_lines+=("$line")
        fi
    done <<< "$ipmi_output"
    
    if [[ ${#temp_lines[@]} -eq 0 ]]; then
        log_debug "未找到CPU温度行，默认偏移量0"
        echo "0"
        return
    fi
    
    # 提取第一个CPU温度行的编号
    first_line="${temp_lines[0]}"
    first_num=$(echo "$first_line" | grep -oE '[0-9]+' | head -1)
    
    if [[ -n "$first_num" ]]; then
        if [[ "$first_num" -eq 0 ]]; then
            offset="0"
            log_debug "检测到CPU编号从0开始 (CPU${first_num}_Temp)"
        elif [[ "$first_num" -eq 1 ]]; then
            offset="1"
            log_debug "检测到CPU编号从1开始 (CPU${first_num}_Temp)"
        else
            # 如果第一个编号不是0或1，尝试判断
            if [[ "$first_num" -gt 1 ]]; then
                offset="1"
                log_debug "检测到CPU编号从1开始 (CPU${first_num}_Temp)"
            else
                offset="0"
                log_debug "未知起始值，默认偏移量0"
            fi
        fi
    else
        offset="0"
        log_debug "无法解析CPU编号，默认偏移量0"
    fi
    
    echo "$offset"
}

# 获取CPU温度（从ipmitool获取，兼容CPU编号从0和1开始）
get_cpu_temperature() {
    local cpu_idx="$1"
    local temp_value=""
    local ipmi_output=""
    
    # 获取缓存的ipmitool输出
    ipmi_output=$(cache_ipmitool_sdr)
    
    if [[ -z "$ipmi_output" ]]; then
        log_debug "ipmitool未返回CPU温度信息"
        echo "N/A"
        return 0
    fi
    
    # 如果偏移量未检测，先检测
    if [[ -z "$CPU_TEMP_OFFSET" ]]; then
        CPU_TEMP_OFFSET=$(detect_cpu_temp_offset "$ipmi_output")
        log_debug "CPU温度编号偏移量: ${CPU_TEMP_OFFSET}"
    fi
    
    # 根据偏移量计算实际的IPMI CPU编号
    local actual_cpu_idx=$((cpu_idx + CPU_TEMP_OFFSET))
    
    log_debug "CPU${cpu_idx} -> 查找 CPU${actual_cpu_idx}_Temp"
    
    # 匹配对应的CPU温度行
    while IFS= read -r line; do
        if [[ -n "$line" ]] && is_cpu_temp_line "$line" "$actual_cpu_idx"; then
            temp_value=$(extract_temp_from_line "$line")
            if [[ -n "$temp_value" ]]; then
                log_debug "✅ 从ipmitool获取到 CPU${actual_cpu_idx}_Temp (映射到CPU${cpu_idx}): ${temp_value}°C"
                echo "${temp_value}"
                return 0
            fi
        fi
    done <<< "$ipmi_output"
    
    # 如果精确匹配失败，尝试模糊匹配作为备选
    log_debug "精确匹配失败，尝试模糊匹配..."
    local temp_lines=()
    while IFS= read -r line; do
        if [[ -n "$line" ]] && echo "$line" | grep -qiE "CPU[[:space:]_]*[0-9]+[[:space:]_]*Temp"; then
            temp_lines+=("$line")
        fi
    done <<< "$ipmi_output"
    
    if [[ ${#temp_lines[@]} -gt 0 ]] && [[ ${#temp_lines[@]} -gt $cpu_idx ]]; then
        temp_value=$(extract_temp_from_line "${temp_lines[$cpu_idx]}")
        if [[ -n "$temp_value" ]]; then
            log_debug "✅ 模糊匹配: 按顺序分配 CPU${cpu_idx} 温度: ${temp_value}°C"
            echo "${temp_value}"
            return 0
        fi
    fi
    
    # 所有方法都失败，返回N/A
    log_debug "❌ 无法获取 CPU${cpu_idx} 温度"
    echo "N/A"
    return 0
}

# 缓存CPU温度（每颗CPU独立缓存）
get_cpu_temperature_cached() {
    local cpu_idx="$1"
    local cache_key="cpu_${cpu_idx}_temp"
    local temp_value=""
    
    if [[ -z "${CPU_TEMP_CACHE[$cache_key]}" ]]; then
        log_debug "采集 CPU${cpu_idx} 温度并缓存..."
        # 获取温度值
        temp_value=$(get_cpu_temperature "$cpu_idx")
        # 只取第一行（防止意外多行输出）
        temp_value=$(echo "$temp_value" | head -1)
        CPU_TEMP_CACHE[$cache_key]="$temp_value"
    fi
    
    echo "${CPU_TEMP_CACHE[$cache_key]}"
}

# ============================================================================
# CPU信息获取函数（从缓存读取）
# ============================================================================

# 获取CPU Socket数量
get_cpu_socket_count() {
    local sockets=""
    local dmidecode_output=$(cache_dmidecode_processor)
    
    # 方法1：从dmidecode获取
    if [[ -n "$dmidecode_output" ]]; then
        sockets=$(echo "$dmidecode_output" | grep -c "Socket Designation" 2>/dev/null)
        if [[ -n "$sockets" ]] && [[ "$sockets" -gt 0 ]]; then
            echo "$sockets"
            return
        fi
    fi
    
    # 方法2：从lscpu获取
    local lscpu_output=$(cache_lscpu)
    if [[ -n "$lscpu_output" ]]; then
        sockets=$(echo "$lscpu_output" | grep -i "^Socket(s):" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$sockets" ]] && [[ "$sockets" =~ ^[0-9]+$ ]]; then
            echo "$sockets"
            return
        fi
    fi
    
    # 方法3：从/proc/cpuinfo的physical id去重统计
    local proc_output=$(cache_proc_cpuinfo)
    if [[ -n "$proc_output" ]]; then
        sockets=$(echo "$proc_output" | grep -i "physical id" | sort -u | wc -l)
        if [[ -n "$sockets" ]] && [[ "$sockets" -gt 0 ]]; then
            echo "$sockets"
            return
        fi
    fi
    
    echo "1"
}

# 获取每颗CPU的核心数
get_cpu_cores_per_socket() {
    local socket_idx="$1"
    local cores_per_socket=""
    local dmidecode_output=$(cache_dmidecode_processor)
    local current_cpu=0
    local in_cpu=false
    
    # 方法1：从dmidecode获取
    if [[ -n "$dmidecode_output" ]]; then
        while IFS= read -r line; do
            if echo "$line" | grep -qi "Socket Designation"; then
                if [[ $current_cpu -eq $socket_idx ]]; then
                    in_cpu=true
                else
                    in_cpu=false
                fi
                ((current_cpu++))
            fi
            
            if [[ "$in_cpu" == "true" ]]; then
                if echo "$line" | grep -qi "Core Count"; then
                    cores_per_socket=$(echo "$line" | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
                    if [[ -n "$cores_per_socket" ]] && [[ "$cores_per_socket" =~ ^[0-9]+$ ]]; then
                        echo "$cores_per_socket"
                        return
                    fi
                fi
            fi
        done <<< "$dmidecode_output"
    fi
    
    # 方法2：从lscpu获取
    local lscpu_output=$(cache_lscpu)
    if [[ -n "$lscpu_output" ]]; then
        cores_per_socket=$(echo "$lscpu_output" | grep -i "^Core(s) per socket:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$cores_per_socket" ]] && [[ "$cores_per_socket" =~ ^[0-9]+$ ]]; then
            echo "$cores_per_socket"
            return
        fi
    fi
    
    # 方法3：计算总核心数 / socket数
    local total_cores=$(get_cpu_total_cores)
    local sockets=$(get_cpu_socket_count)
    if [[ -n "$total_cores" ]] && [[ -n "$sockets" ]] && [[ "$sockets" -gt 0 ]]; then
        cores_per_socket=$((total_cores / sockets))
        if [[ "$cores_per_socket" -gt 0 ]]; then
            echo "$cores_per_socket"
            return
        fi
    fi
    
    echo "0"
}

# 获取CPU总核心数
get_cpu_total_cores() {
    local cores=""
    local lscpu_output=$(cache_lscpu)
    
    # 方法1：从lscpu获取
    if [[ -n "$lscpu_output" ]]; then
        cores=$(echo "$lscpu_output" | grep -i "^CPU(s):" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$cores" ]] && [[ "$cores" =~ ^[0-9]+$ ]]; then
            echo "$cores"
            return
        fi
    fi
    
    # 方法2：从/proc/cpuinfo获取
    local proc_output=$(cache_proc_cpuinfo)
    if [[ -n "$proc_output" ]]; then
        cores=$(echo "$proc_output" | grep -c "processor" 2>/dev/null)
        if [[ -n "$cores" ]] && [[ "$cores" -gt 0 ]]; then
            echo "$cores"
            return
        fi
    fi
    
    echo "0"
}

# 获取CPU Socket名称（从dmidecode获取）
get_cpu_socket_name() {
    local socket_idx="$1"
    local socket_name=""
    local dmidecode_output=$(cache_dmidecode_processor)
    local current_cpu=0
    
    if [[ -n "$dmidecode_output" ]]; then
        while IFS= read -r line; do
            if echo "$line" | grep -qi "Socket Designation"; then
                if [[ $current_cpu -eq $socket_idx ]]; then
                    socket_name=$(echo "$line" | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
                    echo "$socket_name"
                    return
                fi
                ((current_cpu++))
            fi
        done <<< "$dmidecode_output"
    fi
    
    echo "CPU$socket_idx"
}

# 获取CPU厂商（从lscpu的Vendor ID获取并映射简化）
get_cpu_vendor() {
    local vendor=""
    local vendor_id=""
    local lscpu_output=$(cache_lscpu)
    
    # 方法1：从lscpu获取Vendor ID
    if [[ -n "$lscpu_output" ]]; then
        vendor_id=$(echo "$lscpu_output" | grep -i "Vendor ID" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$vendor_id" ]]; then
            # 映射简化
            if [[ -n "${CPU_VENDOR_MAP[$vendor_id]}" ]]; then
                vendor="${CPU_VENDOR_MAP[$vendor_id]}"
                log_debug "Vendor ID映射: $vendor_id -> $vendor"
                echo "$vendor"
                return
            else
                # 如果没有映射，直接返回原始值
                echo "$vendor_id"
                return
            fi
        fi
    fi
    
    # 方法2：从/proc/cpuinfo获取（备选）
    local proc_output=$(cache_proc_cpuinfo)
    if [[ -n "$proc_output" ]]; then
        vendor_id=$(echo "$proc_output" | grep -i "vendor_id" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$vendor_id" ]]; then
            if [[ -n "${CPU_VENDOR_MAP[$vendor_id]}" ]]; then
                vendor="${CPU_VENDOR_MAP[$vendor_id]}"
                log_debug "从/proc/cpuinfo Vendor ID映射: $vendor_id -> $vendor"
                echo "$vendor"
                return
            else
                echo "$vendor_id"
                return
            fi
        fi
    fi
    
    echo "UNKNOWN"
}

# 获取CPU Family（从dmidecode获取）
get_cpu_family() {
    local family=""
    local dmidecode_output=$(cache_dmidecode_processor)
    
    if [[ -n "$dmidecode_output" ]]; then
        family=$(echo "$dmidecode_output" | grep -i "Family" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$family" ]] && [[ "$family" != "Not Specified" ]] && [[ "$family" != "Unknown" ]]; then
            echo "$family"
            return
        fi
    fi
    
    # 备选：从lscpu获取
    local lscpu_output=$(cache_lscpu)
    if [[ -n "$lscpu_output" ]]; then
        family=$(echo "$lscpu_output" | grep -i "CPU family:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$family" ]]; then
            echo "$family"
            return
        fi
    fi
    
    echo "N/A"
}

# 获取CPU型号
get_cpu_model() {
    local model=""
    local lscpu_output=$(cache_lscpu)
    
    # 方法1：从lscpu获取
    if [[ -n "$lscpu_output" ]]; then
        model=$(echo "$lscpu_output" | grep -i "Model name" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$model" ]]; then
            echo "$model"
            return
        fi
    fi
    
    # 方法2：从/proc/cpuinfo获取
    local proc_output=$(cache_proc_cpuinfo)
    if [[ -n "$proc_output" ]]; then
        model=$(echo "$proc_output" | grep -i "model name" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
        if [[ -n "$model" ]]; then
            echo "$model"
            return
        fi
    fi
    
    echo "UNKNOWN"
}

# 获取CPU基础频率（MHz）
# 优先从model name解析，其次从dmidecode Current Speed解析
get_cpu_base_mhz() {
    local base_mhz=""
    local cpu_model=""
    local dmidecode_output=$(cache_dmidecode_processor)
    local lscpu_output=$(cache_lscpu)
    
    # 方法1：从model name中解析频率
    if [[ -n "$lscpu_output" ]]; then
        cpu_model=$(echo "$lscpu_output" | grep -i "Model name" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
    elif [[ -f "/proc/cpuinfo" ]]; then
        local proc_output=$(cache_proc_cpuinfo)
        cpu_model=$(echo "$proc_output" | grep -i "model name" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//')
    fi
    
    if [[ -n "$cpu_model" ]]; then
        # 匹配 "@ X.XXGHz" 格式
        local freq_match=$(echo "$cpu_model" | grep -oE '@[[:space:]]*[0-9]+\.[0-9]+GHz' | head -1 | sed 's/@[[:space:]]*//' | sed 's/GHz//')
        if [[ -n "$freq_match" ]]; then
            base_mhz=$(echo "$freq_match" | awk '{print int($1 * 1000)}')
            if [[ -n "$base_mhz" ]] && [[ "$base_mhz" -gt 0 ]]; then
                log_debug "从model name解析到频率: $base_mhz MHz"
                echo "$base_mhz"
                return
            fi
        fi
    fi
    
    # 方法2：从dmidecode获取Current Speed
    if [[ -n "$dmidecode_output" ]]; then
        local current_speed=$(echo "$dmidecode_output" | grep -i "Current Speed" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//' | sed 's/[^0-9]//g')
        if [[ -n "$current_speed" ]] && [[ "$current_speed" =~ ^[0-9]+$ ]] && [[ "$current_speed" -gt 0 ]]; then
            log_debug "从dmidecode Current Speed解析到频率: $current_speed MHz"
            echo "$current_speed"
            return
        fi
    fi
    
    # 方法3：从lscpu的CPU MHz获取（作为备选）
    if [[ -n "$lscpu_output" ]]; then
        base_mhz=$(echo "$lscpu_output" | grep -i "CPU MHz" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//' | awk '{print int($1)}')
        if [[ -n "$base_mhz" ]] && [[ "$base_mhz" =~ ^[0-9]+$ ]] && [[ "$base_mhz" -gt 0 ]]; then
            log_debug "从lscpu CPU MHz解析到频率: $base_mhz MHz"
            echo "$base_mhz"
            return
        fi
    fi
    
    echo "0"
}

# ============================================================================
# CSV文件操作函数
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"
    
    local clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    
    if [[ -z "$clean_serial" ]] || [[ "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/cpu_info.csv"
    else
        echo "${dir}/cpu_info_${clean_serial}.csv"
    fi
}

write_csv_header() {
    local output_file="$1"
    echo "server_serial,cpu_socket_name,cpu_vendor,cpu_family,cpu_model,cpu_core_num,cpu_base_mhz,cpu_temperature_c" > "$output_file"
    log_debug "CSV头已写入: $output_file"
}

# ============================================================================
# CPU信息收集主函数
# ============================================================================

collect_cpu_info() {
    local serial="$1"
    local output_file="$2"
    
    log_info "正在收集CPU信息..."
    
    # 初始化Vendor映射表
    init_cpu_vendor_map
    
    # 提前执行dmidecode、lscpu并缓存
    cache_dmidecode_processor
    cache_lscpu
    cache_proc_cpuinfo
    # 提前执行ipmitool并缓存（温度采集）
    cache_ipmitool_sdr
    
    # 获取共享信息（所有CPU相同）
    local vendor=$(get_cpu_vendor)
    local family=$(get_cpu_family)
    local model=$(get_cpu_model)
    local base_mhz=$(get_cpu_base_mhz)
    local socket_count=$(get_cpu_socket_count)
    
    log_info "检测到 $socket_count 颗CPU"
    log_info "CPU厂商: $vendor"
    log_info "CPU Family: $family"
    log_info "CPU基础频率: ${base_mhz} MHz"
    
    if [[ -z "$socket_count" ]] || [[ "$socket_count" -eq 0 ]]; then
        socket_count=1
    fi
    
    local record_count=0
    
    for ((cpu_idx=0; cpu_idx<socket_count; cpu_idx++)); do
        log_debug "正在处理CPU $cpu_idx"
        
        # 获取每颗CPU特有的信息
        local socket_name=$(get_cpu_socket_name "$cpu_idx")
        local cores_per_socket=$(get_cpu_cores_per_socket "$cpu_idx")
        
        # 获取该CPU的温度（独立采集，从ipmitool）
        local cpu_temp=$(get_cpu_temperature_cached "$cpu_idx")
        
        # 如果核心数为0或获取失败，使用总核心数
        if [[ -z "$cores_per_socket" ]] || [[ "$cores_per_socket" -eq 0 ]]; then
            local total_cores=$(get_cpu_total_cores)
            if [[ -n "$total_cores" ]] && [[ "$total_cores" -gt 0 ]]; then
                cores_per_socket=$((total_cores / socket_count))
            else
                cores_per_socket=0
            fi
        fi
        
        # CSV转义处理
        local serial_escaped=$(csv_escape "$serial")
        local socket_name_escaped=$(csv_escape "$socket_name")
        local vendor_escaped=$(csv_escape "$vendor")
        local family_escaped=$(csv_escape "$family")
        local model_escaped=$(csv_escape "$model")
        local cores_escaped=$(csv_escape "$cores_per_socket")
        local base_mhz_escaped=$(csv_escape "$base_mhz")
        local temp_escaped=$(csv_escape "$cpu_temp")
        
        # 输出到CSV
        echo "$serial_escaped,$socket_name_escaped,$vendor_escaped,$family_escaped,$model_escaped,$cores_escaped,$base_mhz_escaped,$temp_escaped" >> "$output_file"
        
        ((record_count++))
        
        log_info "✅ CPU $cpu_idx ($socket_name): $model, 温度: ${cpu_temp}°C"
        log_debug "   - Vendor: $vendor"
        log_debug "   - Family: $family"
        log_debug "   - Cores: $cores_per_socket"
        log_debug "   - Base MHz: $base_mhz"
        log_debug "   - Temperature: $cpu_temp°C"
    done
    
    echo "$record_count"
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_header "服务器CPU信息收集工具 (含CPU温度)"
    
    SYSTEM_SERIAL=$(get_system_serial)
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")
    
    # 检查必要命令
    local missing_tools=()
    
    if ! command -v dmidecode &>/dev/null; then
        missing_tools+=("dmidecode")
    fi
    
    if ! command -v lscpu &>/dev/null; then
        log_warn "lscpu 命令未找到，将使用 /proc/cpuinfo 作为备选"
    fi
    
    # 检查ipmitool命令（用于温度采集）
    if ! command -v ipmitool &>/dev/null; then
        log_warn "ipmitool 命令未找到，无法获取CPU温度"
        log_info "请根据系统类型安装："
        echo "  - CentOS/RHEL: yum install -y ipmitool" >&2
        echo "  - Ubuntu/Debian: apt-get install -y ipmitool" >&2
    fi
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_warn "缺少以下工具: ${missing_tools[*]}"
        log_info "请根据系统类型安装："
        echo "  - CentOS/RHEL: yum install -y dmidecode util-linux" >&2
        echo "  - Ubuntu/Debian: apt-get install -y dmidecode util-linux" >&2
        echo ""
    fi
    
    # 检查权限（dmidecode和ipmitool需要sudo）
    if ! sudo -v 2>/dev/null; then
        log_warn "无法获取sudo权限，部分信息可能不完整（dmidecode/ipmitool需要root权限）"
        echo ""
        read -p "是否继续执行（部分信息可能不完整）？[y/N] " -n 1 -r < /dev/tty
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    if [[ ! -d "$OUTPUT_DIR" ]]; then
        mkdir -p "$OUTPUT_DIR" 2>/dev/null || {
            log_error "无法创建输出目录: $OUTPUT_DIR"
            exit 1
        }
    fi
    
    write_csv_header "$OUTPUT_FILE"
    
    local record_count
    record_count=$(collect_cpu_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")
    
    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2
    
    if [[ -f "$OUTPUT_FILE" ]]; then
        local line_count=$(($(wc -l < "$OUTPUT_FILE") - 1))
        echo -e "📊 CPU记录: ${BLUE}$line_count${NC} 条" >&2
        print_separator
        echo -e "${YELLOW}📄 内容预览:${NC}" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 信号处理和脚本入口
# ============================================================================

set -eo pipefail 2>/dev/null || true

show_help() {
    cat << EOF
服务器CPU信息收集工具（含CPU温度）

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录 (默认: 当前目录)
    -s, --serial SN     手动指定系统序列号

功能说明:
    - 支持多颗CPU，每颗CPU输出一条记录
    - 每颗CPU独立采集温度
    - dmidecode、lscpu、/proc/cpuinfo 结果缓存，只执行一次
    - cpu_socket_name: 从dmidecode -t processor的Socket Designation获取
    - cpu_vendor: 从lscpu的Vendor ID获取并映射简化 (GenuineIntel->Intel, AuthenticAMD->AMD)
    - cpu_family: 从dmidecode -t processor的Family获取
    - cpu_model: 从lscpu的Model name获取
    - cpu_core_num: 从dmidecode的Core Count或lscpu获取
    - cpu_base_mhz: 优先从model name解析(@ X.XXGHz)，其次从dmidecode Current Speed
    - cpu_temperature_c: 每颗CPU独立温度采集，从ipmitool sdr list获取

温度采集方式（仅从ipmitool获取）:
    从 ipmitool sdr list | grep CPU 获取
    自动检测CPU编号起始值（从0或从1开始）
    支持格式: CPU0_Temp | 36 degrees C | ok 或 CPU1_Temp | 34 degrees C | ok

输出格式（8列）:
    server_serial,cpu_socket_name,cpu_vendor,cpu_family,cpu_model,cpu_core_num,cpu_base_mhz,cpu_temperature_c

Vendor映射:
    GenuineIntel -> Intel
    AuthenticAMD -> AMD
    HygonGenuine -> Hygon

依赖工具:
    - dmidecode: 获取CPU详细信息 (需要root权限)
    - lscpu: 获取CPU详细信息 (推荐)
    - ipmitool: 获取CPU温度 (必须，从BMC/IPMI获取)
    - /proc/cpuinfo: 备选信息来源

示例:
    sudo $SCRIPT_NAME
    sudo $SCRIPT_NAME -o /tmp
    sudo $SCRIPT_NAME -s ABC123456
    sudo $SCRIPT_NAME -d
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--debug)
                DEBUG="true"
                shift
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                shift 2
                ;;
            -s|--serial)
                SYSTEM_SERIAL="$2"
                shift 2
                ;;
            *)
                log_error "未知选项: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

parse_args "$@"
main

# ============================================================================
# 结束
# ============================================================================
