#!/bin/bash
# ============================================================================
# 服务器网卡信息收集脚本（含光模块信息 + PCIe slot）
#
# 输出：31 列 CSV，一行 = 一个物理端口
#   server_serial,nic_vendor,nic_model,nic_submodel,nic_product,nic_serial,
#   nic_speed_gb,nic_port_num,nic_port_subnum,nic_firmware,nic_interface_name,
#   nic_link_detected,nic_mac,nic_lldp_sw,nic_lldp_port,
#   nic_pcie_bus_id,nic_port_pcie_bus_id,pcie_slot,
#   pcie_vendor_id,pcie_product_id,
#   pcie_gen,pcie_link_cap,pcie_link_sta,
#   optics_vendor,optics_pn,optics_ver,optics_sn,optics_tx_power_mw,
#   optics_rx_power_mw,optics_temperature_c,errors
#
# ----------------------------------------------------------------------------
# 设计要点（改代码前先读这里）
# ----------------------------------------------------------------------------
#   * 多端口网卡：同一 PCI bus 上的所有端口共享"卡级信息"（厂商/型号/
#     固件/PCIe 能力），每端口各占一行，卡级字段重复。
#     nic_port_subnum = 端口序号（从 1 开始），nic_port_num = 总端口数。
#   * 卡级字段以该卡【第一个端口】的 PCI 地址为准；端口级字段各取各的。
#     PCIe 相关字段例外：多口卡各口是独立 PCI function，插槽/链路可能
#     不同，因此取【本端口】的地址（含 AER，按端口读）。
#   * 所有外部命令都允许失败：取不到值一律填 N/A / UNKNOWN，绝不中断采集。
#   * 不用 set -e，只用 set -o pipefail：采集脚本在"半残环境"下必须跑完，
#     某条命令失败应当降级为"该字段为空"，而不是中途退出产出残缺 CSV。
#
# ----------------------------------------------------------------------------
# errors 列的设计原则
# ----------------------------------------------------------------------------
#   只记录【可能由硬件引起、或预示硬件故障】的项。无异常时为 0。
#   读不到 / 字段缺失 / 无法判断 → 一律不报告（"缺数据"不等于"有故障"）。
#
#   收录（ethtool -S 计数器，非零才输出）：
#     信号质量  rx_crc_errors / rx_symbol_errors / rx_phy_errors / tx_phy_errors
#     帧结构    rx_frame_errors / rx_alignment_errors
#               （FCS/对齐错 → 物理层比特错误，是硬件信号）
#     发送异常  tx_carrier_errors / tx_aborted_errors / tx_window_errors /
#               tx_heartbeat_errors
#     汇总      rx_errors / tx_errors / rx_mac_errors / tx_mac_errors
#     其他      collisions / tx_timeout / rx_nohandler
#               （名称兜底关键字含 err/crc/timeout/collision/nohandler，
#                 覆盖白名单未列全的驱动命名）
#
#   不收录（病因不属于硬件，收进来会把排查方向带偏）：
#     长度类    rx_oversize / rx_undersize / rx_jabbers / rx_fragments /
#               rx_long_length / rx_short_length / rx_length_errors
#               → 帧长越界 = MTU/隧道配置或对端问题，不是网卡劣化
#     主机类    rx_missed / rx_fifo / rx_over_errors / rx_no_buffer
#               → 主机 CPU、中断或 ring 配置不足
#     协议类    rx_csum_offload / checksum
#               → 坏校验和由【发送方】产生
#     判定顺序是 DENYLIST 优先：长度类计数器的名字含 err/oversize 等词，
#     仅从白名单删除无效，必须由 DENYLIST 先 continue 掉。
#     dropped / discard 类默认也不收（丢包通常是拥塞而非介质故障），
#     可用 --include-drops 显式打开。
#
#   额外并入的非计数器指标：
#     carrier_changes  链路翻转次数（仅在 > 10 次/天时输出）—— 介质劣化
#                      最灵敏的指标；*_errors 在瞬时断链时往往完全不涨。
#     link_down        当前链路 down，且该口【曾经跑过流量】。
#     pcie_aer_*       PCIe 可纠正/非致命/致命错误。ethtool -S 完全看不到，
#                      典型成因是坏插槽、转接卡、金手指氧化。
#     optics_rx_low    收光跌破模块自带 DDM 门限（仅链路 up 时判）。
#
#     值的语义：计数器写 name:数字；AER 写 *_aer_*:可纠正:非致命:致命。
#
# ----------------------------------------------------------------------------
# 关键实现约定
# ----------------------------------------------------------------------------
#   1) 热路径零 fork。
#      ethtool -S 有 300+ 个计数器，逐行 fork（echo|awk|tr）会让 8 口机器
#      多出上万次进程创建。计数器解析一律用纯 bash 参数展开
#      （${var%%:*} / ${rest#*:} / ${var//[[:space:]]/}），每行 0 次 fork。
#      端口循环里的字段切分用 IFS='|' read，不要 echo|cut。
#
#   2) 用 `if ! out=$(cmd); then` 判断命令失败，不要先赋值再看 $?。
#      `out=$(cmd)` 之后 $? 是【赋值语句】的状态（恒为 0），捕不到 cmd 失败。
#
#   3) 空数组必须逐行 printf，且为空时一个字节都不输出。
#      `echo "${arr[@]}"` 在空数组时会输出一个空行，调用方按行读会得到
#      长度 1 的数组（元素是空串），判空失效。调用方用 mapfile 读。
#
#   4) 判据先校验取值格式/完整性，再判异常。
#      直接拿字段值和期望值比较，字段没被完整捕获时就会落到"异常"分支，
#      从而误报。读不到 ≠ 有问题。
#
#   5) 收光判据只在【链路 up】时生效（carrier=1）。
#      链路 down 时对端不发光，收光必然是物理下限，那是必然结果而非故障。
#      与 link_down 分工：optics_rx_low 只问"当前是否在运行"（看 carrier），
#      link_down 才负责区分"线断了"还是"本来就没插过"（还要看历史流量）。
#
#   6) 判别 InfiniBand 接口按【内核设备类型】，不按接口名（名字可被
#      ip link set name 任意重命名）。判据优先级见 _is_ib_iface()。
#
#   7) SUDO 变量：root 下为空，非 root 下 "sudo"（绝不交互式索要密码）。
# ============================================================================


SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
OUTPUT_FILE=""
SYSTEM_SERIAL=""          # 显式指定（-s）时不再自动探测，见 B2
SERIAL_EXPLICIT=false     # -s 是否被显式指定过
DEBUG="${DEBUG:-false}"
INCLUDE_DROPS="${INCLUDE_DROPS:-false}"   # --include-drops：把 dropped 计入 errors

# 系统 uptime（天）。carrier_changes 判定要用"次/天"的速率，而 uptime
# 在所有端口上是同一个值，因此在 main 里读一次即可，不必每口重读。
# 读不到时为空串，_nic_cc_is_flapping 会退回保守判断。
UPTIME_DAYS=""

# lspci -vv 输出按 BDF 缓存：gen/cap/sta 三个函数都用它，避免重复调用 lspci
declare -A LSPCI_NIC_CACHE=()

# mlxlink -m 输出按 BDF 缓存。一块双口/四口卡共享同一 PCI 设备，
# 模块信息对同一卡的各口是同一份，而 mlxlink 单次调用极慢（数秒），
# 必须缓存，否则时间随端口数线性增长。
declare -A MLXLINK_CACHE=()

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2 || true; }

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ============================================================================
# SUDO 变量定义
#   - root 下 $SUDO 为空；非 root 下 $SUDO="sudo -n"
# ============================================================================

if [[ $EUID -ne 0 ]]; then
    if command -v sudo &>/dev/null; then
        SUDO="sudo -n"
    else
        SUDO=""
    fi
else
    SUDO=""
fi
export SUDO

# ============================================================================
# CSV 转义
# ============================================================================

csv_escape() {
    local field="$1"
    if [[ -z "$field" ]]; then
        printf ''
        return
    fi
    if [[ "$field" == *","* || "$field" == *"\""* || "$field" == *$'\n'* ]]; then
        field=$(printf '%s' "$field" | sed 's/"/""/g')
        printf '"%s"' "$field"
    else
        printf '%s' "$field"
    fi
}

# ============================================================================
# 系统序列号
# ============================================================================

get_serial_from_dmidecode() {
    local serial
    serial=$($SUDO dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" && "$serial" != "Not Specified" && "$serial" != "Unknown" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$($SUDO cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" && "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" && "$serial" != "00000000" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(get_serial_from_dmidecode get_serial_from_sysfs get_serial_from_hostid)
    log_info "正在获取系统序列号..."
    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            log_info "通过 ${method#get_serial_from_} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done
    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# Vendor ID 映射
# ============================================================================

declare -A VENDOR_ID_MAP

init_vendor_id_map() {
    log_debug "初始化Vendor ID映射表..."
    VENDOR_ID_MAP["8086"]="Intel"
    VENDOR_ID_MAP["10ec"]="Realtek"
    VENDOR_ID_MAP["14e4"]="Broadcom"
    VENDOR_ID_MAP["1969"]="Atheros"
    VENDOR_ID_MAP["10de"]="NVIDIA"
    VENDOR_ID_MAP["15b3"]="Mellanox"
    VENDOR_ID_MAP["1d22"]="BAIDU"
    VENDOR_ID_MAP["1af4"]="Red Hat VirtIO"
    VENDOR_ID_MAP["1a6e"]="Amazon"
    VENDOR_ID_MAP["15ad"]="VMware"
    VENDOR_ID_MAP["1ab8"]="AMD"
    VENDOR_ID_MAP["10b5"]="PLX"
    VENDOR_ID_MAP["11ab"]="Marvell"
    VENDOR_ID_MAP["13c0"]="Huawei"
    VENDOR_ID_MAP["19e5"]="Huawei"
    VENDOR_ID_MAP["1d0f"]="Amazon"
    VENDOR_ID_MAP["1d6b"]="Linux Foundation"
}

# ============================================================================
# PCIe slot 映射
# ============================================================================

declare -A PCI_SLOT_MAP=()
# BDF → bus 的反查表，与 PCI_SLOT_MAP 同步构建。
# 用途：get_pcie_slot 的第二轮容错要按 bus 分组。bus 在建表时算一次存进来，
# 查表即得，避免在内层对每个 key 反复跑 cut。
declare -A PCI_SLOT_BUS=()
PCI_SLOT_MAP_LOADED=false

_normalize_dmi_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    if [[ "$a" =~ ^([0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2})$ ]]; then
        a="${a}.0"
    fi
    if [[ "$a" =~ ^([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]]; then
        a="0000:$a"
    fi
    echo "$a"
}

load_pci_slot_map() {
    [[ "$PCI_SLOT_MAP_LOADED" == "true" ]] && return

    log_debug "加载 dmidecode -t slot 到内存..."

    local cur=""
    while IFS= read -r line; do
        if [[ "$line" =~ Designation:[[:space:]]*(.+) ]]; then
            cur="${BASH_REMATCH[1]}"
        fi
        if [[ "$line" =~ Bus[[:space:]]Address:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            local key
            key=$(_normalize_dmi_addr "${BASH_REMATCH[1]}")
            if [[ -n "$key" ]]; then
                PCI_SLOT_MAP["$key"]="$cur"
                # 同步记录 bus 字段（0000:bb:dd.f 的第 2 段），供第二轮
                # 容错直接查表，避免在循环里 fork cut。
                PCI_SLOT_BUS["$key"]="${key#*:}"
                PCI_SLOT_BUS["$key"]="${PCI_SLOT_BUS[$key]%%:*}"
            fi
        fi
    done < <($SUDO dmidecode -t slot 2>/dev/null)

    PCI_SLOT_MAP_LOADED=true
    log_debug "PCI slot 表加载完成，共 ${#PCI_SLOT_MAP[@]} 条"

    if [[ "${DEBUG}" == "true" ]]; then
        local k
        for k in "${!PCI_SLOT_MAP[@]}"; do
            log_debug "  $k → ${PCI_SLOT_MAP[$k]}"
        done
    fi
}

get_pcie_slot() {
    local bdf="$1"
    # 无效输入直接返回，别去拼一个不存在的 sysfs 路径
    if [[ -z "$bdf" ]] || [[ "$bdf" == "N/A" ]] || [[ "$bdf" == "Unknown" ]]; then
        echo "N/A"; return 0
    fi

    bdf=$(echo "$bdf" | tr 'A-F' 'a-f')
    # dmidecode 的 Bus Address 一律带域号，这里补齐成 0000:bb:dd.f
    if [[ "$bdf" =~ ^[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
        bdf="0000:$bdf"
    fi

    local realpath
    realpath=$(readlink -f "/sys/bus/pci/devices/$bdf" 2>/dev/null)
    [[ -z "$realpath" ]] && { echo "N/A"; return 0; }

    # 沿 sysfs 符号链接的真实路径向上取出整条 PCIe 拓扑链（网卡 → 桥 → 根），
    # tac 反转成"从网卡自己往上"的顺序，这样第一个命中的就是最深（最精确）
    # 的那个槽位。
    local chain
    chain=$(echo "$realpath" | tr '/' '\n' \
            | grep -E '^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$' \
            | tac)

    # ---- 第一轮：精确匹配完整 BDF ----
    local p
    while IFS= read -r p; do
        if [[ -n "${PCI_SLOT_MAP[$p]+x}" ]]; then
            log_debug "  pcie_slot: $bdf → ${PCI_SLOT_MAP[$p]} (严格匹配 $p)"
            echo "${PCI_SLOT_MAP[$p]}"
            return 0
        fi
    done <<< "$chain"

    # ---- 第二轮：同 bus 容错 ----
    # 某些 BIOS 报的 Bus Address 是桥的地址（dd.f 与网卡不同），严格匹配会
    # 落空，但 bus 仍是对的，故按 bus 再匹配一次。
    # 仅当该 bus 在槽位表中【唯一】时才容错：同 bus 有多个槽位条目时无法
    # 判断网卡插在哪个槽，返回 N/A 比返回遍历顺序决定的随机结果更安全。
    local bus
    while IFS= read -r p; do
        # 纯参数展开取 bus，不再 `echo | cut` fork
        bus="${p#*:}"; bus="${bus%%:*}"

        local k matches=()
        for k in "${!PCI_SLOT_BUS[@]}"; do
            [[ "${PCI_SLOT_BUS[$k]}" == "$bus" ]] && matches+=("$k")
        done

        if [[ ${#matches[@]} -eq 1 ]]; then
            log_debug "  pcie_slot: $bdf → ${PCI_SLOT_MAP[${matches[0]}]} (同 bus 唯一容错 $p ≈ ${matches[0]})"
            echo "${PCI_SLOT_MAP[${matches[0]}]}"
            return 0
        elif [[ ${#matches[@]} -gt 1 ]]; then
            log_debug "  pcie_slot: $bdf 的 bus $bus 在槽位表中不唯一（${#matches[@]} 条），放弃容错"
        fi
    done <<< "$chain"

    log_debug "  pcie_slot: $bdf 未匹配，链路: $(echo "$chain" | tr '\n' '|' | sed 's/|$//')"
    echo "N/A"
    return 0
}

# ============================================================================
# ★ InfiniBand 接口判定（不依赖接口名）
#
#   判据（优先级从高到低）：
#     1) /sys/class/net/<iface>/type == 32 (ARPHRD_INFINIBAND)  → 是
#     2) /sys/class/net/<iface>/type == 1  (ARPHRD_ETHER)       → 否
#     3) /sys/class/net/<iface>/type == 772 (ARPHRD_LOOPBACK)   → 否
#     4) ip -o link show <iface> 输出含 link/infiniband         → 是
#     5) ip -o link show <iface> 输出含 link/ether              → 否
#     6) /sys/class/net/<iface>/device/infiniband/ 目录存在      → 是
#     7) 其余                                                   → 否
#
#   注意：接口名可被 ip link set name 任意重命名，因此不再用 ^ib 前缀判定。
# ============================================================================

_is_ib_iface() {
    local iface="$1"
    [[ -z "$iface" ]] && return 1
    [[ -e "/sys/class/net/$iface" ]] || return 1

    # ---- 1) sysfs type（最权威）----
    local tfile="/sys/class/net/$iface/type"
    if [[ -r "$tfile" ]]; then
        local t
        t=$(cat "$tfile" 2>/dev/null | tr -d ' \n')
        if [[ -n "$t" ]]; then
            case "$t" in
                32)  return 0 ;;   # ARPHRD_INFINIBAND
                1)   return 1 ;;   # ARPHRD_ETHER
                772) return 1 ;;   # ARPHRD_LOOPBACK
            esac
        fi
    fi

    # ---- 2) ip link 输出 ----
    if command -v ip &>/dev/null; then
        local ipout
        ipout=$(ip -o link show "$iface" 2>/dev/null)
        if [[ -n "$ipout" ]]; then
            if echo "$ipout" | grep -q 'link/infiniband'; then
                return 0
            fi
            if echo "$ipout" | grep -q 'link/ether'; then
                return 1
            fi
        fi
    fi

    # ---- 3) device/infiniband 子目录 ----
    if [[ -d "/sys/class/net/$iface/device/infiniband" ]]; then
        return 0
    fi

    return 1
}

# ============================================================================
# 网卡过滤
# ============================================================================

is_virtual_function() {
    local iface="$1"
    local pci_addr="$2"

    if [[ -n "$pci_addr" ]]; then
        local physfn_link="/sys/bus/pci/devices/$pci_addr/physfn"
        if [[ -L "$physfn_link" ]]; then
            log_debug "网卡 $iface (PCI: $pci_addr) 是VF (检测到physfn链接)"
            return 0
        fi
    fi

    if [[ -n "$pci_addr" ]]; then
        local sriov_file="/sys/bus/pci/devices/$pci_addr/sriov_numvfs"
        if [[ -f "$sriov_file" ]]; then
            log_debug "网卡 $iface (PCI: $pci_addr) 是PF (检测到sriov_numvfs文件)"
            return 1
        fi
    fi

    if [[ "$iface" =~ v[0-9]+$ ]] || [[ "$iface" =~ _v[0-9]+ ]] || [[ "$iface" =~ -vf[0-9]+ ]]; then
        log_debug "网卡 $iface 是VF (接口名称匹配VF模式)"
        return 0
    fi

    if [[ -L "/sys/class/net/$iface/device" ]]; then
        local dev_path=$(readlink -f "/sys/class/net/$iface/device" 2>/dev/null)
        if [[ -n "$dev_path" ]]; then
            if [[ "$dev_path" =~ virtfn[0-9]+ ]] || [[ "$dev_path" =~ /vf[0-9]+/ ]]; then
                log_debug "网卡 $iface 是VF (设备路径包含virtfn或vf)"
                return 0
            fi
        fi
    fi

    if [[ -n "$pci_addr" ]]; then
        local pci_info=$(lspci -v -s "$pci_addr" 2>/dev/null)
        if echo "$pci_info" | grep -qi "Virtual Function"; then
            log_debug "网卡 $iface 是VF (lspci标记为Virtual Function)"
            return 0
        fi
    fi

    return 1
}

is_physical_nic() {
    local iface="$1"

    [[ "$iface" == "lo" ]] && return 1

    # ================================================================
    # ★ InfiniBand 接口过滤（交由 collect_ib.sh 处理）
    #   判据来自内核设备类型 / ip link 输出 / device/infiniband 目录，
    #   不依赖接口名（接口名可被 ip link set name 任意重命名）。
    # ================================================================
    if _is_ib_iface "$iface"; then
        log_debug "网卡 $iface 是 InfiniBand 接口，已过滤（交由 collect_ib.sh 处理）"
        return 1
    fi

    if [[ "$iface" =~ ^(veth|docker|br-|virbr|tun|tap|vnet|bond|dummy|sit|ip6tnl|gre|gretap|erspan) ]]; then
        log_debug "网卡 $iface 是虚拟接口，已过滤"
        return 1
    fi

    if [[ "$iface" =~ ^usb ]]; then
        log_debug "网卡 $iface 是 USB 网卡，已过滤"
        return 1
    fi

    if [[ ! -L "/sys/class/net/$iface/device" ]]; then
        log_debug "网卡 $iface 没有device链接，可能是虚拟接口"
        return 1
    fi

    local dev_path
    dev_path=$(readlink -f "/sys/class/net/$iface/device" 2>/dev/null)

    if [[ "$dev_path" == *"/usb"* ]]; then
        log_debug "网卡 $iface 的 device 路径含 usb ($dev_path)，已过滤"
        return 1
    fi

    if [[ "$dev_path" =~ virtfn[0-9]+ ]] || [[ "$dev_path" =~ /vf[0-9]+/ ]]; then
        log_debug "网卡 $iface 是VF (路径含 virtfn/vf)，已过滤"
        return 1
    fi

    local pci_addr
    pci_addr=$(basename "$dev_path" 2>/dev/null)

    if [[ ! "$pci_addr" =~ ^([0-9a-fA-F]{4}:)?[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$ ]]; then
        log_debug "网卡 $iface 的 pci_addr '$pci_addr' 不是标准 PCI 格式，已过滤"
        return 1
    fi

    if is_virtual_function "$iface" "$pci_addr"; then
        return 1
    fi

    return 0
}

get_physical_nics() {
    local nics=()
    local pf_count=0
    local vf_count=0
    local virtual_count=0

    log_info "正在扫描网卡并过滤Virtual Function (VF)..." >&2

    # 用 mapfile 按行遍历：接口名不可能含换行，这样比 `for x in $(ls)`
    # 更安全（不受 IFS 影响），也不需要 subshell。
    local iface
    while IFS= read -r iface; do
        [[ -z "$iface" ]] && continue
        if is_physical_nic "$iface"; then
            nics+=("$iface")
            ((pf_count++)) || true
            log_debug "✅ 保留物理网卡: $iface"
        else
            # 只做分类计数与日志，判定逻辑本身在 is_physical_nic 里
            if [[ "$iface" == "lo" ]]; then
                continue
            elif _is_ib_iface "$iface"; then
                ((virtual_count++)) || true
                log_debug "⏭️  跳过 InfiniBand 接口: $iface"
            elif [[ "$iface" =~ ^(veth|docker|br-|virbr|tun|tap|vnet|bond|dummy|sit|ip6tnl|gre|gretap|erspan) ]]; then
                ((virtual_count++)) || true
                log_debug "⏭️  跳过虚拟接口: $iface"
            else
                ((vf_count++)) || true
                log_debug "⏭️  跳过非物理网卡: $iface"
            fi
        fi
    done < <(ls /sys/class/net/ 2>/dev/null)

    log_info "扫描完成: 物理网卡 ${#nics[@]} 个, 非物理网卡/VF ${vf_count} 个, 虚拟接口 ${virtual_count} 个" >&2

    # 契约：每行一个接口名；数组为空时一个字节都不输出。
    # 调用方用 mapfile 按行读取，空数组就是真的空数组。
    # (`echo "${arr[@]}"` 在空数组时会输出一个空行，调用方会得到长度 1 的
    #  数组而判空失效，进而拿空接口名跑完整流程、产出垃圾行。)
    [[ ${#nics[@]} -gt 0 ]] && printf '%s\n' "${nics[@]}"
    return 0
}

# ============================================================================
# PCI Bus
# ============================================================================

get_pci_bus_base() {
    local pci_addr="$1"
    local base=""
    if [[ -n "$pci_addr" ]]; then
        # 标准格式 bb:dd.f → 取 bb:dd；否则退化为按 '.' 切掉功能号
        if [[ "$pci_addr" =~ ^([0-9a-fA-F]{2}:[0-9a-fA-F]{2})\.[0-9]+$ ]]; then
            base="${BASH_REMATCH[1]}"
        else
            base=$(echo "$pci_addr" | cut -d'.' -f1)
        fi
    fi
    echo "$base"
    return 0
}

# 一次性建立 interface → bus_base 映射，供端口分组查表使用。
# 只遍历一次 /sys/class/net；若在每个 bus 上重扫，最坏是 O(bus数 × 网卡数)
# 次外部调用（is_virtual_function 可能触发 lspci）。
#
# 用全局关联数组而不是 nameref（local -n）传引用：nameref 需要 bash 4.3+，
# CentOS 7 自带 bash 4.2。本脚本只用 declare -A（bash 4.0 即可）。
declare -A IFACE_BUS_MAP=()

build_iface_bus_map() {
    IFACE_BUS_MAP=()

    local nic pci
    while IFS= read -r nic; do
        [[ -z "$nic" ]] && continue
        [[ -L "/sys/class/net/$nic/device" ]] || continue

        pci=$(get_pci_address "$nic")
        [[ -z "$pci" ]] && continue

        # VF 不算独立端口：多个 VF 共享同一个物理口，计入会让端口数虚高
        is_virtual_function "$nic" "$pci" && continue

        IFACE_BUS_MAP["$nic"]="$(get_pci_bus_base "$pci")"
    done < <(ls /sys/class/net/ 2>/dev/null)

    return 0
}

# 取某个 bus 上的所有物理端口，按接口名排序保证输出稳定
get_ports_for_bus() {
    local bus_base="$1"
    local ports=()
    local nic

    if [[ -n "$bus_base" ]]; then
        for nic in "${!IFACE_BUS_MAP[@]}"; do
            [[ "${IFACE_BUS_MAP[$nic]}" == "$bus_base" ]] && ports+=("$nic")
        done
    fi

    # 排序：端口顺序必须稳定，否则同一台机器两次跑出来的 subnum 会对不上
    if [[ ${#ports[@]} -gt 1 ]]; then
        local sorted
        sorted=$(printf '%s\n' "${ports[@]}" | sort)
        mapfile -t ports <<< "$sorted"
    fi

    [[ ${#ports[@]} -gt 0 ]] && printf '%s\n' "${ports[@]}"
    return 0
}

# ============================================================================
# 网卡信息
# ============================================================================

get_pci_address() {
    local iface="$1"
    local pci_addr=""
    local dev="/sys/class/net/$iface/device"

    if [[ -L "$dev" ]]; then
        # 必须 readlink -f：/device 指向 ../../../0000:bb:dd.f，设备可能挂在
        # 桥下面，直接用 basename 会拿到 ".." 之类的中间段。
        pci_addr=$(basename "$(readlink -f "$dev" 2>/dev/null)" 2>/dev/null)
    fi
    echo "$pci_addr"
    return 0
}

ensure_domain_pci_addr() {
    local addr="$1"
    addr=$(echo "$addr" | tr 'A-F' 'a-f' | tr -d ' ')
    # dmidecode / lspci 有时省略域号，补成 0000: 前缀以便统一查表
    if [[ "$addr" =~ ^[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
        echo "0000:$addr"
    else
        echo "$addr"
    fi
    return 0
}

get_nic_pcie_bus_id() {
    local iface="$1"

    local dev="/sys/class/net/$iface/device"
    [[ -L "$dev" ]] || { echo "N/A"; return 0; }

    local pci_addr
    pci_addr=$(basename "$(readlink -f "$dev" 2>/dev/null)" 2>/dev/null)
    [[ -z "$pci_addr" ]] && { echo "N/A"; return 0; }

    # 首选 lspci -D，它给出规范化的 0000:bb:dd.f
    local bus_id
    bus_id=$(lspci -D -s "$pci_addr" 2>/dev/null | awk '{print $1}')
    if [[ -n "$bus_id" ]]; then
        echo "$bus_id"
        return 0
    fi

    # lspci 不可用（未装 pciutils）时，从 sysfs 路径自己补域号
    ensure_domain_pci_addr "$pci_addr"
    return 0
}

# 取网卡厂商名。
#
# sysfs 的 vendor id 是权威来源，lspci 只作美化：
# 先拿 sysfs 的 id 查映射表，查到就用表里的名字；表里没有、且 lspci 给出了
# 像样的名字时才采信 lspci，并过滤掉占位词。
#
# 不能反过来（lspci 优先、空了再查 sysfs）：pci.ids 里没有这张卡时 lspci
# 输出的不是空串，而是 "Unknown device 1d22:0001" / "Device 1d22:0001" /
# "1d22:0001" 这类占位值，取首词后得到 "Unknown" / "Device" / "1d22:0001"。
# 它们都非空，sysfs 兜底就永远不会触发。
get_nic_vendor() {
    local pci_addr="$1"

    if [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]]; then
        echo "UNKNOWN"; return 0
    fi

    local key vid vendor=""
    key=$(ensure_domain_pci_addr "$pci_addr")

    # ---- 1) 权威：sysfs vendor id（形如 0x15b3），不依赖 pciutils ----
    local vendor_file="/sys/bus/pci/devices/$key/vendor"
    if [[ -f "$vendor_file" ]]; then
        vid=$(sed 's/^0x//; s/[[:space:]]//g' "$vendor_file" 2>/dev/null)
        vid="${vid,,}"          # 统一小写再查表（表是小写）
        [[ -n "${VENDOR_ID_MAP[$vid]}" ]] && vendor="${VENDOR_ID_MAP[$vid]}"
    fi

    # ---- 2) 映射表没命中时，才考虑 lspci 给出的名字 ----
    # 但必须排除 lspci 的"占位词"：它们不是厂商名。
    if [[ -z "$vendor" ]]; then
        local pci_info name
        pci_info=$(lspci -s "$pci_addr" 2>/dev/null | head -1)
        if [[ -n "$pci_info" ]]; then
            # 跳过 "bb:dd.f Class: " 前缀，取厂商字段的第一个词
            name=$(echo "$pci_info" | awk -F': ' '{print $2}' | awk '{print $1}')
            case "$name" in
                # lspci 认不出这张卡时的各种占位输出，都不是厂商名
                Unknown|unknown|Device|device) name="" ;;
            esac
            # 裸 VID（如 1d22）或 "1d22:0001" 也不是名字
            if [[ "$name" =~ ^[0-9a-fA-F]{4}(:[0-9a-fA-F]{4})?$ ]]; then
                name=""
            fi
            # lspci 偶尔会输出 "[AMD]" 这种带方括号的归一化名字，去掉括号
            name=$(echo "$name" | tr -d '[]')
            vendor="$name"
        fi
    fi

    echo "${vendor:-UNKNOWN}"
    return 0
}

get_nic_model() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]] && { echo "N/A"; return 0; }

    local line
    line=$(lspci -s "$pci_addr" 2>/dev/null | head -1)
    if [[ -z "$line" ]]; then
        line=$($SUDO lspci -s "$pci_addr" 2>/dev/null | head -1)
    fi
    [[ -z "$line" ]] && { echo "N/A"; return 0; }

    local model
    model=$(echo "$line" | sed -E 's/^[0-9a-fA-F:.]+ [^:]+: //')
    [[ -z "$model" ]] && { echo "N/A"; return 0; }

    echo "$model"
    return 0
}

get_nic_submodel() {
    local pci_addr="$1"
    local model=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info=$(lspci -vvv -s "$pci_addr" 2>/dev/null)
        local subsystem_line=$(echo "$pci_info" | grep -i "^[[:space:]]*Subsystem:" | head -1)
        if [[ -n "$subsystem_line" ]]; then
            model=$(echo "$subsystem_line" | sed 's/^[[:space:]]*Subsystem:[[:space:]]*//' | sed 's/[[:space:]]*$//')
            if [[ -n "$model" ]]; then
                log_debug "从Subsystem获取到子型号: $model"
                echo "$model"
                return 0
            fi
        fi
    fi

    if [[ -n "$pci_addr" ]]; then
        local pci_name=$(lspci -s "$pci_addr" 2>/dev/null | head -1)
        if [[ -n "$pci_name" ]]; then
            model=$(echo "$pci_name" | awk -F': ' '{print $2}')
            if [[ -n "$model" ]]; then
                log_debug "从设备名称获取到子型号: $model"
                echo "$model"
                return 0
            fi
        fi
    fi

    echo "UNKNOWN"
    return 0
}

get_nic_product() {
    local pci_addr="$1"
    local product=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info=$(lspci -vvv -s "$pci_addr" 2>/dev/null)
        product=$(echo "$pci_info" | grep -i "\[PN\]" | head -1 | sed 's/.*\[PN\]//' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//' | sed 's/^Part number: //')
        if [[ -n "$product" ]]; then
            echo "$product"
            return
        fi
    fi

    echo "N/A"
}

get_nic_serial() {
    local pci_addr="$1"
    local serial=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info=$(lspci -vvv -s "$pci_addr" 2>/dev/null)
        serial=$(echo "$pci_info" | grep -i "\[SN\]" | head -1 | sed 's/.*\[SN\]//' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//' | sed 's/^Serial number: //')
        if [[ -n "$serial" ]]; then
            echo "$serial"
            return
        fi
    fi

    echo "N/A"
}

# Mb/s → Gb/s 的展示换算。
#   注意这里只做"除以 1000"的计算换算（10000 Mb/s = 10 Gb），
#   不是存储容量那种 1024 进制，网速历来用十进制。
_mbps_to_gb() {
    local mbps="$1"

    # 非数字 / 空 → 0，避免 awk 收到脏输入
    if [[ -z "$mbps" ]] || [[ ! "$mbps" =~ ^[0-9]+$ ]]; then
        echo "0"
        return 0
    fi

    awk -v v="$mbps" 'BEGIN {
        g = v / 1000
        # 整数不带小数点（10000 → "10"），非整数保留一位（2500 → "2.5"）。
        # 0 < g < 0.1 特判为两位小数：10 Mb/s → "0.01"，保留一位会显示成
        # "0.0"，那是会让人误读为"没速率"的假值。
        if (g == 0)                printf "0\n"
        else if (g == int(g))      printf "%d\n", g
        else if (g < 0.1)          printf "%.2f\n", g
        else                       printf "%.1f\n", g
    }'
    return 0
}

get_nic_speed_gb() {
    local iface="$1"

    # 策略：优先"当前协商速率"，未插线/未协商时退回"支持的最大速率"。
    # 前者代表实际链路能力，后者代表硬件上限（对规划更有意义）。
    if command -v ethtool &>/dev/null; then
        local ethtool_output
        ethtool_output=$($SUDO ethtool "$iface" 2>/dev/null)

        # ---- 1) 当前速率 ----
        # 未插线时该行可能是 "Speed: Unknown!" 或干脆没有
        local current_speed
        current_speed=$(echo "$ethtool_output" \
            | grep -iE "^[[:space:]]*Speed:" \
            | awk '{print $2}')
        if [[ -n "$current_speed" ]] \
           && [[ "$current_speed" != "Unknown!" ]] \
           && [[ "$current_speed" != "Unknown" ]] \
           && [[ "$current_speed" != "Speed:" ]] \
           && [[ "$current_speed" =~ ^[0-9] ]]; then
            current_speed=$(echo "$current_speed" | sed 's/Mb\/s//; s/mb\/s//' | tr -d ' ')
            if [[ -n "$current_speed" ]] && [[ "$current_speed" =~ ^[0-9]+$ ]]; then
                _mbps_to_gb "$current_speed"
                return 0
            fi
        fi

        # ---- 2) 支持的最大速率 ----
        # "Supported link modes:" 是一个多行块，形如：
        #     Supported link modes:   1000baseT/Full
        #                             10000baseT/Full
        #                             25000baseCR/Full
        #     Supported pause frame use: No
        # 用 sed 的地址范围从起始行抓到"下一个 Supported xxx"行（含），
        # 再用 head -n -1 把那个终止行去掉，得到纯净的模式块。
        local supported_block
        supported_block=$(echo "$ethtool_output" \
            | sed -n '/Supported link modes:/,/^[[:space:]]*Supported [a-z]/p' \
            | head -n -1)

        # 某些驱动只给一行、没有后继 Supported 行；此时上面的范围会一直抓到
        # 文件尾。退回固定 6 行虽然可能截断多于 6 个模式的卡，但好过没有。
        if [[ -z "$supported_block" ]]; then
            supported_block=$(echo "$ethtool_output" \
                | grep -A6 "Supported link modes:" \
                | tail -n +2)
        fi

        if [[ -n "$supported_block" ]]; then
            # 从 "10000baseT/Full" 这类 token 里抽出数字，取最大值
            local speeds max_speed
            speeds=$(echo "$supported_block" \
                | grep -oE '[0-9]+[bB]ase' \
                | grep -oE '^[0-9]+' \
                | sort -n -u)
            if [[ -n "$speeds" ]]; then
                max_speed=$(echo "$speeds" | tail -1)
                if [[ -n "$max_speed" ]] && [[ "$max_speed" =~ ^[0-9]+$ ]]; then
                    _mbps_to_gb "$max_speed"
                    return 0
                fi
            fi
        fi
    fi

    # ---- 3) 兜底：内核暴露的当前速率（未插线时为 -1，被下面的 -gt 0 挡掉）----
    if [[ -f "/sys/class/net/$iface/speed" ]]; then
        local speed_val
        speed_val=$(cat "/sys/class/net/$iface/speed" 2>/dev/null)
        if [[ -n "$speed_val" ]] && [[ "$speed_val" =~ ^[0-9]+$ ]] && [[ "$speed_val" -gt 0 ]]; then
            _mbps_to_gb "$speed_val"
            return 0
        fi
    fi

    echo "0"
    return 0
}

# 端口总数统一取自 get_ports_for_bus 的结果长度。
# 注意不要另写一个返回 "3P" 这类字符串的端口数函数：两套契约容易不同步。

get_nic_firmware() {
    local iface="$1"

    if command -v ethtool &>/dev/null; then
        local firmware
        firmware=$($SUDO ethtool -i "$iface" 2>/dev/null \
                   | grep -i "firmware-version" \
                   | awk -F': ' '{print $2}')
        if [[ -n "$firmware" ]] && [[ "$firmware" != "N/A" ]]; then
            # 固件串常带后缀（如 "20.31.1014 (MT_0000000452)"），
            # 只保留第一段数字版本号，便于版本比对
            local version
            version=$(echo "$firmware" | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)
            if [[ -n "$version" ]]; then
                echo "$version"
                return 0
            fi
        fi
    fi

    echo "N/A"
    return 0
}

# 接口名即本列的值。单独成函数只为保持"每列一个取值函数"的结构一致性。
get_nic_interface_name() {
    echo "$1"
    return 0
}

# 端口当前是否检测到链路（载波是否存在）。
#
# 判据是 /sys/class/net/<iface>/carrier：
#     carrier=1 → yes  链路已建立
#     carrier=0 → no   无载波
#     读不到    → no   按"读不到 ≠ 有问题"处理，不引入第三态
# （注：它反映的是"链路是否建立"，不是"网线是否插着"：接了线但对端未开机、
#   或交换机口被关时同样为 no。要判"曾经插过线"应看 errors 列的 link_down。）
#
# 只读 sysfs，零 fork；判据与 _nic_link_is_up / link_down 同源。
get_nic_link_detected() {
    local iface="$1"
    [[ -n "$iface" && -r "/sys/class/net/$iface/carrier" ]] || { echo "no"; return 0; }

    local c
    c=$(< "/sys/class/net/$iface/carrier")
    c="${c//[[:space:]]/}"
    [[ "$c" == "1" ]] && echo "yes" || echo "no"
    return 0
}

get_nic_mac() {
    local iface="$1"
    local mac=""

    # 优先 permaddr（出厂永久 MAC）：绑定/聚合或某些驱动下 address 可能是
    # 被改写过的临时地址，资产核对要的是出厂地址。
    # 老版本 iproute2 没有 permaddr 字段，故回退 address。
    if command -v ip &>/dev/null; then
        mac=$(ip -o link show "$iface" 2>/dev/null \
              | grep -oE 'permaddr [0-9a-f:]+' \
              | awk '{print $2}')
    fi

    # 兜底：sysfs 的 address
    if [[ -z "$mac" ]] && [[ -f "/sys/class/net/$iface/address" ]]; then
        mac=$(tr -d ' \n' < "/sys/class/net/$iface/address" 2>/dev/null)
    fi

    echo "${mac:-N/A}"
    return 0
}

# 从 lldpctl 输出里取一个字段的值：匹配行 → 去掉第一个冒号及其前内容 → 去尾空白
_lldp_field() {
    local text="$1"
    local key="$2"
    echo "$text" \
        | grep -i -- "$key" \
        | head -1 \
        | sed 's/^[^:]*:[[:space:]]*//' \
        | sed 's/[[:space:]]*$//'
    return 0
}

get_lldp_info() {
    local iface="$1"
    local sw_name=""
    local port_id=""

    # 返回值格式：交换机名|端口ID（调用方按 '|' 切分），空值统一给 N/A
    if command -v lldpctl &>/dev/null; then
        local lldp_output
        lldp_output=$($SUDO lldpctl "$iface" 2>/dev/null)

        if [[ -n "$lldp_output" ]]; then
            # 字段名随 lldpctl 版本而异（SysName / System Name / PortID /
            # Port ID），逐个尝试。注意 "SysName" 是 "System Name" 的子串，
            # 先试短名能命中多数版本，试不到再退长名。
            sw_name=$(_lldp_field "$lldp_output" "SysName")
            [[ -z "$sw_name" ]] && sw_name=$(_lldp_field "$lldp_output" "System Name")

            port_id=$(_lldp_field "$lldp_output" "PortID")
            [[ -z "$port_id" ]] && port_id=$(_lldp_field "$lldp_output" "Port ID")

            # 有些交换机只报数字端口号（如 12），换成 Port Description
            # （如 "TenGigabitEthernet1/0/12"）更便于现场按名字找口
            if [[ "$port_id" =~ ^[0-9]+$ ]]; then
                local port_desc
                port_desc=$(_lldp_field "$lldp_output" "Port Description")
                [[ -n "$port_desc" ]] && port_id="$port_desc"
            fi

            # lldpctl 对 ifname 子类型会输出 "ifname eth0"，去掉前缀只留名字
            port_id=$(echo "$port_id" | sed 's/^ifname[[:space:]]*//')
        fi
    fi

    # 兜底：交换机（DSA）直连场景下，端口号可以从本地 sysfs 读到。
    # 仅在 LLDP 两个字段都没拿到时才用，避免覆盖真实 LLDP 结果。
    if [[ -z "$sw_name" ]] && [[ -z "$port_id" ]]; then
        if [[ -f "/sys/class/net/$iface/dsa/port" ]]; then
            port_id=$(cat "/sys/class/net/$iface/dsa/port" 2>/dev/null)
        fi
    fi

    echo "${sw_name:-N/A}|${port_id:-N/A}"
    return 0
}

# ============================================================================
# pcie_gen / pcie_link_cap / pcie_link_sta
# ============================================================================

_get_nic_pcie_raw() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]] && { echo ""; return; }

    if [[ -n "${LSPCI_NIC_CACHE[$pci_addr]+x}" ]]; then
        echo "${LSPCI_NIC_CACHE[$pci_addr]}"
        return
    fi

    local info
    info=$(lspci -vv -s "$pci_addr" 2>/dev/null || true)
    if [[ -z "$info" ]]; then
        info=$($SUDO lspci -vv -s "$pci_addr" 2>/dev/null || true)
    fi

    LSPCI_NIC_CACHE["$pci_addr"]="$info"
    echo "$info"
}

gtps_to_pcie_ver() {
    case "$1" in
        "2.5GT/s") echo "PCIe 1.0" ;;
        "5GT/s")   echo "PCIe 2.0" ;;
        "8GT/s")   echo "PCIe 3.0" ;;
        "16GT/s")  echo "PCIe 4.0" ;;
        "32GT/s")  echo "PCIe 5.0" ;;
        "64GT/s")  echo "PCIe 6.0" ;;
        *)         echo "" ;;
    esac
}

# ---------------------------------------------------------------------------
# PCIe 链路解析：LnkCap / LnkSta
#
# lspci -vv 里相关两行形如：
#   LnkCap: Port #0, Speed 16GT/s, Width x16, ASPM not supported
#   LnkSta: Speed 8GT/s (downgraded), Width x8 (downgraded)
#
# 要区分能力与状态，所以不能简单 grep 一行了事：
#   * LnkCap —— 这张卡"最多能跑"多少
#   * LnkSta —— 当前"实际跑"多少，以及是否被降级
# gen / link_cap / link_sta 三个取值函数都要用这两行，故统一解析一次成
#   "cap_speed|cap_width|sta_speed|sta_speed_state|sta_width|sta_width_state"
# ---------------------------------------------------------------------------

_pcie_lnk_parse() {
    local pci_addr="$1"

    local info
    info=$(_get_nic_pcie_raw "$pci_addr")
    [[ -z "$info" ]] && { echo "|||||"; return 0; }

    local cap_line sta_line
    cap_line=$(echo "$info" | grep -E "LnkCap:" | head -1)
    sta_line=$(echo "$info" | grep -E "LnkSta:" | head -1)

    # 抽 "Speed 16GT/s" → "16GT/s"。注意 [0-9.] 而非 [0-9]，因为存在 2.5GT/s
    local cap_speed cap_width
    cap_speed=$(echo "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    cap_width=$(echo "$cap_line" | grep -oE 'Width x[0-9]+'      | head -1 | sed 's/Width x//')

    local sta_speed sta_width
    sta_speed=$(echo "$sta_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    sta_width=$(echo "$sta_line" | grep -oE 'Width x[0-9]+'      | head -1 | sed 's/Width x//')

    # 括号里的状态，如 "(downgraded)"。取不到默认 "ok"，
    # 这样输出里总有明确结论，不用让读表的人去猜空白代表什么。
    local sta_speed_state sta_width_state
    sta_speed_state=$(echo "$sta_line" | grep -oE 'Speed [0-9.]+GT/s \([^)]*\)' | head -1 \
                      | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$sta_speed_state" ]] && sta_speed_state="ok"

    sta_width_state=$(echo "$sta_line" | grep -oE 'Width x[0-9]+ \([^)]*\)' | head -1 \
                      | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$sta_width_state" ]] && sta_width_state="ok"

    echo "${cap_speed}|${cap_width}|${sta_speed}|${sta_speed_state}|${sta_width}|${sta_width_state}"
    return 0
}

get_pcie_gen() {
    local pci_addr="$1"
    if [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]]; then
        echo "N/A"; return 0
    fi

    IFS='|' read -r cap_speed _ sta_speed _ _ _ < <(_pcie_lnk_parse "$pci_addr")

    # 先看能力，能力缺失时退回实际状态：LnkCap 在个别旧 lspci 上没有
    local speed="${cap_speed:-$sta_speed}"
    [[ -z "$speed" ]] && { echo "N/A"; return 0; }

    local ver
    ver=$(gtps_to_pcie_ver "$speed")
    echo "${ver:-N/A}"
    return 0
}

get_pcie_link_cap() {
    local pci_addr="$1"
    if [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]]; then
        echo "N/A"; return 0
    fi

    local cap_speed cap_width
    IFS='|' read -r cap_speed cap_width _ _ _ _ < <(_pcie_lnk_parse "$pci_addr")

    # 输出 "16GT/s x16"；两者缺一就只输出有的那个
    if [[ -n "$cap_speed" ]] && [[ -n "$cap_width" ]]; then
        echo "${cap_speed} x${cap_width}"
    elif [[ -n "$cap_speed" ]]; then
        echo "$cap_speed"
    elif [[ -n "$cap_width" ]]; then
        echo "x${cap_width}"
    else
        echo "N/A"
    fi
    return 0
}

get_pcie_link_sta() {
    local pci_addr="$1"
    if [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]]; then
        echo "N/A"; return 0
    fi

    local sta_speed sta_speed_state sta_width sta_width_state
    IFS='|' read -r _ _ sta_speed sta_speed_state sta_width sta_width_state \
        < <(_pcie_lnk_parse "$pci_addr")

    # 带上状态标注： "8GT/s (downgraded) x8 (downgraded)"
    local sp_str="" wd_str=""
    [[ -n "$sta_speed" ]] && sp_str="${sta_speed} (${sta_speed_state:-ok})"
    [[ -n "$sta_width" ]] && wd_str="x${sta_width} (${sta_width_state:-ok})"

    if [[ -n "$sp_str" ]] && [[ -n "$wd_str" ]]; then
        echo "${sp_str} ${wd_str}"
    elif [[ -n "$sp_str" ]]; then
        echo "$sp_str"
    elif [[ -n "$wd_str" ]]; then
        echo "$wd_str"
    else
        echo "N/A"
    fi
    return 0
}

# ============================================================================
# PCIe VID / PID
# ============================================================================

# vendor 与 device 两个 sysfs 属性的读取逻辑完全一致（都是 "0x15b3" 这种
# 十六进制串 → 去 0x → 转小写），合并成一个函数，第二个参数选属性名。
_read_pci_sysfs_hex() {
    local pci_addr="$1"
    local attr="$2"          # vendor | device

    if [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]]; then
        echo "N/A"; return 0
    fi

    local key f v
    key=$(ensure_domain_pci_addr "$pci_addr")
    f="/sys/bus/pci/devices/$key/$attr"

    if [[ -f "$f" ]]; then
        v=$(tr -d ' \n' < "$f" 2>/dev/null)
        v="${v#0x}"          # sysfs 给的是 "0x15b3"
        v="${v,,}"           # 统一小写，避免与 0000 混排
        [[ -n "$v" ]] && { echo "$v"; return 0; }
    fi

    echo "N/A"
    return 0
}

get_pcie_vendor_id_sysfs()  { _read_pci_sysfs_hex "$1" "vendor"; }
get_pcie_product_id_sysfs() { _read_pci_sysfs_hex "$1" "device"; }

# ============================================================================
# 链路翻转计数 / PCIe AER
# ============================================================================

# carrier_changes：网口"链路通断"的累计翻转次数（内核维护，无需 root）。
#
# 链路翻转是成本最低、信噪比最高的介质劣化指标：
#   光纤/模块/网线老化 → 链路反复 up/down → 该计数持续增长；
#   而网卡自身的 *_errors 在很多瞬时断链场景下完全不涨。
#
# 判据用【速率】而非绝对值：这是自开机以来的累计值，没有绝对阈值 ——
# 跑了 700 天的机器经历几次交换机重启，累计 50 次完全正常；刚开机 3 天就
# 30 次才说明正在反复闪断。因此换算成"次/天"，超过 NIC_CC_RATE_MAX 才报。
readonly NIC_CC_RATE_MAX=10      # 次/天，超过即判定为链路闪断

# 系统 uptime 天数（从 /proc/uptime 第一列秒数换算，零 fork 之外的开销）。
# 读不到时返回空串，调用方退回"只输出累计值"的行为。
get_uptime_days() {
    local f="/proc/uptime" secs
    if [[ -r "$f" ]]; then
        read -r secs _ < "$f" 2>/dev/null || true
        # /proc/uptime 是 "12345.67 98765.43"，取整数部分即可
        secs="${secs%%.*}"
        [[ "$secs" =~ ^[0-9]+$ ]] && { echo $(( secs / 86400 )); return 0; }
    fi
    echo ""
    return 0
}

# 判断 carrier_changes 是否属于异常闪断。
#   参数：$1=累计翻转次数  $2=uptime 天数（空则只做保守判断）
#   输出 "1" 表示异常，空表示正常/无法判断。
_nic_cc_is_flapping() {
    local cc="$1" days="$2"
    [[ -z "$cc" || ! "$cc" =~ ^[0-9]+$ ]] && return 0

    # uptime 不可用：无法算速率，退回"累计值必须明显偏大"的保守判断，
    # 避免因为读不到 uptime 就把所有口都标成异常。
    if [[ -z "$days" || ! "$days" =~ ^[0-9]+$ ]]; then
        (( cc > NIC_CC_RATE_MAX * 30 )) && echo "1"
        return 0
    fi

    # 不到 1 天按 1 天算，避免开机几分钟就因除以 0 或放大倍数误报
    (( days < 1 )) && days=1

    # cc/days > NIC_CC_RATE_MAX  → 等价于 cc > NIC_CC_RATE_MAX * days
    # 用整数乘法比较，避免引入浮点/bc 依赖。
    (( cc > NIC_CC_RATE_MAX * days )) && echo "1"
    return 0
}

# 端口链路是否处于 up（carrier=1）。
# 返回 0 = 链路 up；1 = down 或读不到。
#
# 用途：把"运行状态类"的光模块判据（收光是否偏低等）限制在链路 up 时。
#   链路 up   → 收光是【运行状态】，低于门限说明模块/光纤真的在劣化
#   链路 down → 收光低是【物理必然】（对端不发光），不代表模块有问题
#   读不到    → 无法判断 → 按"读不到 ≠ 有问题"处理，返回 1
#
# 只读 sysfs，零 fork；判据与 get_nic_errors 里的 link_down 保持同源。
_nic_link_is_up() {
    local iface="$1"
    [[ -n "$iface" && -r "/sys/class/net/$iface/carrier" ]] || return 1

    local c
    c=$(< "/sys/class/net/$iface/carrier")
    c="${c//[[:space:]]/}"
    [[ "$c" == "1" ]]
}

get_carrier_changes() {
    local iface="$1"
    local f="/sys/class/net/$iface/carrier_changes"
    local v

    if [[ -r "$f" ]]; then
        v=$(< "$f")                 # bash 内建读取，0 次 fork
        v="${v//[[:space:]]/}"
        [[ "$v" =~ ^[0-9]+$ ]] && { echo "$v"; return 0; }
    fi
    echo ""                          # 空 = 内核不支持，调用方据此决定是否输出
    return 0
}

# PCIe AER（Advanced Error Reporting）可纠正/不可纠正错误。
#
# 网卡自己的 ethtool -S 完全看不到 PCIe 总线错误。坏插槽 / 转接卡 /
# 金手指氧化会表现为 AER 计数增长，症状是偶发丢包和性能抖动，而 errors
# 列里其他项全是 0，排查时极易走错方向。
#
# 输出 "<correctable>:<nonfatal>:<fatal>"，不可用时返回空串。
# sysfs 里这些文件的格式是 "name count\n" 多行，只累加数字。
get_pcie_aer() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "N/A" ]] && { echo ""; return 0; }

    local key base total_c=0 total_nf=0 total_f=0
    key=$(ensure_domain_pci_addr "$pci_addr")
    base="/sys/bus/pci/devices/$key"

    # 三个文件是否存在是判断内核是否启用 AER 的依据
    [[ -d "$base" ]] || { echo ""; return 0; }

    local f kind line nm cnt acc
    for kind in correctable nonfatal fatal; do
        f="$base/aer_dev_$kind"
        [[ -r "$f" ]] || continue
        acc=0
        # 逐行读，用纯 bash 切分，避免 fork。
        # sysfs 有两种格式，都必须认：
        #   (a) "RxErr 12"        —— 多行，每行 名称+计数
        #   (b) "12"              —— 单行裸数字（部分内核/驱动）
        # 只认 (a) 会在 (b) 的机器上恒返回 0，把"有错"报成"干净" ——
        # 对诊断工具来说假阴性比假阳性危险得多，所以两种都处理。
        #
        # ⚠ 必须先把行首尾空白 trim 掉再切。反例：行是 "RxErr 5 "（尾随
        #   一个空格，内核某些版本会这样打印）时，
        #       ${line##*[[:space:]]}  删的是"到最后一个空格为止"的前缀，
        #   结果是空串而不是 "5"，该计数器被静默跳过 —— 又一次假阴性。
        #   ${line%%[[:space:]]*} 同理会在行首有空格时出问题。
        while IFS= read -r line; do
            line="${line%$'\r'}"                  # 去 CR（内核不会给，防御）
            line="${line#"${line%%[![:space:]]*}"}"  # 去行首空白
            line="${line%"${line##*[![:space:]]}"}"  # 去行尾空白
            [[ -z "$line" ]] && continue

            if [[ "$line" =~ ^[0-9]+$ ]]; then
                # 格式 (b)：整行就是计数
                acc=$(( acc + line ))
                continue
            fi

            # 格式 (a)：名称 + 空白 + 计数。trim 之后切割是安全的：
            #   cnt 取最后一个空白之后，nm 取第一个空白之前。
            cnt="${line##*[[:space:]]}"
            nm="${line%%[[:space:]]*}"
            [[ "$cnt" =~ ^[0-9]+$ ]] || continue
            [[ "$nm" == "TOTAL_ERR"* ]] && continue   # 汇总行，否则重复计数
            acc=$(( acc + cnt ))
        done < "$f"

        case "$kind" in
            correctable) total_c=$acc ;;
            nonfatal)    total_nf=$acc ;;
            fatal)       total_f=$acc ;;
        esac
    done

    # 三个文件都不存在 → 该设备不支持 AER，返回空
    if [[ ! -r "$base/aer_dev_correctable" && ! -r "$base/aer_dev_nonfatal" \
          && ! -r "$base/aer_dev_fatal" ]]; then
        echo ""; return 0
    fi

    echo "${total_c}:${total_nf}:${total_f}"
    return 0
}

# ============================================================================
# 网卡错误计数
# ============================================================================

# ---------------------------------------------------------------------------
# 网卡错误计数 → errors 列
#
# 输出格式： name:value;name:value...   全 0 时字面量 "0"
#
# 纳入判据是两条并集：
#   A. 命中硬件故障白名单（语义明确、值得关注的计数器）
#   B. 名称兜底 —— 含 err / crc / frame / align / carrier / phy_err /
#      timeout / collision / nohandler（覆盖白名单没列全的驱动命名）
# 且必须先排除 DENYLIST。保留"值为 0 不输出"的规则（0 无信息量）。
#
# dropped / discard 类默认不纳入：丢包通常意味着拥塞（对端打太满、队列
# 溢出），不是网卡或链路故障。确有需要时用 --include-drops 显式打开。
# ---------------------------------------------------------------------------

# errors 列【只】收录"可能由硬件引起、或预示硬件故障"的指标。
#
# 判据不是"名字里有没有 err"。不收录的三类（病因不属于硬件）：
#   长度类  rx_oversize / rx_undersize / rx_jabbers / rx_fragments /
#           rx_long_length / rx_short_length / rx_length_errors
#           → 帧长越界 = MTU/隧道配置或对端问题，不是网卡劣化
#   主机类  rx_missed / rx_fifo / rx_over_errors / rx_no_buffer
#           → 主机 CPU、中断或 ring 配置不足
#   协议类  rx_csum_offload / checksum
#           → 坏校验和由【发送方】产生
#
# 长度类必须同时从白名单移除并加进 DENYLIST：它们的名字含 err/oversize/
# undersize/jabber 等词，仅删白名单会被 err_re 兜底重新捞回来。
#
# 白名单按"病因"分组，便于新增驱动时对照归位：
readonly NIC_ERR_WHITELIST='rx_crc_errors|rx_crc|rx_symbol_err|rx_symbol_errors|rx_phy_errors|tx_phy_errors|rx_frame_errors|rx_alignment_errors|rx_errors|tx_errors|rx_mac_errors|tx_mac_errors|rx_err_dropped|tx_carrier_errors|tx_aborted_errors|tx_window_errors|tx_heartbeat_errors'

# 明确【排除】的计数器：名字里带 err，但病因不属于硬件。
#
# 这条规则【必须】存在，而且必须收录长度类计数器 —— 下面的 err_re 名称兜底
# 含 err/jabber/oversize/undersize，会把它们重新捞进来。只从白名单里删掉
# 是无效的，必须在这里先 continue 掉。
#
# 长度类：oversize / undersize / jabber / long_length / short_length /
#         length_errors / fragments
#         → 帧长超出允许范围，属配置或对端问题
#         （rx_length_errors 是各驱动的长度错误【汇总项】，
#           rx_short_length_errors 是 undersize 的别名写法，同因同收）
# 主机类：missed / fifo / no_buffer / over_errors / out_of_buffer
#         → 主机 CPU、中断或 ring 配置不足
# 协议类：csum_offload / checksum
#         → 坏校验和由【发送方】产生
readonly NIC_ERR_DENYLIST='csum_offload|checksum|rx_missed|tx_missed|rx_fifo|tx_fifo|rx_no_buffer|rx_over_errors|rx_long_length|rx_short_length|rx_length_errors|rx_oversize|rx_undersize|rx_jabber|rx_fragments|rx_frag|out_of_buffer|no_buffers'

# 采集网卡错误计数与链路/PCIe 健康指标，拼成 errors 列的键值串。
#
# 输出格式： name:value;name:value...   （全 0 时字面量 "0"）
#
# 除 ethtool -S 的计数器外，额外补充三个【ethtool 看不到】的指标，
# 它们同样以 name:value 形式并入 errors 列，不增加列数：
#
#   carrier_changes  —— 链路翻转次数，介质劣化的最灵敏指标
#   pcie_aer_corr    —— PCIe 可纠正错误，坏插槽/转接卡/金手指氧化的征兆
#   link_up          —— 当前链路状态，0 表示端口 down（掉线口的关键线索）
#
# 值的语义约定（便于下游解析）：
#   计数器名:数字   → 该项累计值
#   *_aer_*:a:b:c   → 可纠正:非致命:致命（AER 三个维度）
#
# 可选参数 $2 = PCI 地址，用于读取 PCIe AER；不传则跳过 AER 段。
get_nic_errors() {
    local iface="$1"
    local pci_addr="${2:-}"
    local result=""

    # ---------- 1) 链路状态与翻转次数（sysfs，零 fork） ----------
    local cc up
    cc=$(get_carrier_changes "$iface")
    if [[ -n "$cc" ]] && [[ -n "$(_nic_cc_is_flapping "$cc" "$UPTIME_DAYS")" ]]; then
        # 只有"链路闪断"（翻转速率超过 NIC_CC_RATE_MAX 次/天）才输出，
        # 避免把开机协商、交换机重启这类一次性翻转当成故障。
        # 同时带上原值和 uptime，便于人工复核判定是否合理。
        result+="${result:+;}carrier_changes:${cc}"
        [[ -n "$UPTIME_DAYS" ]] && result+=";uptime_days:${UPTIME_DAYS}"
    fi

    # ---------- 1b) 当前链路状态（sysfs，零 fork） ----------
    #
    # 只对【曾经跑过流量、现在未接线】的口报 link_down。
    # 判据是流量字节，不是链路状态：
    #   rx_bytes > 0 || tx_bytes > 0    曾经真实通过流量
    #
    # 不能用 carrier_changes 作主判据：它只说明"载波状态变过一次"，而接口
    # 被配置成 UP（ifup / bond 从属）本身就会产生一次变化，与插没插线无关。
    # 把它算作"曾用过"会让从未接线的口全部误报。
    # carrier_changes 仅作旁证，在确认有流量时一并输出。
    #
    # 局限：计数器随【驱动加载/重启】清零。机器刚重启且线已拔时，计数全为 0
    # 会与"从未使用"无法区分而漏报，需结合同行的 uptime_days 判断。
    if [[ -r "/sys/class/net/$iface/carrier" ]]; then
        up=$(< "/sys/class/net/$iface/carrier")
        up="${up//[[:space:]]/}"
        if [[ "$up" == "0" ]]; then
            local _rxb=0 _txb=0
            [[ -r "/sys/class/net/$iface/statistics/rx_bytes" ]] \
                && _rxb=$(< "/sys/class/net/$iface/statistics/rx_bytes")
            [[ -r "/sys/class/net/$iface/statistics/tx_bytes" ]] \
                && _txb=$(< "/sys/class/net/$iface/statistics/tx_bytes")
            _rxb="${_rxb//[[:space:]]/}"; _txb="${_txb//[[:space:]]/}"
            [[ "$_rxb" =~ ^[0-9]+$ ]] || _rxb=0
            [[ "$_txb" =~ ^[0-9]+$ ]] || _txb=0

            # ★ 必须"真的过过流量"才报：rx 或 tx 字节数大于 0。
            if [[ "$_rxb" -gt 0 || "$_txb" -gt 0 ]]; then
                local _cc_n="${cc:-0}"
                [[ "$_cc_n" =~ ^[0-9]+$ ]] || _cc_n=0
                result+="${result:+;}link_down:1"
                # 三个证据值都输出，便于现场复核，也便于从 CSV 单独诊断。
                result+=";link_prev_rx_bytes:${_rxb}"
                result+=";link_prev_tx_bytes:${_txb}"
                result+=";link_prev_cc:${_cc_n}"
            fi
        fi
    fi

    # ---------- 2) PCIe AER ----------
    local aer
    aer=$(get_pcie_aer "$pci_addr")
    if [[ -n "$aer" ]]; then
        IFS=':' read -r _c _nf _f <<< "$aer"
        # 三个都为 0 说明总线健康，不输出
        if [[ "$_c" -gt 0 || "$_nf" -gt 0 || "$_f" -gt 0 ]]; then
            result+="${result:+;}pcie_aer_corr:${_c};pcie_aer_nonfatal:${_nf};pcie_aer_fatal:${_f}"
        fi
    fi

    # ---------- 3) ethtool -S 计数器 ----------
    if ! command -v ethtool &>/dev/null; then
        echo "${result:-0}"
        return 0
    fi

    # 注意保留 || true：网卡不支持 -S 时 ethtool 会非 0 退出，
    # 而本函数在 set -o pipefail 下运行，不兜住会把整个脚本带崩。
    local stats
    stats=$($SUDO ethtool -S "$iface" 2>/dev/null || true)
    [[ -z "$stats" ]] && { echo "${result:-0}"; return 0; }

    # 两条并集：命中白名单，或名称含物理层/链路层症状关键字；
    # 且必须先被 DENYLIST 排除。
    #
    # 兜底关键字里放裸 'err' 是为了覆盖 collisions / tx_timeout /
    # rx_nohandler 这类不含 crc/frame 的命名，否则它们会被静默丢弃
    # （诊断工具漏报比误报危险）。
    # 放宽兜底的安全性依赖 DENYLIST 的完整性：所有"名字含 err 但非硬件"的
    # 计数器都必须在 DENYLIST 里，在任何 err 判定之前就被 continue 掉。
    # 以后新增此类计数器，务必同步加进 DENYLIST。
    local err_re='crc|symbol|frame|align|carrier|phy_err|err|timeout|collision|nohandler'
    [[ "$INCLUDE_DROPS" == "true" ]] && err_re="${err_re}|dropped|discard"

    # 注意：result 在前面已经装了 carrier_changes / AER，这里【不能】重新
    # local result="" —— 那会把刚采集的硬件指标清空。
    local name val rest
    while IFS= read -r line; do
        [[ "$line" == *:* ]] || continue

        # 用纯 bash 参数展开切分，不要 echo|awk|tr —— 那样每行要 fork 4 个
        # 进程，而 Intel 万兆卡 ethtool -S 有 300+ 个计数器，8 个口就是上万次。
        name="${line%%:*}"          # 冒号前
        rest="${line#*:}"           # 冒号后
        # 剥掉空白（不能用 ${var// /} 之外的正则，bash 只支持模式）
        name="${name//[[:space:]]/}"
        val="${rest//[[:space:]]/}"
        [[ -z "$name" ]] && continue

        # 先排除：明确判定与硬件无关的计数器（优先级最高）
        [[ "$name" =~ $NIC_ERR_DENYLIST ]] && continue

        # 再纳入：白名单 或 物理层症状关键字
        if [[ ! "$name" =~ $NIC_ERR_WHITELIST ]] \
           && [[ ! "$name" =~ $err_re ]]; then
            continue
        fi

        # 只收正整数：非数字（N/A、-）和 0 都不输出
        [[ "$val" =~ ^[0-9]+$ ]] || continue
        [[ "$val" -gt 0 ]] || continue

        # name:value 用分号连接；CSV 层面再由 csv_escape 处理引号。
        # 注意这里是【追加】到 result，前面的 carrier_changes / AER 不能丢。
        result+="${result:+;}${name}:${val}"
    done <<< "$stats"

    echo "${result:-0}"
    return 0
}

# ============================================================================
# 光模块 - mlxlink 路径
# ============================================================================

_is_zero_dbm_mw() {
    local mw="$1"
    [[ -z "$mw" || "$mw" == "N/A" ]] && return 0
    awk -v v="$mw" 'BEGIN { exit !(v > 0.9999 && v < 1.0001) }'
}

_mlxlink_dbm_to_mw_avg() {
    local list="$1"
    [[ -z "$list" || "$list" == "N/A" ]] && { echo "N/A"; return; }

    list="${list%%\[*}"
    list="${list//,/ }"

    # 整串交给【单个】awk 处理：切词、过滤、求和、均值、零值判断一次完成。
    # 每个 dBm 值单独 fork 一次 awk 会成倍放大进程数。
    awk -v s="$list" 'BEGIN {
        n = split(s, a, /[ \t]+/)
        sum = 0; cnt = 0
        for (i = 1; i <= n; i++) {
            v = a[i]
            gsub(/ /, "", v)
            if (v == "") continue
            if (v ~ /^-?[0-9.]+$/) { sum += 10 ^ (v / 10); cnt++ }
        }
        if (cnt == 0) { print "N/A"; exit }
        avg = sum / cnt
        # 约等于 1.0 mW 视为无效值（驱动未填该字段时的占位）
        if (avg > 0.9999 && avg < 1.0001) { print "N/A"; exit }
        printf "%.6f", avg
    }'
    return 0
}

get_optics_info_mlxlink() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && return 1

    local mlxlink_cmd
    mlxlink_cmd=$(command -v mlxlink 2>/dev/null || true)
    [[ -z "$mlxlink_cmd" ]] && return 1

    # 按 BDF 缓存 mlxlink 输出：一块双口卡的两个口共享同一个 PCI 设备，
    # -m 输出的模块信息对两个口是同一份。而 mlxlink 是极重的调用（经 MST
    # 驱动逐字节读 I2C，单次 2-10 秒，且烧 user CPU）。
    # 不缓存则端口数越多耗时线性放大，故用关联数组按 BDF 记忆。
    local out
    if [[ -n "${MLXLINK_CACHE[$bdf]+x}" ]]; then
        out="${MLXLINK_CACHE[$bdf]}"
    else
        out=$($SUDO "$mlxlink_cmd" -d "$bdf" -m 2>/dev/null || true)
        MLXLINK_CACHE[$bdf]="$out"
    fi
    [[ -z "$out" ]] && return 1

    # 一次遍历取出全部字段。
    # （逐字段调用 _mlx_field 每次都要重扫整个 blob 并起多个进程。）
    local vendor pn ver sn temp tx_dbm rx_dbm
    local parsed
    parsed=$(printf '%s\n' "$out" | awk '
        function val(line,   p) {          # 去掉 "key :" 前缀与尾部空白
            p = index(line, ":")
            line = substr(line, p + 1)
            gsub(/^[ \t]+|[ \t]+$/, "", line)
            return line
        }
        /^[ \t]*Module Info/ { seen_mod = 1 }
        !seen_mod { next }                 # 只在 Module Info 段内取值
        /^[ \t]*Vendor Name[ \t]*:/          && !v  { v  = val($0) }
        /^[ \t]*Vendor Part Number[ \t]*:/   && !p  { p  = val($0) }
        /^[ \t]*Rev[ \t]*:/                  && !r  { r  = val($0) }
        /^[ \t]*Vendor Serial Number[ \t]*:/ && !s  { s  = val($0) }
        /^[ \t]*Temperature \[C\][ \t]*:/    && !t  { t  = val($0); sub(/ .*/, "", t) }
        /^[ \t]*Tx Power Current \[dBm\][ \t]*:/ && !x { x = val($0) }
        /^[ \t]*Rx Power Current \[dBm\][ \t]*:/ && !y { y = val($0) }
        END { printf "%s\x1f%s\x1f%s\x1f%s\x1f%s\x1f%s\x1f%s", v, p, r, s, t, x, y }
    ')
    IFS=$'\x1f' read -r vendor pn ver sn temp tx_dbm rx_dbm <<< "$parsed"

    # 有效性与"Vendor Name 必须存在"的校验合并在这里，解析结果为空即未命中。
    [[ -z "$vendor" ]] && return 1
    [[ "$out" == *"Module Info"* ]] || return 1

    local tx_mw rx_mw
    tx_mw=$(_mlxlink_dbm_to_mw_avg "$tx_dbm")
    rx_mw=$(_mlxlink_dbm_to_mw_avg "$rx_dbm")

    # ★★ 必须返回 10 个字段，与 ethtool 路径保持一致 ★★
    #   原实现只返回 7 个，而调用方按 10 个字段 read，导致 mlxlink
    #   路径下 lw/la/floor 全为空 → 收光判定恒走类型兜底，
    #   DDM 门限功能在 Mellanox 卡上【从来没有生效过】。
    #   mlxlink -m 不提供 SFF 门限表，故 lw/la 留空（这是真实情况，
    #   不是解析失败）；floor 同样留空，由调用方按模块类型补默认值。
    #   末尾 3 个空字段 = lw / la / floor。
    echo "${vendor:-N/A}|${pn:-N/A}|${ver:-N/A}|${sn:-N/A}|${tx_mw}|${rx_mw}|${temp:-N/A}|||"
    return 0
}

# 注：原 _mlx_field（echo|grep|head|sed|sed，每字段 4 个进程、
# 每次重扫整个 blob）已被 get_optics_info_mlxlink 里的单次 awk 取代，
# 因此删除该函数，避免留下死代码。

# ============================================================================
# 光模块 - ethtool 兜底路径
# ============================================================================

# ethtool -m 的字段取值（格式 "Vendor name: FS          "），简单切冒号即可
_optics_field() {
    local text="$1"
    local key="$2"
    echo "$text" \
        | grep -i -- "$key" \
        | head -1 \
        | awk -F':' '{print $2}' \
        | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'
    return 0
}

# 从一行里抽光功率并统一成 mW。
#   优先直接取 mW（0.5 mW），没有的话把 dBm 换算成 mW：mW = 10^(dBm/10)
#   返回空串表示没解析到。
_optics_extract_power_mw() {
    local line="$1"
    [[ -z "$line" ]] && return 0

    local mw
    mw=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+ mW' | head -1 | sed 's/ mW//')
    if [[ -n "$mw" ]]; then
        echo "$mw"
        return 0
    fi

    local dbm
    dbm=$(echo "$line" | grep -oE '[-+]?[0-9]+\.[0-9]+ dBm' | head -1 | sed 's/ dBm//')
    if [[ -n "$dbm" ]]; then
        awk -v d="$dbm" 'BEGIN { printf "%.4f", 10^(d/10) }'
    fi
    return 0
}

# 从一行温度里抽摄氏度
_optics_extract_temp_c() {
    local line="$1"
    [[ -z "$line" ]] && return 0

    local t
    t=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+ degrees C' | head -1 | sed 's/ degrees C//')
    [[ -z "$t" ]] && t=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+ C' | head -1 | sed 's/ C//')
    [[ -z "$t" ]] && t=$(echo "$line" | awk -F':' '{print $2}' | grep -oE '[0-9]+\.[0-9]+' | head -1)
    echo "$t"
    return 0
}

# 把 mW 转成 dBm（保留 2 位）。errors 里附带实测 dBm，
# 因为工程上判断光功率余量看的是 dBm，不是 mW。  0.0742 mW → -11.30 dBm
_optics_mw_to_dbm() {
    local mw="$1"
    [[ -z "$mw" || "$mw" == "N/A" ]] && return 0
    awk -v m="$mw" 'BEGIN {
        if (m <= 0) { print ""; exit }
        printf "%.2f", 10 * log(m) / log(10)
    }'
    return 0
}

# 从 ethtool -m 输出里取模块厂商定义的【收光】门限。
#
# 必须锁定 Rx：ethtool -m 里同时存在 Tx 和 Rx 两组门限，且 Tx 行在前：
#     Laser output power low warning threshold : 0.0850 mW / -10.71 dBm  ← Tx
#     Laser rx power low warning threshold     : 0.0200 mW / -16.99 dBm  ← Rx
# 用泛匹配 + head -1 会取到 Tx 门限当 Rx 用，而 0.0850 比很多健康口的实测
# 收光还高 → 正常口被误报为"收光偏低"。这属于静默产生错误结论，比解析
# 失败更危险，因此必须精确匹配 Rx。
#
# 还要跳过非门限行：模块会打印同名前缀的【实时状态】行：
#     Laser rx power low warning : Off                    ← 状态
#     Laser rx power low warning threshold : 0.0200 mW    ← 门限
# 因此优先取含 "threshold" 的行，没有再退回。
#
# 兼容两种驱动命名：
#   Intel ixgbe 系    "Laser rx power low warning threshold"
#   SFF-8472 标准命名 "Receiver signal average optical power low warning"
#
# 返回 "<low_warning_mW>|<low_alarm_mW>"（未提供则为空字段）
_optics_rx_thresholds() {
    local text="$1"
    [[ -z "$text" ]] && { echo "|"; return 0; }

    local rx_lw_re='rx power low warning|receiver signal average optical power low warning'
    local rx_la_re='rx power low alarm|receiver signal average optical power low alarm'

    # 先只留 Rx 相关的行，再优先挑 threshold 行，最后才取第一条。
    # 这三步顺序是关键：少任何一步都会取到错的行。
    local lw_lines la_lines lw_line la_line
    lw_lines=$(echo "$text" | grep -iE "$rx_lw_re")
    la_lines=$(echo "$text" | grep -iE "$rx_la_re")

    lw_line=$(echo "$lw_lines" | grep -i "threshold" | head -1)
    [[ -z "$lw_line" ]] && lw_line=$(echo "$lw_lines" | grep -viE "off|on" | head -1)

    la_line=$(echo "$la_lines" | grep -i "threshold" | head -1)
    [[ -z "$la_line" ]] && la_line=$(echo "$la_lines" | grep -viE "off|on" | head -1)

    local lw la
    lw=$(_optics_extract_power_mw "$lw_line")
    la=$(_optics_extract_power_mw "$la_line")

    # 把 "0.0000 / -inf" 视为"该门限未实现"，不能当真实值。
    #
    # 模块没有实现某项门限时会填 0，例如：
    #   Laser rx power low warning threshold : 0.0200 mW / -16.99 dBm  ← 真实
    #   Laser rx power low alarm   threshold : 0.0000 mW /  -inf dBm   ← 占位
    # 这不是"门限为 0 mW"（那意味着任何收光都告警），而是"本项不支持"。
    #
    # 危害是脏数据：10*log(0)/log(10) 在 awk 里不报错，直接输出 "-inf"，
    # 会流到下游/CSV；而纯 bash 的 dBm→整数转换会把它当成一个大负数，
    # 可能被选成"最保守门限"，导致真正的低收光反而不报。
    # 故统一置空，让上层走"模块未公布此门限"的回退分支。
    local zero_re='^0+\.?0*$'
    [[ "$lw" =~ $zero_re ]] && lw=""
    [[ "$la" =~ $zero_re ]] && la=""

    echo "${lw}|${la}"
    return 0
}

# 从 ethtool -m 输出里取【模块自己置位的 DDM 告警/预警标志】，
# 返回紧凑的逗号分隔列表（无则返回空串）。
#
# 这是脚本里唯一不依赖本脚本推算的光学判据：ethtool -m 会把模块内部
# 【厂商写入并实时维护】的告警位读出来，位为 On 即代表模块自身认定某个量
# 已越过它自己的门限。门限由厂商为该型号标定，判定由模块硬件完成。
# 其他判据（optics_rx_low / optics_power_* / optics_temp_*）都建立在
# "门限取得对、两个工具读数准"的前提上，唯有本项没有这个前提。
#
# 输出形如（Intel AFBR-709DMZ-IN3 共 20 个标志位）：
#     Laser bias current high alarm             : Off
#     Laser rx power low warning                : Off
# 同一份输出里还有【同名但带 threshold 后缀】的门限行：
#     Laser rx power low warning threshold      : 0.0200 mW / -16.99 dBm
# 必须把 threshold 行排除，否则会把门限值误当成"标志位状态"。
#
# 匹配用 `(On|Off)([[:space:]]|$)` 而不是更严格的 `(On|Off)[[:space:]]*$`：
# 后者要求 On/Off 之后除空格外别无内容，若驱动打印
#     Laser rx power low warning : On (latched)
# 就会被漏掉 —— 已置位的告警被漏报比误报危险得多。
# 放宽后 "…threshold : 0.0200 mW" 仍不匹配（0 不是 On/Off），
# 而 "… : On (latched)" 能匹配。
#
# 逗号分隔的原因：errors 列本身用 ';' 分隔键值对，标志位内部用 ';'
# 会破坏列结构，用 ',' 保持单键单值。
_optics_ddm_alarms() {
    local text="$1"
    [[ -z "$text" ]] && return 0

    echo "$text" \
        | grep -iE '^[[:space:]]*[A-Za-z][^:]*:[[:space:]]*(On|Off)([[:space:]]|$)' \
        | grep -iE ':[[:space:]]*On([[:space:]]|$)' \
        | while IFS= read -r line; do
            local name="${line%%:*}"
            # 归一成短键：去掉首尾空白、去掉 Laser/Module 之类的前缀噪音、
            # 空白转下划线、小写。保留语义，便于 CSV 里直接读。
            name="${name#"${name%%[![:space:]]*}"}"
            name="${name%"${name##*[![:space:]]}"}"
            name="${name// /_}"
            name="${name,,}"
            name="${name#laser_}"
            name="${name#module_}"
            printf '%s,' "$name"
        done
    return 0
}

# 模块类型自适应的收光下限（dBm），用于模块【没有】公布 DDM 门限时的兜底。
#
# 各标准的接收灵敏度（OMA，典型值）差异很大，用一个数字套所有模块必然误判：
#   10GBASE-SR  850nm 多模   ≈ -11.1 dBm
#   10GBASE-LR  1310nm 单模  ≈ -12.6 dBm
#   10GBASE-ER  1550nm 单模  ≈ -14.1 dBm
#   1000BASE-SX 850nm 多模   ≈ -17.0 dBm
#   1000BASE-LX 1310nm 单模  ≈ -19.0 dBm
# 以 ethtool -m 的 "Transceiver type" 字段判断；识别不出时按最宽松的
# 千兆值处理（宁可漏报也不误报 —— 误报会浪费现场排查成本）。
#
# 解析该字段要注意两点：
#   1) 它可能【出现多次】，一个模块常同时声明多种兼容类型：
#        Transceiver type : 10G Ethernet: 10G Base-SR
#        Transceiver type : Ethernet: 1000BASE-SX
#      只取 head -1 会丢掉后面的类型，若顺序是先千兆后万兆，就会按
#      -17.0 而不是 -11.1 判定，松了 6 dB。
#      因此遍历所有 type 行，取"最严格"（dBm 最大、最保守）的那个。
#   2) ethtool 打印的是 "10G Base-SR"，Base 与 SR 之间【有空格】，而标准
#      写法是 "10GBASE-SR"（无空格）。按无空格字符串匹配会全部落空，
#      一路掉到默认值 —— 这种静默取默认值的失配不会报错，最难发现。
#      因此匹配前先把空格/连字符全部去掉，统一成 "10gbasesr" 再比。
readonly NIC_RX_FLOOR_SR=-11.1
readonly NIC_RX_FLOOR_LR=-12.6
readonly NIC_RX_FLOOR_ER=-14.1
readonly NIC_RX_FLOOR_SX=-17.0
readonly NIC_RX_FLOOR_LX=-19.0

# 把 dBm 浮点值转成【带符号】的整数（乘 10，消掉 1 位小数），
# 供 bash 的整数比较使用。纯参数展开，0 次 fork。
#   -11.1 → -111     -17.0 → -170      0.0 → 0
# 上面的门限常量都是 0.1 的整数倍，因此不丢精度。
# 用 bash 整数比较可以避免在循环里 fork awk。
_optics_dbm_to_int10() {
    local v="$1"
    local sign="" int_part frac_part

    [[ -z "$v" ]] && { echo "0"; return 0; }

    [[ "$v" == -* ]] && { sign="-"; v="${v#-}"; }

    int_part="${v%%.*}"
    if [[ "$v" == *.* ]]; then
        frac_part="${v#*.}"
    else
        frac_part="0"
    fi

    # 只取 1 位小数；非数字一律当 0，避免 (( )) 里出现语法错误
    [[ "$int_part" =~ ^[0-9]*$ ]] || int_part=0
    [[ "$frac_part" =~ ^[0-9] ]] || frac_part=0
    frac_part="${frac_part:0:1}"
    [[ -z "$int_part" ]] && int_part=0
    [[ -z "$frac_part" ]] && frac_part=0

    echo "${sign}$(( int_part * 10 + frac_part ))"
    return 0
}

_optics_rx_floor_dbm() {
    local text="$1"
    local lines line norm best="" cand

    lines=$(echo "$text" | grep -i "transceiver type")
    [[ -z "$lines" ]] && { echo "$NIC_RX_FLOOR_SX"; return 0; }

    # 逐个 type 行判定，取最保守（数值最大）的下限。
    # 判断顺序：先长距后短距，避免 "er" 被 "sr" 之类的子串规则抢走。
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        norm="${line#*:}"          # 去掉字段名
        norm="${norm,,}"           # 统一小写
        norm="${norm//[[:space:]]/}"   # ★ 去掉空格："10g base-sr" → "10gbase-sr"
        norm="${norm//-/}"             # 去掉连字符，统一写法

        case "$norm" in
            *10gbaseer*|*10gbasezr*|*1550*)        cand="$NIC_RX_FLOOR_ER" ;;
            *10gbaselr*|*10gbaselw*|*1310*)        cand="$NIC_RX_FLOOR_LR" ;;
            *10gbasesr*|*10gbasesw*|*850*)         cand="$NIC_RX_FLOOR_SR" ;;
            *1000baselx*|*1000baselh*)             cand="$NIC_RX_FLOOR_LX" ;;
            *1000basesx*)                          cand="$NIC_RX_FLOOR_SX" ;;
            *)                                     continue ;;
        esac

        # 取最大值 = 最保守（最先触发告警）的判定标准。
        # 用纯 bash 整数比较，不要为每个 type 行 fork 一个 awk。
        #
        # 门限全是【负数】，不能简单去掉负号再比：
        # 去负号会把 -11.1→111、-17.0→170，于是 170 更大、判定成"更保守"，
        # 实际却选了最宽松的 -17.0，方向完全相反。
        # 必须先还原成带符号整数（乘 10 消掉小数位）再比较：
        #     -11.1 → -111（最大，最保守）  -19.0 → -190（最小）
        local cand_i best_i
        cand_i=$(_optics_dbm_to_int10 "$cand")
        if [[ -z "$best" ]]; then
            best="$cand"
        else
            best_i=$(_optics_dbm_to_int10 "$best")
            (( cand_i > best_i )) && best="$cand"
        fi
    done <<< "$lines"

    echo "${best:-$NIC_RX_FLOOR_SX}"
    return 0
}

# ============================================================================
# 光功率健康判定
# ============================================================================

# 判定收光是否偏低，输出 "1" 或空。
#
# 判据以【模块自带 DDM 门限】为唯一权威：厂商针对这颗模块标定的门限已经
# 综合考虑了模块类型、速率、发射端特性与链路预算，比任何通用标准值都更
# 贴合实际。例如 Intel AFBR-709DMZ（10GBASE-SR）的 Rx 低预警门限为
# -16.99 dBm，而 10GBASE-SR 的链路灵敏度标准值是 -11.1 dBm —— 相差近 6 dB。
# 用标准值去套会把大量正常口误报成"余量耗尽"。
#
# 因此：模块报了门限 → 只用门限判定，不再叠加标准值；
#       模块没报门限 → 才按模块类型取灵敏度标准值兜底。
#
# 优先级（降序）：
#   1) 模块低【预警】门限 —— 最早触发的信号，覆盖预警区+告警区
#   2) 模块低告警门限   —— 模块未报预警门限时使用
#   3) 按类型自适应的灵敏度标准值（见 _optics_rx_floor_dbm）
#
# 预警门限优先于告警门限：DDM 里预警门限 > 告警门限（预警先触发）。
# 若先判告警，则在"已跌破预警但还没到告警"这段区间会漏报，
# 而这恰恰是要提前介入的窗口。用预警门限判定可同时覆盖两个区间。
#
# 放在 errors 列的理由：错误计数器反映的是"已经坏到出错"，而收光贴在
# 灵敏度底线上时计数可能全为 0 —— 这个口正处于"余量耗尽、即将开始出错"
# 的状态，属于典型的【预示硬件故障】。
_optics_rx_is_low() {
    local rx_mw="$1"          # 实测收光 mW
    local low_warn="$2"       # 模块低预警门限 mW（可空）
    local low_alarm="$3"      # 模块低告警门限 mW（可空）
    local floor_dbm="$4"      # 类型自适应下限 dBm（可空，仅兜底时用）

    [[ -z "$rx_mw" || "$rx_mw" == "N/A" ]] && return 0
    [[ -z "$floor_dbm" ]] && floor_dbm="$NIC_RX_FLOOR_SX"

    # 数值比较统一交给 awk（bash 只能做整数比较，光功率是小数）
    awk -v rx="$rx_mw" -v lw="$low_warn" -v la="$low_alarm" -v fl="$floor_dbm" 'BEGIN {
        if (rx <= 0) exit 1

        # 1) 模块低预警门限（覆盖预警区 + 告警区）
        if (lw != "" && lw + 0 > 0) { exit !(rx <= lw + 0) }
        # 2) 模块低告警门限（模块没报预警门限时的退路）
        if (la != "" && la + 0 > 0) { exit !(rx <= la + 0) }

        # 3) 模块未公布任何门限 → 按类型取灵敏度标准值兜底。
        #    把实测 mW 转成 dBm 再比较：dBm = 10*log10(mW)
        dbm = 10 * log(rx) / log(10)
        exit !(dbm <= fl + 0)
    }' && echo "1"
    return 0
}

# 原始文本用【参数传进来】，不要试图用变量从命令替换里往外带数据。
#
# 背景：get_optics_info 需要 ethtool -m 的原始文本来解析 DDM 告警位，
# 但本函数的 stdout 已被"10 字段向量"占用，没法再回传原始文本。
#
# 两条走不通的路：
#   1) 在 get_optics_info 里直接引用本函数的 local —— 调用方看不到，
#      展开为空串，DDM 告警解析会静默失效（没有 set -u，不报错）。
#   2) 让本函数给全局变量赋值 —— 本函数是在
#         eth_out=$(get_optics_info_ethtool ...)
#      这个【命令替换子 shell】里执行的，子 shell 里对全局变量的赋值
#      在子 shell 退出时全部丢弃，父 shell 看不到。
#
# 根本原则：不要用变量从命令替换里往外带数据。正确做法是让需要数据的
# 那一层自己去读，然后把数据【作为参数传进去】：
#   eth_raw=$($SUDO ethtool -m "$iface")                   # 在 get_optics_info 里读
#   eth_out=$(get_optics_info_ethtool "$iface" "$eth_raw") # 传进来
#   ddm=$(_optics_ddm_alarms "$eth_raw")                   # 同一层直接用
# 附带好处：ethtool -m 从"每口读两次"变成"只读一次"。
#
# 可选参数 $2 = 已经读好的原始文本；给了就不再自己跑 ethtool。
get_optics_info_ethtool() {
    local iface="$1"
    local pre_read="${2:-}"        # 非空表示调用方已读过，直接用

    local vendor="" pn="" ver="" sn=""
    local tx_power="" rx_power="" temperature=""

    if ! command -v ethtool &>/dev/null; then
        echo "$OPTICS_SENTINEL"
        return 1
    fi

    # 用 `if ! out=$(cmd)` 直接判断失败：先赋值再看 $? 捕不到 cmd 的退出码
    # （`var=$(cmd)` 之后 $? 恒为 0）。这样"网卡不支持 -m / 无光模块"
    # 能立刻短路，不必等下面的文本检查。
    local ethtool_output
    if [[ -n "$pre_read" ]]; then
        # 调用方已读过（它自己也需要这份文本），直接复用，避免重复 fork。
        ethtool_output="$pre_read"
    elif ! ethtool_output=$($SUDO ethtool -m "$iface" 2>/dev/null); then
        echo "$OPTICS_SENTINEL"
        return 1
    fi
    if [[ -z "$ethtool_output" ]]; then
        echo "$OPTICS_SENTINEL"
        return 1
    fi

    # 没有 "Vendor name" 基本可判定这不是一个可解析的光模块页（可能是电口，
    # 或驱动不支持 SFF-8636/8472 页读取），直接放弃以免输出一堆空值
    if ! echo "$ethtool_output" | grep -qi "Vendor name"; then
        echo "$OPTICS_SENTINEL"
        return 1
    fi

    # 统一用 _optics_field 取值，避免同一段 grep|head|awk|sed 在多处重复
    vendor=$(_optics_field "$ethtool_output" "Vendor name")
    pn=$(_optics_field "$ethtool_output" "Vendor PN")
    ver=$(_optics_field "$ethtool_output" "Vendor rev")
    sn=$(_optics_field "$ethtool_output" "Vendor SN")

    # 光功率：不同驱动/模块的字段名不一样，两种都试。
    #   "Laser output power" 是 SFF-8636 常见写法，"Tx power" 见于部分驱动
    #
    # 取值行必须排除 threshold / alarm / warning 行：ethtool -m 里同一前缀
    # 会出现在多行，例如
    #     Laser rx power low warning threshold : 0.0200 mW   ← 门限，不是实测
    #     Receiver signal average optical power : 0.0742 mW  ← 实测值
    # 若泛匹配到门限行，会把【门限】当成【实测收光】写进 CSV，数值与含义全错。
    tx_power=$(_optics_extract_power_mw \
        "$(echo "$ethtool_output" \
            | grep -iE "Laser output power|Tx power" \
            | grep -viE "threshold|alarm|warning" | head -1)")
    rx_power=$(_optics_extract_power_mw \
        "$(echo "$ethtool_output" \
            | grep -iE "Receiver signal average optical power|Rx power" \
            | grep -viE "threshold|alarm|warning" | head -1)")

    temperature=$(_optics_extract_temp_c \
        "$(echo "$ethtool_output" | grep -i "Module temperature" \
            | grep -viE "threshold|alarm|warning" | head -1)")

    # 第 8/9/10 个字段：模块自带的收光低预警/低告警门限，以及按模块类型
    # 自适应的灵敏度下限。三者【仅供判定收光是否偏低，不进 CSV】，
    # 因此这些字段不进 CSV。
    local th lw la floor_dbm
    th=$(_optics_rx_thresholds "$ethtool_output")
    lw="${th%%|*}"
    la="${th##*|}"
    floor_dbm=$(_optics_rx_floor_dbm "$ethtool_output")

    echo "${vendor:-N/A}|${pn:-N/A}|${ver:-N/A}|${sn:-N/A}|${tx_power:-N/A}|${rx_power:-N/A}|${temperature:-N/A}|${lw}|${la}|${floor_dbm}"
    return 0
}

# 注：原 _optics_power_valid 已随"先 ethtool 后 mlxlink"的短路逻辑一并删除。
# 现在两个来源都会被读取并逐字段比较，不再需要"功率是否可用"这一单一闸门。

# 归一化光模块身份字段，供 ethtool 与 mlxlink 交叉核对时比较。
#
# 规则：转大写 → 去掉全部空白 → 去掉【尾部】标点。
# 两个工具对同一模块的渲染差异只在空白和尾部标点上，例如：
#   ethtool : "FINISAR CORP."   （保留内部空格与尾部句点）
#   mlxlink : "FINISARCORP."    （去掉内部空格，保留句点）
# 二者指向同一模块，差异不是身份差异。
#
# 只去尾部，不动首字符（编号长度差异不是本函数造成的）。
#
# 用 [[:punct:]] 字符类而不要手写标点集合：方括号表达式里【未转义的 ';'
# 仍是命令分隔符】，bash 在解析阶段就会报错并拒绝加载整个脚本
#     syntax error in conditional expression: unexpected token `;'
# 这是解析期错误，与机器环境无关。''[[:punct:]]'' 的字面量不含 ';'，
# 既能安全解析，又一次性覆盖所有标点。
_optics_norm_ident() {
    local s="$1"
    s="${s^^}"                       # 转大写
    s="${s//[[:space:]]/}"           # 去掉全部空白
    while [[ "$s" == *[[:punct:]] ]]; do
        s="${s%?}"
    done
    echo "$s"
}

get_optics_info() {
    local iface="$1"
    local pcie_bus_id="$2"
    local nic_vendor="$3"

    # ========================================================================
    # 综合判断：ethtool 与 mlxlink 【同时读取】，互相核对
    # ========================================================================
    # 两个来源各有独占信息，缺一不可：
    #   ethtool 独有：SFF 门限表（收光低预警/低告警）、Transceiver type
    #                 （类型自适应下限要用）
    #   mlxlink 独有：per-lane 故障位、Recommendation、Voltage、Bias
    #                 （ethtool -m 不一定给）
    # 因此不能只用一个。取数正确性优先于速度：mlxlink 在 Mellanox 上
    # 单次数秒（走 MST 驱动逐字节读 I2C），这个代价是刻意接受的。
    #
    # 取值优先级：以 ethtool 为准（它在本环境能读出 mlxlink 读不到的真实
    # 功率）。mlxlink 只用于【补 ethtool 缺失的字段】和【交叉核对】。
    # 两边不一致时不静默取一个，而是在 errors 里留下标注，供现场判断。
    # ========================================================================

    # 不要写成 `... || echo "$OPTICS_SENTINEL"`：
    # get_optics_info_ethtool 的 4 条失败路径【自己就会】echo 哨兵值并
    # return 1，再补一次会让命令替换收到两行输出，eth_out 整体永远【不等于】
    # $OPTICS_SENTINEL，下面两个分支就永远进不去：
    #   - "两侧都拿不到 → 返回哨兵"
    #   - "只有 mlxlink 可用"（老 mlx5 驱动只有这一条路）
    #
    # 先在本层把 ethtool -m 读一次，再【传进去】：
    # 不交给 get_optics_info_ethtool 去读、再想办法把文本传回来 —— 那个函数
    # 是在命令替换子 shell 里跑的，它设的任何变量都会随子 shell 一起消失。
    #
    # 附带好处：ethtool -m 由"每口两次"（一次算字段、一次解告警位）降到一次。
    #
    # 失败（无光模块/驱动不支持）时 eth_raw 为空，get_optics_info_ethtool
    # 会走它自己的失败分支返回哨兵。
    local eth_raw=""
    if command -v ethtool &>/dev/null; then
        eth_raw=$($SUDO ethtool -m "$iface" 2>/dev/null || true)
    fi

    local eth_out=""
    eth_out=$(get_optics_info_ethtool "$iface" "$eth_raw" 2>/dev/null)
    [[ -n "$eth_out" ]] || eth_out="$OPTICS_SENTINEL"

    local mlx_out=""
    local mlx_available=false
    if [[ "$nic_vendor" == "Mellanox" ]] \
       && [[ -n "$pcie_bus_id" && "$pcie_bus_id" != "N/A" && "$pcie_bus_id" != "Unknown" ]]; then
        # 说明：双口卡的两个口 BDF 不同（0000:17:00.0 / 0000:17:00.1），
        # 各自有自己的光模块笼子，因此正常情况【每个口都会真的跑一次】
        # mlxlink —— 这是为交叉核对刻意接受的代价（每口约数秒）。
        # MLXLINK_CACHE 只防止"同一 BDF 被重复查询"（例如端口映射异常
        # 导致同一口被处理两次），命中时直接复用，不会返回别的口的数据。
        mlx_out=$(get_optics_info_mlxlink "$pcie_bus_id" 2>/dev/null || true)
        [[ -n "$mlx_out" && "$mlx_out" != "$OPTICS_SENTINEL" ]] && mlx_available=true
    fi

    # ---- 两侧都拿不到：返回哨兵 ----
    if [[ "$eth_out" == "$OPTICS_SENTINEL" && "$mlx_available" != true ]]; then
        echo "$OPTICS_SENTINEL"
        return 1
    fi

    # ---- 只有 mlxlink 拿到（老 mlx5 驱动 ethtool -m 读不到）----
    if [[ "$eth_out" == "$OPTICS_SENTINEL" ]]; then
        log_debug "  光模块: ethtool 不可用，仅用 mlxlink ($iface)"
        echo "$mlx_out"
        return 0
    fi

    # ---- 只有 ethtool 拿到 ----
    if [[ "$mlx_available" != true ]]; then
        echo "$eth_out"
        return 0
    fi

    # ---- 两侧都有：逐字段综合 + 交叉核对 ----
    local -a e=() m=()
    IFS='|' read -r -a e <<< "$eth_out"
    IFS='|' read -r -a m <<< "$mlx_out"

    # 合并：默认用 ethtool，仅当 ethtool 该字段为空/N/A 时用 mlxlink 补
    local -a r=("${e[@]}")
    local notes=""                       # 交叉核对发现的问题，进 errors
    local i
    for i in 0 1 2 3 6; do               # vendor/pn/ver/sn/temp
        if [[ -z "${r[$i]}" || "${r[$i]}" == "N/A" ]] \
           && [[ -n "${m[$i]:-}" && "${m[$i]}" != "N/A" ]]; then
            r[$i]="${m[$i]}"
            log_debug "  光模块: 字段 $i 用 mlxlink 补齐 (ethtool 为空)"
        fi
    done
    # 功率字段（4=tx, 5=rx）也允许用 mlxlink 补，
    # 但 mlxlink 的 0/-inf 是"不支持"的占位，必须排除，否则会把
    # 1.0 mW 这种假值当成真实功率写进 CSV。
    for i in 4 5; do
        if [[ -z "${r[$i]}" || "${r[$i]}" == "N/A" ]] \
           && [[ -n "${m[$i]:-}" && "${m[$i]}" != "N/A" ]] \
           && ! _is_zero_dbm_mw "${m[$i]}"; then
            r[$i]="${m[$i]}"
            log_debug "  光模块: 功率 $i 用 mlxlink 补齐 (ethtool 为空)"
        fi
    done

    # ---- 交叉核对（只在两边都有真实值时比较，避免误报）----
    #
    # 身份锚点用 PN 与 SN，不用 vendor name：
    # PN 逐型号唯一、SN 逐序列号唯一，二者一致就说明两个工具读的是
    # 【同一个物理模块】，不可能是换模块、串扰读错口或模块损坏。
    # vendor name 在此类模块上是【定长空格填充】的自由文本，两个工具对
    # 内部空白的处理不同，例如同一模块（FINISAR FTLF8536P4BCL-HC）：
    #     ethtool : "FINISAR CORP."    （保留内部空格与尾部句点）
    #     mlxlink : "FINISARCORP."     （去掉内部空格，保留句点）
    # 拿它做判据会让每个 FINISAR 模块都误报。同一协议里也有反例：
    # "NADDOD" 是单一无标点词，两边渲染天然相同，从不报。
    #
    # 规则：
    #   1) 比较前先归一化：转大写、去掉全部空白、去掉尾部标点
    #   2) vendor 单独不一致【不足以】判定异常，必须有 PN 或 SN
    #      同时不一致才上报（互相印证）；否则只写 debug 日志
    #
    # 取舍：若某模块被贴错牌/仿冒，但 PN+SN 恰好与真品一致，vendor 差异
    # 将不再上报。这个风险远小于"每个 FINISAR 模块都误报"。

    # 归一化与身份锚点比较。_optics_norm_ident 定义在文件作用域。

    local _ev _mv _en _mn
    local _ident_bad=false               # PN 或 SN 是否真的不一致
    for i in 1 3; do                     # 1=PN  3=SN：身份锚点
        _ev="${e[$i]:-}"; _mv="${m[$i]:-}"
        [[ -z "$_ev" || "$_ev" == "N/A" ]] && continue
        [[ -z "$_mv" || "$_mv" == "N/A" ]] && continue
        _en=$(_optics_norm_ident "$_ev")
        _mn=$(_optics_norm_ident "$_mv")
        if [[ "$_en" != "$_mn" ]]; then
            notes+="optics_mismatch_$i:1;"
            _ident_bad=true
        fi
    done

    # vendor 差异只有在 PN/SN 也异常时才上报，避免把
    # "FINISAR CORP." vs "FINISAR CORP" 这类渲染差异当故障。
    _ev="${e[0]:-}"; _mv="${m[0]:-}"
    if [[ -n "$_ev" && "$_ev" != "N/A" && -n "$_mv" && "$_mv" != "N/A" ]]; then
        _en=$(_optics_norm_ident "$_ev")
        _mn=$(_optics_norm_ident "$_mv")
        if [[ "$_en" != "$_mn" ]]; then
            if [[ "$_ident_bad" == true ]]; then
                notes+="optics_mismatch_0:1;"
            else
                log_debug "  光模块: vendor 渲染差异（PN/SN 一致，非异常）: '$_ev' vs '$_mv'"
            fi
        fi
    fi

    # 温度：允许小差异（ethtool 33.11 vs mlxlink 33，取整与刷新时刻不同），
    # 超过 3°C 才算不一致。
    if [[ -n "${e[6]:-}" && "${e[6]}" != "N/A" && -n "${m[6]:-}" && "${m[6]}" != "N/A" ]]; then
        if awk -v a="${e[6]}" -v b="${m[6]}" \
             'BEGIN { d = a - b; if (d < 0) d = -d; exit !(d > 3) }'; then
            notes+="optics_temp_mismatch:${e[6]}/${m[6]};"
        fi
    fi

    # 功率：mlxlink 的 0/-inf/N/A 表示"不支持"，不是"读数不同"，
    # 绝不能拿来比较，否则每个口都会误报 mismatch。
    local _pwr_cmp=0                     # 实际【比较过】的功率项数
    for i in 4 5; do
        _ev="${e[$i]:-}"; _mv="${m[$i]:-}"
        [[ -z "$_ev" || "$_ev" == "N/A" ]] && continue
        [[ -z "$_mv" || "$_mv" == "N/A" ]] && continue
        _is_zero_dbm_mw "$_mv" && continue
        _is_zero_dbm_mw "$_ev" && continue
        # 用 dB 比较，不用 mW 百分比。
        #
        # mlxlink 把 dBm 【取整】输出，同一时刻同一物理量会出现：
        #   ethtool : 0.5169 mW / -2.87 dBm
        #   mlxlink :            -2    dBm
        # 真实只差 0.87 dB。但 -2 dBm 换算回 mW 是 0.6310，相对差
        # |0.5169-0.6310| / 0.5169 = 22.1%，用 20% 门限就会误报。
        #
        # 根因：整数 dBm 自带 ±0.5 dB 量化误差，而换算成 mW 后，
        # 0.5 dB 恰好约等于 12% 的相对误差。用 20% 的相对门限去卡一个
        # 12% 的量化台阶，健康模块必然频繁误报。
        #
        # 光功率本质是对数量，差异就应该在 dB 域比较：
        # 0.87 dB 的量化差在 dB 域一目了然，在 mW 域却成了 22%。
        # 门限取 3 dB：远大于 ±0.5 dB 量化台阶，又远小于 DDM 低预警到
        # 低告警的间距（3~7 dB），既能过滤量化噪声，又不会漏掉真实衰减。
        if awk -v a="$_ev" -v b="$_mv" \
             'BEGIN { if (a <= 0 || b <= 0) exit 1
                      # mW -> dBm，再取绝对差
                      da = 10 * log(a) / log(10)
                      db = 10 * log(b) / log(10)
                      d = da - db; if (d < 0) d = -d
                      exit !(d > 3) }'; then
            # 把【两侧原值】一起写进去，与 optics_temp_mismatch 的写法一致：
            # 只写 ":1" 的话现场无法判断"另一边到底读到了多少"，只能靠猜。
            notes+="optics_power_mismatch_$i:${_ev}/${_mv};"
        else
            # 一致时也把两边的值打出来，否则现场看不到 mlxlink 究竟读到了
            # 多少，无法回答"它读的是不是同一个物理量"，只能再跑一次。
            log_debug "  光模块: 功率 $i 一致 (ethtool=${_ev} mlxlink=${_mv})"
        fi
        _pwr_cmp=$(( _pwr_cmp + 1 ))
    done

    # 模块自己置位的 DDM 告警/预警标志。
    # 这是全脚本唯一不依赖本脚本推算阈值的光学判据：门限由模块厂商写入、
    # 越界由模块硬件判定，这里只做搬运，因此几乎不可能误报。
    # 与 optics_rx_low（拿实测值比门限）互为补足。
    local ddm_alarms
    ddm_alarms=$(_optics_ddm_alarms "$eth_raw")
    [[ -n "$ddm_alarms" ]] && notes+="ddm_alarm:${ddm_alarms%,};"

    if [[ -n "$notes" ]]; then
        log_debug "  光模块: 交叉核对发现不一致 -> ${notes}"
    elif [[ "$_pwr_cmp" -gt 0 ]]; then
        # 只有【真的比较过】才说"一致"。
        # 只看 $notes 是否为空会把"没比较"说成"一致"：mlxlink 读不到功率时
        # 循环被 continue 全部跳过，$notes 同样为空。
        # "没比较"是【未知】，"比较后一致"才是【已验证】，两者不能混。
        log_debug "  光模块: 交叉核对一致（已比对 ${_pwr_cmp} 项功率）($iface)"
    else
        # mlxlink 没给出可用的功率值（0/N/A 占位），无法比对。
        # 明确说"无数据可比对"，不要说"一致"。
        log_debug "  光模块: mlxlink 未提供功率，无数据可交叉核对（仅 ethtool 单源）($iface)"
    fi

    # 第 11 个字段 = 交叉核对结果，供调用方并入 errors。
    # 用额外字段而不是全局变量：get_optics_info 是在 $(...) 子 shell 里
    # 被调用的，子 shell 里对全局变量的赋值【不会】传回父 shell。
    echo "${r[0]}|${r[1]}|${r[2]}|${r[3]}|${r[4]}|${r[5]}|${r[6]}|${r[7]}|${r[8]}|${r[9]}|${notes}"
    return 0
}

# ============================================================================
# CSV
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"
    local clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    if [[ -z "$clean_serial" ]] || [[ "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/nic_info.csv"
    else
        echo "${dir}/nic_info_${clean_serial}.csv"
    fi
}

# CSV 列定义：列名与顺序的唯一来源。改这里就等于改表头，
# 下面的 csv_build_row 会核对实参个数，防止改了表头忘了改数据行。
readonly CSV_HEADER='server_serial,nic_vendor,nic_model,nic_submodel,nic_product,nic_serial,nic_speed_gb,nic_port_num,nic_port_subnum,nic_firmware,nic_interface_name,nic_link_detected,nic_mac,nic_lldp_sw,nic_lldp_port,nic_pcie_bus_id,nic_port_pcie_bus_id,pcie_slot,pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,optics_vendor,optics_pn,optics_ver,optics_sn,optics_tx_power_mw,optics_rx_power_mw,optics_temperature_c,errors'

# 列数，用逗号数 +1 得到（不要用 wc -l 数行，那样会少 1）
# 光模块信息的"无数据"哨兵值。10 个字段：厂商/PN/版本/SN/tx/rx/温度/
# 模块低预警门限/模块低告警门限/类型自适应灵敏度下限。
# 后三个只用于判定收光是否偏低，不进 CSV。
readonly OPTICS_SENTINEL="N/A|N/A|N/A|N/A|N/A|N/A|N/A|||"
readonly CSV_COLUMNS=31

write_csv_header() {
    local output_file="$1"
    printf '%s\n' "$CSV_HEADER" > "$output_file"
    log_debug "CSV头已写入: $output_file"
    return 0
}

# 把各列值转义后拼成一行 CSV，并强制校验列数。
#   $# 必须等于 CSV_COLUMNS，否则说明调用处与表头不同步 —— 这种情况必须
#   立刻暴露（输出到 stderr），否则会静默产出错位的 CSV，下游解析全乱。
csv_build_row() {
    if [[ $# -ne $CSV_COLUMNS ]]; then
        log_error "内部错误: CSV 列数不匹配（期望 $CSV_COLUMNS，实际 $#）"
        return 1
    fi

    # ★★ 严禁用 `[[ -n "$out" ]]` 判断"是不是第一个字段" ★★
    #
    # 旧实现：
    #     for v in "$@"; do
    #         if [[ -n "$out" ]]; then out+=",$(csv_escape "$v")"
    #         else                     out="$(csv_escape "$v")"
    #         fi
    #     done
    # 它把"$out 非空"当成了"已输出过字段"的代理。该代理仅在
    # 【前面所有字段都非空】时成立。一旦开头有连续空字段：
    #     ('', 'B', 'C')  →  'B,C'    ← 只剩 2 列，应为 3 列
    #     ('', '', 'C')   →  'C'      ← 只剩 1 列，应为 3 列
    # 因为 csv_escape('') 输出空串，$out 仍为空，于是后续字段不断走
    # assign（覆盖）而不是 append，开头的空列连同分隔符一起被吞掉。
    #
    # 后果是【静默错列】：行被写成少一列，表头对不齐。
    # 更糟的是上面的列数断言检查的是【实参个数】（$#），传 30 个参数
    # 照样通过 —— 它根本发现不了拼出来的列数少了。
    #
    # 触发路径（不止 -s ""）：
    #   1) -s "" —— parse_args 里 SYSTEM_SERIAL="$2" 无任何校验
    #   2) 正常采集 —— 调用点传入的 $nic_serial / $product / $optics_tx
    #      / $optics_rx / $optics_temp 在真实硬件上都可能为空
    #      （例如 get_optics_info 的早返回分支只回 10 个字段）。
    #
    # 改用【下标】判断，与字段内容完全解耦：
    local out="" v i=0
    for v in "$@"; do
        if (( i > 0 )); then
            out+=",$(csv_escape "$v")"
        else
            out="$(csv_escape "$v")"
        fi
        i=$(( i + 1 ))
    done

    # ★ 真正的列数自检：数【拼出来的字段数】，而不是实参个数。
    #   csv_escape 会给含逗号的字段加引号，因此不能简单地数逗号 ——
    #   必须按 CSV 引号规则扫描。这里用纯参数展开逐字符走一遍，
    #   0 次 fork（本函数被每个端口调用一次，不能用 awk/sed）。
    local _n=1 _q=0 _ch _k
    for (( _k = 0; _k < ${#out}; _k++ )); do
        _ch="${out:_k:1}"
        if [[ "$_ch" == '"' ]]; then
            # 连续两个 "" 是转义后的引号，不切换引号状态
            if [[ "${out:_k+1:1}" == '"' ]]; then
                _k=$(( _k + 1 ))
            else
                _q=$(( 1 - _q ))
            fi
        elif [[ "$_ch" == ',' && "$_q" -eq 0 ]]; then
            _n=$(( _n + 1 ))
        fi
    done

    if [[ "$_n" -ne "$CSV_COLUMNS" ]]; then
        log_error "内部错误: CSV 字段数不匹配（期望 $CSV_COLUMNS，实际 $_n）"
        return 1
    fi

    printf '%s' "$out"
    return 0
}

# ============================================================================
# 网卡信息收集主函数
# ============================================================================

collect_nic_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集网卡信息..."

    # 用 mapfile 按行读入，不要 `nics=($(...))`：
    # 后者在"没有物理网卡"时会拿到 ('')，长度 1，判空失效，于是拿空接口名
    # 跑完整流程，最终输出一条全 N/A 的假记录。
    local nics=()
    mapfile -t nics < <(get_physical_nics)

    if [[ ${#nics[@]} -eq 0 ]]; then
        log_warn "未检测到物理网卡！"
        return 0
    fi

    log_info "检测到 ${#nics[@]} 个物理网卡: ${nics[*]}"

    # 一次遍历建立 接口 → bus 映射，端口分组查表。
    # 不要对每个 bus 重扫全部网卡（每个网卡还可能调 lspci）：
    # 那是 O(bus数 × 网卡数)，这里是 O(网卡数)。
    build_iface_bus_map

    local record_count=0
    local -A processed_bus=()      # 用关联数组代替线性查找的数组

    local iface pci_addr bus_base
    for iface in "${nics[@]}"; do
        log_debug "正在处理网卡: $iface"

        pci_addr=$(get_pci_address "$iface")
        bus_base=$(get_pci_bus_base "$pci_addr")

        # 同一张多口卡只输出一组卡级信息，卡级字段以第一个端口为准
        if [[ -n "${processed_bus[$bus_base]+x}" ]]; then
            log_debug "PCI Bus $bus_base 已处理，跳过 $iface"
            continue
        fi
        processed_bus["$bus_base"]=1

        local ports=()
        mapfile -t ports < <(get_ports_for_bus "$bus_base")

        # 防御：正常情况下面这张卡自己一定在 IFACE_BUS_MAP 里（它已通过
        # is_physical_nic），所以 ports 至少有一个。万一映射构建异常导致
        # 查不到，就退回"本卡只有当前这个口"，绝不能因为端口数 0 而把
        # 整张网卡静默丢掉。
        if [[ ${#ports[@]} -eq 0 ]]; then
            log_debug "PCI Bus $bus_base 未查到端口列表，回退为当前接口 $iface"
            ports=("$iface")
        fi

        local total_ports=${#ports[@]}
        local port_num_str="${total_ports}P"

        # ---- 卡级字段（一张卡只算一次）----
        local vendor model submodel product nic_serial firmware speed pcie_bus_id
        local pcie_gen pcie_link_cap pcie_link_sta
        vendor=$(get_nic_vendor "$pci_addr")
        model=$(get_nic_model "$pci_addr")
        submodel=$(get_nic_submodel "$pci_addr")
        product=$(get_nic_product "$pci_addr")
        nic_serial=$(get_nic_serial "$pci_addr")
        firmware=$(get_nic_firmware "$iface")
        speed=$(get_nic_speed_gb "$iface")
        pcie_bus_id=$(get_nic_pcie_bus_id "$iface")
        pcie_gen=$(get_pcie_gen "$pci_addr")
        pcie_link_cap=$(get_pcie_link_cap "$pci_addr")
        pcie_link_sta=$(get_pcie_link_sta "$pci_addr")

        log_info "✅ 网卡: $model (Bus: $bus_base, 端口数: $port_num_str, 速率: ${speed}Gb, PCIe: $pcie_gen $pcie_link_cap, $pcie_link_sta, BusID: $pcie_bus_id)"

        # ---- 逐端口输出 ----
        local subnum=1 port
        for port in "${ports[@]}"; do
            # ---- 端口级字段：每个物理口各取各的 ----
            # 注意 pcie_slot/vid/pid/gen 取的是"本端口"的 PCI 地址，
            # 因为多口卡的各口是独立的 PCI function，插槽/链路可能不同。
            local port_pci port_mac port_name port_link_state port_pcie_bus_id
            local port_pcie_slot port_pcie_vid port_pcie_pid
            local port_pcie_gen port_pcie_link_cap port_pcie_link_sta port_errors
            port_pci=$(get_pci_address "$port")
            port_mac=$(get_nic_mac "$port")
            port_name=$(get_nic_interface_name "$port")
            port_link_state=$(get_nic_link_detected "$port")
            port_pcie_bus_id=$(get_nic_pcie_bus_id "$port")
            port_pcie_slot=$(get_pcie_slot "$port_pci")
            port_pcie_vid=$(get_pcie_vendor_id_sysfs "$port_pci")
            port_pcie_pid=$(get_pcie_product_id_sysfs "$port_pci")
            port_pcie_gen=$(get_pcie_gen "$port_pci")
            port_pcie_link_cap=$(get_pcie_link_cap "$port_pci")
            port_pcie_link_sta=$(get_pcie_link_sta "$port_pci")
            # 第二个参数传本端口的 BDF：PCIe AER 是【每功能】独立的，
            # 双口卡两个口可能一个干净一个有错，必须按端口读。
            port_errors=$(get_nic_errors "$port" "$port_pci")

            # LLDP：拿对端交换机名与端口
            # 用 IFS 切分而不是 echo|cut —— cut 每调用一次就是一次 fork，
            # 而这段在每个端口上都要跑，8 口就是几十次无谓的进程创建。
            local lldp_info lldp_sw lldp_port
            lldp_info=$(get_lldp_info "$port")
            IFS='|' read -r lldp_sw lldp_port _ <<< "$lldp_info"

            # 光模块：先默认全 N/A，只有拿到有效结果才覆盖，
            # 这样"没有光模块"和"有光模块但读不到"在 CSV 里表现一致
            local optics_vendor="N/A" optics_pn="N/A" optics_ver="N/A" optics_sn="N/A"
            local optics_tx="N/A" optics_rx="N/A" optics_temp="N/A"
            # 模块自带的收光门限 + 类型自适应下限（只用于判偏低，不进 CSV）
            local optics_lw="" optics_la="" optics_floor=""
            # 第 11 字段：ethtool 与 mlxlink 的交叉核对结果
            local optics_xcheck=""

            local optics_info
            optics_info=$(get_optics_info "$port" "$port_pcie_bus_id" "$vendor")
            if [[ "$optics_info" != "$OPTICS_SENTINEL" ]]; then
                # 10 个数据字段 + 1 个交叉核对字段，一次性切开
                IFS='|' read -r optics_vendor optics_pn optics_ver optics_sn \
                               optics_tx optics_rx optics_temp \
                               optics_lw optics_la optics_floor optics_xcheck _ <<< "$optics_info"
            fi

            # 交叉核对发现的不一致 → 并入 errors。
            # 两个独立来源对同一模块给出不同读数，本身就是需要现场确认的
            # 异常（可能是模块将坏、接触不良、或读取串扰），符合
            # "errors 只记录可能预示硬件故障的信号"这一约定。
            if [[ -n "$optics_xcheck" ]]; then
                local _xc="${optics_xcheck%;}"
                port_errors="${port_errors:-0}"
                [[ "$port_errors" == "0" ]] && port_errors=""
                port_errors+="${port_errors:+;}$_xc"
                [[ -n "$port_errors" ]] || port_errors="0"
            fi

            # 收光偏低 → 并入 errors。这属于"预示硬件故障"：
            # 光功率跌破模块自带 DDM 门限时错误计数可能仍为 0，
            # 但模块自身已在报告异常。
            # 判据以模块 DDM 门限为权威；模块未公布门限时才按类型兜底。
            #
            # 只在【链路 up】时判收光，因为收光是否偏低属于【运行状态】：
            #   链路 up   → 对端在发光，收光低于门限说明模块/光纤真的在劣化
            #   链路 down → 对端不发光，收光是物理下限，必然结果而非故障
            #
            # 与 link_down 的分工：
            #   optics_rx_low  只问【当前是否在运行】→ 看 carrier
            #   link_down      区分【线断了】还是【本就没插过】→ 还要看流量
            # 链路 down 时静默，把"没接线"的结论留给 link_down，
            # 两个判据互补而不重叠。
            if _nic_link_is_up "$port" \
               && [[ -n "$(_optics_rx_is_low "$optics_rx" "$optics_lw" "$optics_la" "$optics_floor")" ]]; then
                local rx_dbm
                rx_dbm=$(_optics_mw_to_dbm "$optics_rx")
                port_errors="${port_errors:-0}"
                [[ "$port_errors" == "0" ]] && port_errors=""
                port_errors+="${port_errors:+;}optics_rx_low:1"
                [[ -n "$rx_dbm" ]] && port_errors+=";optics_rx_dbm:${rx_dbm}"
                [[ -n "$port_errors" ]] || port_errors="0"
            fi

            # ---- 组装 CSV 行 ----
            # 顺序必须与 CSV_HEADER 严格一致；末尾有列数自检（见 csv_build_row）
            #
            # 必须检查 csv_build_row 的退出码：它在两条失败路径上都会
            # `log_error ...; return 1`，而 log_error 写的是 stderr，
            # stdout 一个字节都没有，于是 line 会是空串。
            # 脚本没有开 set -e，若不判失败就会继续往下走，
            # 无条件 `printf '%s\n' "$line" >> "$output_file"` 会在 CSV 里
            # 追加一个【空行】—— 既不是合法记录，又会让下游按行解析时多出
            # 一条垃圾，而 main 依然打印"完成"和记录条数，看起来一切正常。
            # 这里显式判失败并中止：宁可整次采集明确失败，
            # 也不要产出一个看起来成功、实际错位的 CSV。
            local line
            if ! line=$(csv_build_row \
                "$serial" "$vendor" "$model" "$submodel" "$product" "$nic_serial" \
                "$speed" "$port_num_str" "$subnum" "$firmware" "$port_name" \
                "$port_link_state" "$port_mac" "$lldp_sw" "$lldp_port" \
                "$pcie_bus_id" "$port_pcie_bus_id" "$port_pcie_slot" \
                "$port_pcie_vid" "$port_pcie_pid" \
                "$port_pcie_gen" "$port_pcie_link_cap" "$port_pcie_link_sta" \
                "$optics_vendor" "$optics_pn" "$optics_ver" "$optics_sn" \
                "$optics_tx" "$optics_rx" "$optics_temp" "$port_errors"); then
                log_error "端口 $port_name 的 CSV 行组装失败，已中止以免写出错位文件"
                log_error "已写入 $record_count 条记录，输出文件可能不完整: $output_file"
                return 1
            fi

            printf '%s\n' "$line" >> "$output_file"

            log_debug "   - 端口 $subnum/$total_ports: $port_name (MAC: $port_mac, Slot: $port_pcie_slot, BusID: $port_pcie_bus_id, Gen: $port_pcie_gen, Optics: $optics_vendor, Tx: $optics_tx, Rx: $optics_rx)"
            ((subnum++)) || true
            ((record_count++)) || true
        done
    done

    echo "$record_count"
    return 0
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_header "服务器网卡信息收集工具 (含光模块信息)"

    init_vendor_id_map

    # 只有用户没有用 -s 显式指定时，才去自动探测序列号。
    # 无条件覆盖会让 -s/--serial 这个命令行选项完全无效。
    if [[ "$SERIAL_EXPLICIT" != "true" ]]; then
        SYSTEM_SERIAL=$(get_system_serial)
    else
        log_info "使用命令行指定的序列号: $SYSTEM_SERIAL"
    fi
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    local missing_tools=()
    command -v dmidecode &>/dev/null || missing_tools+=("dmidecode")
    command -v lspci     &>/dev/null || missing_tools+=("pciutils")
    command -v ethtool   &>/dev/null || missing_tools+=("ethtool")

    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_warn "缺少以下工具: ${missing_tools[*]}"
        echo "  - CentOS/RHEL: yum install -y dmidecode pciutils ethtool" >&2
        echo "  - Ubuntu/Debian: apt-get install -y dmidecode pciutils ethtool" >&2
    fi

    if ! command -v mlxlink &>/dev/null; then
        log_debug "mlxlink 未安装，Mellanox 光模块将回退 ethtool -m"
    else
        log_debug "检测到 mlxlink: $(command -v mlxlink)"
    fi

    if ! $SUDO true 2>/dev/null; then
        if [[ -t 0 && -r /dev/tty ]]; then
            log_warn "需要sudo权限获取硬件信息，尝试获取..."
            if ! sudo -v 2>/dev/null; then
                log_warn "无法获取sudo权限"
                read -p "是否继续执行？[y/N] " -n 1 -r < /dev/tty
                echo >&2
                [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
            fi
        else
            log_warn "非交互环境，无免密sudo，将继续执行"
        fi
    fi

    load_pci_slot_map

    # uptime 只影响 carrier_changes 的速率判定，读一次供所有端口复用
    UPTIME_DAYS=$(get_uptime_days)
    [[ -n "$UPTIME_DAYS" ]] && log_debug "系统 uptime: ${UPTIME_DAYS} 天"

    [[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR" 2>/dev/null || {
        log_error "无法创建输出目录: $OUTPUT_DIR"
        exit 1
    }

    write_csv_header "$OUTPUT_FILE"

    local record_count
    record_count=$(collect_nic_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ ! -f "$OUTPUT_FILE" ]]; then
        log_error "输出文件生成失败"
        exit 1
    fi

    # 记录条数以 collect_nic_info 的返回值为准，不再用 wc -l 重新数一遍。
    # 两个来源会不一致（比如写文件失败时 wc 少一行却不报错），只保留一个。
    echo -e "📊 网卡端口记录: ${BLUE}${record_count:-0}${NC} 条" >&2
    print_separator
    cat "$OUTPUT_FILE"
    print_separator
    return 0
}

# ============================================================================
# 入口
# ============================================================================

set -o pipefail 2>/dev/null || true

show_help() {
    cat << EOF
服务器网卡信息收集工具

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示本帮助
    -d, --debug         输出调试日志
    -o, --output DIR    指定输出目录（默认: <脚本目录>/report）
    -s, --serial SN     手动指定服务器序列号（默认自动探测）
        --include-drops 把 dropped / discard 类计数也计入 errors 列
                        （默认排除：丢包通常源于拥塞，不是网卡或链路故障）

运行前提:
    建议以 root 运行，否则部分字段会取不到值。本工具只读，不修改任何配置。

输出:
    输出目录下名为 nic_info_<服务器序列号>.csv 的文件；序列号取不到时为
    nic_info.csv。★ 同名文件会被【直接覆盖】，需要保留历史请先改名或
    用 -o 换目录。
    31 列，一行 = 一个物理端口；多端口网卡每口一行，卡级字段重复。
    取不到的值填 N/A 或 UNKNOWN。

采集范围:
    只收集物理网卡的端口，以下接口不收集:
      - 回环接口
      - InfiniBand 接口（由 collect_ib.sh 收集）
      - 虚拟接口: veth / docker / br- / virbr / tun / tap / vnet / bond /
                  dummy / sit / ip6tnl / gre / gretap / erspan
      - USB 网卡
      - SR-IOV 虚拟功能 (VF)

列说明:
    server_serial          服务器序列号
    nic_vendor             网卡厂商
    nic_model              网卡型号
    nic_submodel           网卡子型号
    nic_product            网卡产品名
    nic_serial             网卡序列号
    nic_speed_gb           速率 (Gb/s)
    nic_port_num           该卡的端口总数
    nic_port_subnum        本端口序号，从 1 开始
    nic_firmware           网卡固件版本
    nic_interface_name     网卡接口名，如 enp94s0f0
    nic_link_detected      本端口当前是否检测到链路: yes / no
    nic_mac                网卡 MAC 地址
    nic_lldp_sw            LLDP 对端交换机名
    nic_lldp_port          LLDP 对端端口号
    nic_pcie_bus_id        网卡 PCI 地址
    nic_port_pcie_bus_id   本端口 PCI 地址
    pcie_slot              物理 PCIe 插槽名
    pcie_vendor_id         PCIe 厂商 ID
    pcie_product_id        PCIe 设备 ID
    pcie_gen               PCIe 链路速率与通道数
    pcie_link_cap          PCIe 链路能力（该卡最高能跑到多少）
    pcie_link_sta          PCIe 链路当前实际状态，含是否被降级
    optics_vendor          光模块厂商
    optics_pn              光模块型号
    optics_ver             光模块版本
    optics_sn              光模块序列号
    optics_tx_power_mw     光模块发射光功率 (mW)
    optics_rx_power_mw     光模块接收光功率 (mW)
    optics_temperature_c   光模块温度 (°C)
    errors                 硬件异常指标汇总；无异常时为 0

nic_speed_gb:
    已连接时为链路协商出的当前速率；未连接时填该口支持的最高速率。

nic_link_detected:
    yes = 当前检测到链路；no = 未检测到链路。该字段始终有值。
    ★ 它表示"链路是否建立"，不是"网线是否插着"：接了线但对端未开机、
      或交换机端口被关闭时同样为 no。读不到时按 no 处理。
      要判断"曾经通过流量、但现在断了"，请看 errors 列的 link_down。

errors:
    只收录"可能由硬件引起、或预示硬件故障"的指标，正常为 0。
    格式为 名称:值，多项之间用分号分隔。

  1) 网卡错误计数器（非 0 才出现）
       信号质量   rx_crc_errors / rx_symbol_errors / rx_phy_errors / tx_phy_errors
       帧结构     rx_frame_errors / rx_alignment_errors
       发送异常   tx_carrier_errors / tx_aborted_errors / tx_window_errors /
                  tx_heartbeat_errors
       汇总       rx_errors / tx_errors / rx_mac_errors / tx_mac_errors
       其他       collisions / tx_timeout / rx_nohandler

  2) 链路
       carrier_changes:N       链路翻转累计次数，是介质劣化最灵敏的指标。
                               输出条件是换算成"次/天"后超过 10 次/天；
                               读不到系统运行时间时，改为累计超过 300 次
                               才输出。
       uptime_days:N           系统运行天数，用于复核上面的翻转速率。
       link_down:1             当前未检测到链路，且该口曾经通过流量。
       link_prev_rx_bytes:N    判定"曾经通过流量"时的接收字节数
       link_prev_tx_bytes:N    判定"曾经通过流量"时的发送字节数
       link_prev_cc:N          该口历史上的链路翻转次数
       ★ 从未通过流量的空闲口不会输出 link_down，以免干扰真正掉线的
         端口。链路已建立时也不会输出。
         计数器会在驱动重新加载或系统重启后清零，届时"曾经用过"的
         历史会丢失，需结合 uptime_days 判断。

  3) PCIe 总线
       pcie_aer_corr:N         PCIe 可纠正错误
       pcie_aer_nonfatal:N     PCIe 非致命错误
       pcie_aer_fatal:N        PCIe 致命错误
       ★ 典型成因是坏插槽、转接卡或金手指氧化，症状是偶发丢包与性能
         抖动，而网卡自身的错误计数器往往全为 0。

  4) 光模块
       optics_rx_low:1         接收光功率偏低，预示模块或光纤劣化。
       optics_rx_dbm:-11.30    实测接收光功率 (dBm)，附在上一条之后。
                               判据用模块自带 DDM 门限（Rx 低预警，其次
                               低告警）；模块未公布门限时才按模块类型取
                               接收灵敏度标准值兜底。
                               只在链路已建立时才判 —— 链路未建立时对端
                               不发光，收不到光是必然结果而非故障。光纤
                               断裂导致链路中断的场景由 link_down 覆盖。
       optics_mismatch_1:1     模块型号 (PN) 两侧读取不一致
       optics_mismatch_3:1     模块序列号 (SN) 两侧读取不一致
       optics_mismatch_0:1     厂商名不一致（且型号或序列号也不一致）
       optics_temp_mismatch:A/B          两侧温度相差超过 3 °C
       optics_power_mismatch_4:A/B       发射光功率两侧相差超过 3 dB
       optics_power_mismatch_5:A/B       接收光功率两侧相差超过 3 dB
                               4 = 发射，5 = 接收；A、B 是两个来源各自
                               读到的原值 (mW)，一并输出便于现场复核。
                               仅当两侧都给出有效值时才比较。
       ddm_alarm:<标志名>      模块自身置位的告警或预警标志，例如
                               ddm_alarm:rx_power_low_warning。
                               门限由模块厂商确定、越界由模块硬件判定，
                               是最可靠的判据；正常模块不输出本项。

       ★ "两侧"指本工具的两个数据来源互相核对。PN 与 SN 是模块的身份
         锚点（逐型号、逐序列号唯一），二者一致即说明读的是同一个物理
         模块；此时厂商名若不同，属正常的排版差异，不视为异常。
         型号或序列号不一致则说明模块页读取异常 —— 可能是模块将坏、
         接触不良或读取串扰，值得现场确认。

不收录（病因不属于硬件，收录会误导排查方向）:
    rx_missed_errors / rx_fifo_errors / rx_over_errors
        主机侧 CPU、中断或 ring 配置不足
    rx_long_length_errors / rx_oversize_pkts_phy / rx_undersize_pkts_phy /
    rx_jabbers_phy
        帧长超出允许范围 → MTU 或隧道配置、或对端问题，不是网卡劣化
    rx_csum_offload_errors
        坏校验和由发送方产生
    dropped / discard 类
        拥塞。需要临时查看时用 --include-drops。

    表征物理层比特错误的 rx_frame_errors / rx_alignment_errors 仍然收录。
EOF
    return 0
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)        show_help; exit 0 ;;
            -d|--debug)       DEBUG="true"; shift ;;
            -o|--output)
                # ★★ 必须先确认 $2 存在，否则脚本会【死循环】★★
                #
                # 原写法是 `OUTPUT_DIR="$2"; shift 2`，两个问题叠在一起：
                #   1) 无 set -u 时 "$2" 越界取到的是空串，不报错；
                #   2) shift 2 在 $# 只有 1 时会【失败】。
                # 关键在 (2)：POSIX/bash 里 shift 越界的语义是
                #       bash: shift: 2: shift count out of range
                #       → 返回 1，且【位置参数原封不动】。
                # 于是 $1 仍是 "-o"、$# 仍是 1，
                #     while [[ $# -gt 0 ]]  恒为真 → 无限空转。
                #
                # 即 `bash collect_nic_v2.sh -s` 或 `-o` 会【静默挂死】：
                # 不打印任何东西、不报错、也永远走不到 main()。
                # 这比崩溃更糟 —— 崩溃有提示，挂死没有；包在 cron/ansible
                # 里会一直占着执行槽直到外部超时，而事后没有任何产物可查。
                #
                # 因此在消费 $2 之前先判空，缺参数就明确报错退出。
                if [[ -z "${2:-}" ]]; then
                    log_error "选项 $1 需要参数"
                    show_help
                    exit 1
                fi
                OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial)
                # 同理，先判 $2 存在（否则同上死循环）。
                if [[ -z "${2:-}" ]]; then
                    log_error "选项 $1 需要参数"
                    show_help
                    exit 1
                fi
                # 同时拒绝【故意传入的空串】：-s "" 会让 SERIAL_EXPLICIT
                # 变成 true，于是 main 跳过自动探测，最终每行第 1 列
                # （server_serial）都是空的。
                # get_system_serial() 自身有 "UNKNOWN" 兜底，绝不会返回空，
                # 所以空序列号只可能来自这里 —— 与其写出整表空序列号，
                # 不如当场报错。
                SYSTEM_SERIAL="$2"; SERIAL_EXPLICIT=true; shift 2 ;;
            --include-drops)  INCLUDE_DROPS="true"; shift ;;
            *) log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
    return 0
}

parse_args "$@"
main
exit $?
