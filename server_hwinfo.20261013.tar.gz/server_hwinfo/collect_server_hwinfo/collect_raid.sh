#!/bin/bash
# ============================================================================
# 服务器 RAID/HBA 控制器信息收集脚本（v3.4）
#
# 变更（对比 v3.3）：
#   - ★ 修复 Adaptec PD 计数正则 bug
#       旧：'Device is a[ n] +'  只匹配 "Device is an xxx"，不匹配 "Device is a xxx"
#       新：'Device is a(n)?[[:space:]]+'  同时匹配 "a xxx" 与 "an xxx"
#       修复后 HBA 模式下若 arcconf 管理了物理盘，raid_pd_count 输出真实数字
#
# v3.3 变更保留：
#   - 删除 GETCONFIG BIOS 调用（arcconf 无此子命令）
#   - Controller Serial Number 过滤字面 "Unknown"
#   - PD 段无真实物理盘时输出 N/A
#
# v3.2 变更保留：
#   - get_ctrl_type_from_class：HBA-SAS → HBA
#   - collect_all_ctrl_info：去掉 Adaptec 分支 ctrl_type="RAID" 强制覆盖
#
# v3.1 变更保留：
#   - Adaptec arcconf 正则按实际输出修正
#   - _bbu_is_ok 放行 "No Battery Connected" 等非故障状态
#   - Adaptec pcie_slot 用 arcconf Physical Slot 兜底
#
# v3.0 变更保留：
#   - is_fake_raid_like() 排除 PCIe Switch management endpoint
#   - raid_submodel（lspci -vv Subsystem 行）
#   - Broadcom/LSI 卡 storcli 未采到 → sas3flash 兜底
#   - pcie_slot 从 lspci Physical Slot 兜底
#   - 只采 RAID/HBA，不采 NVMe
#
# 建议以 root 运行：sudo ./collect_raid.sh
# ============================================================================

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
SYSTEM_SERIAL=""
DEBUG="${DEBUG:-false}"

if [[ "$(id -u)" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2 || true; }

print_separator() { echo "========================================="; }

# ============================================================================
# 基础工具
# ============================================================================

_trim() {
    local v="$1"
    v="${v#"${v%%[![:space:]]*}"}"
    v="${v%"${v##*[![:space:]]}"}"
    printf '%s' "$v"
}

csv_escape() {
    local f="$1"
    [[ -z "$f" ]] && { printf ''; return; }
    if [[ "$f" == *","* || "$f" == *"\""* || "$f" == *$'\n'* ]]; then
        f=${f//\"/\"\"}
        printf '"%s"' "$f"
    else
        printf '%s' "$f"
    fi
}

output_row() {
    local out="" f
    for f in "$@"; do
        out+="$(csv_escape "$f"),"
    done
    printf '%s\n' "${out%,}"
}

_build_errors() {
    local -a parts=("$@")
    if [[ ${#parts[@]} -eq 0 ]]; then
        echo "0"
    else
        local IFS=';'
        echo "${parts[*]}"
    fi
}

_zero_if_empty() {
    local v="$1"
    [[ -z "$v" ]] && echo "0" || echo "$v"
}

_bbu_is_ok() {
    case "$1" in
        ""|"NA"|"N/A"|"na"|"n/a"|"Optimal"|"Present"|"OK"|"Ok"|"ok"|\
        "Absent"|"absent"|"-"|"None"|"none"|\
        "No Battery Connected"|"Not Present"|"Not Installed"|"Not Configured"|\
        "Not Applicable")
            return 0 ;;
        *) return 1 ;;
    esac
}

normalize_pci_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    if [[ "$a" =~ ^([0-9a-f]+):([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        local domain=$((16#${BASH_REMATCH[1]}))
        printf "%04x:%s:%s.%s" "$domain" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        return
    fi
    if [[ "$a" =~ ^([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        printf "0000:%s:%s.%s" "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}"
        return
    fi
    echo "$a"
}

# ============================================================================
# PCIe 派生信息
# ============================================================================

declare -A LSPCI_LNK_CACHE=()

_get_lspci_lnk_info() {
    local a="$1"
    [[ -z "$a" || "$a" == "Unknown" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$a")
    [[ -n "${LSPCI_LNK_CACHE[$key]+x}" ]] && { echo "${LSPCI_LNK_CACHE[$key]}"; return; }
    local info
    info=$(lspci -s "$key" -vv 2>/dev/null || true)
    LSPCI_LNK_CACHE["$key"]="$info"
    echo "$info"
}

gtps_to_pcie_ver() {
    case "$1" in
        "2.5GT/s") echo "PCIe 1.0" ;; "5GT/s")  echo "PCIe 2.0" ;;
        "8GT/s")   echo "PCIe 3.0" ;; "16GT/s") echo "PCIe 4.0" ;;
        "32GT/s")  echo "PCIe 5.0" ;; "64GT/s") echo "PCIe 6.0" ;;
        *)         echo "" ;;
    esac
}

get_pcie_gen() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_lnk_info "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap; cap=$(echo "$info" | grep -E "LnkCap:" | head -1 \
        | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$cap" ]] && cap=$(echo "$info" | grep -E "LnkSta:" | head -1 \
        | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$cap" ]] && { echo "N/A"; return; }
    local v; v=$(gtps_to_pcie_ver "$cap")
    [[ -z "$v" ]] && { echo "N/A"; return; }
    echo "$v"
}

get_pcie_link_cap() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_lnk_info "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap_line speed width
    cap_line=$(echo "$info" | grep -E "LnkCap:" | head -1)
    speed=$(echo "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    width=$(echo "$cap_line" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    if   [[ -n "$speed" && -n "$width" ]]; then echo "${speed} ${width}"
    elif [[ -n "$speed" ]]; then echo "$speed"
    elif [[ -n "$width" ]]; then echo "$width"
    else echo "N/A"; fi
}

get_pcie_link_sta() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_lnk_info "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local sta s ss w ws
    sta=$(echo "$info" | grep -E "LnkSta:" | head -1)
    s=$(echo "$sta" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    ss=$(echo "$sta" | grep -oE 'Speed [0-9.]+GT/s \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$ss" ]] && ss="ok"
    w=$(echo "$sta" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    ws=$(echo "$sta" | grep -oE 'Width x[0-9]+ \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$ws" ]] && ws="ok"
    local sstr="" wstr=""
    [[ -n "$s" ]] && sstr="${s} (${ss})"
    [[ -n "$w" ]] && wstr="${w} (${ws})"
    if   [[ -n "$sstr" && -n "$wstr" ]]; then echo "$sstr $wstr"
    elif [[ -n "$sstr" ]]; then echo "$sstr"
    elif [[ -n "$wstr" ]]; then echo "$wstr"
    else echo "N/A"; fi
}

get_pcie_vid() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local k; k=$(normalize_pci_addr "$a")
    local f="/sys/bus/pci/devices/$k/vendor"
    if [[ -f "$f" ]]; then
        local v; v=$(cat "$f" 2>/dev/null); v="${v#0x}"
        [[ -n "$v" ]] && { echo "$v"; return; }
    fi
    echo "N/A"
}

get_pcie_pid() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local k; k=$(normalize_pci_addr "$a")
    local f="/sys/bus/pci/devices/$k/device"
    if [[ -f "$f" ]]; then
        local v; v=$(cat "$f" 2>/dev/null); v="${v#0x}"
        [[ -n "$v" ]] && { echo "$v"; return; }
    fi
    echo "N/A"
}

get_pcie_subsystem_id() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local k; k=$(normalize_pci_addr "$a")
    local sv sd
    [[ -f "/sys/bus/pci/devices/$k/subsystem_vendor" ]] && sv=$(cat "/sys/bus/pci/devices/$k/subsystem_vendor" 2>/dev/null | sed 's/^0x//')
    [[ -f "/sys/bus/pci/devices/$k/subsystem_device" ]] && sd=$(cat "/sys/bus/pci/devices/$k/subsystem_device" 2>/dev/null | sed 's/^0x//')
    if [[ -n "$sv" && -n "$sd" ]]; then
        echo "${sv}:${sd}"
    else
        echo "N/A"
    fi
}

get_ctrl_submodel_from_lspci() {
    local busid="$1" line
    [[ -z "$busid" ]] && { echo ""; return; }
    line=$(lspci -s "$busid" -vv 2>/dev/null \
        | grep -m1 -E '^[[:space:]]+Subsystem:' \
        | sed 's/.*Subsystem:[[:space:]]*//')
    printf '%s' "$line"
}

# ============================================================================
# PCIe slot
# ============================================================================

declare -A PCI_SLOT_MAP=()
declare -A PCIE_SLOT_CACHE=()
PCI_SLOT_MAP_LOADED=false

_normalize_dmi_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    [[ "$a" =~ ^([0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2})$ ]] && a="${a}.0"
    [[ "$a" =~ ^([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]] && a="0000:$a"
    echo "$a"
}

load_pci_slot_map() {
    [[ "$PCI_SLOT_MAP_LOADED" == "true" ]] && return
    PCI_SLOT_MAP_LOADED=true

    log_debug "加载 dmidecode -t slot..."
    local cur="" line
    while IFS= read -r line; do
        if [[ "$line" =~ Designation:[[:space:]]*(.+) ]]; then
            cur=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ "$line" =~ Bus[[:space:]]Address:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            local key; key=$(_normalize_dmi_addr "${BASH_REMATCH[1]}")
            [[ -n "$key" ]] && PCI_SLOT_MAP["$key"]="$cur"
        fi
    done < <($SUDO dmidecode -t slot 2>/dev/null)

    log_debug "PCI slot 表: ${#PCI_SLOT_MAP[@]} 条"
}

get_pcie_slot() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" ]] && { echo "N/A"; return; }

    if [[ -n "${PCIE_SLOT_CACHE[$bdf]+x}" ]]; then
        echo "${PCIE_SLOT_CACHE[$bdf]}"; return
    fi

    bdf=$(echo "$bdf" | tr 'A-F' 'a-f')
    [[ "$bdf" =~ ^[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]] && bdf="0000:$bdf"

    local realpath; realpath=$(readlink -f "/sys/bus/pci/devices/$bdf" 2>/dev/null)
    if [[ -z "$realpath" ]]; then
        PCIE_SLOT_CACHE["$bdf"]="N/A"; echo "N/A"; return
    fi

    local chain; chain=$(echo "$realpath" | tr '/' '\n' \
        | grep -E '^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$' | tac)

    local p k bus kbus result="N/A"
    while IFS= read -r p; do
        [[ -n "${PCI_SLOT_MAP[$p]+x}" ]] && { result="${PCI_SLOT_MAP[$p]}"; break; }
    done <<< "$chain"

    if [[ "$result" == "N/A" ]]; then
        while IFS= read -r p; do
            bus=$(echo "$p" | cut -d':' -f2)
            for k in "${!PCI_SLOT_MAP[@]}"; do
                kbus=$(echo "$k" | cut -d':' -f2)
                if [[ "$bus" == "$kbus" ]]; then result="${PCI_SLOT_MAP[$k]}"; break 2; fi
            done
        done <<< "$chain"
    fi

    if [[ "$result" == "N/A" ]]; then
        local phys
        phys=$(lspci -s "$bdf" -vv 2>/dev/null \
            | grep -E "^[[:space:]]*Physical Slot:" | head -1 \
            | sed 's/.*Physical Slot:[[:space:]]*//')
        [[ -n "$phys" ]] && result="PhysicalSlot:${phys}"
    fi

    PCIE_SLOT_CACHE["$bdf"]="$result"
    echo "$result"
}

# ============================================================================
# 工具发现
# ============================================================================

_find_tool() {
    local c
    for c in "$@"; do
        command -v "$c" &>/dev/null && { echo "$c"; return 0; }
        [[ -x "$c" ]] && { echo "$c"; return 0; }
    done
    echo ""
}

_find_storcli() {
    _find_tool storcli storcli64 \
        /opt/MegaRAID/storcli/storcli64 /opt/MegaRAID/storcli/storcli
}

_find_perccli() {
    _find_tool perccli perccli64 \
        /opt/MegaRAID/perccli/perccli64 /opt/MegaRAID/perccli/perccli
}

_find_sas3flash() {
    _find_tool sas3flash /usr/local/bin/sas3flash
}

_find_sas2flash() {
    _find_tool sas2flash /usr/local/bin/sas2flash
}

_find_arcconf() {
    _find_tool arcconf /usr/StorMan/arcconf "${SCRIPT_DIR}/tool/arcconf"
}

_find_ssacli() {
    _find_tool ssacli hpssacli \
        /usr/sbin/ssacli /usr/sbin/hpssacli /sbin/ssacli /sbin/hpssacli
}

# ============================================================================
# 厂商映射
# ============================================================================

get_ctrl_vendor_from_vid() {
    case "$1" in
        1000) echo "Broadcom/LSI" ;;
        9005) echo "Adaptec" ;;
        103c) echo "HPE" ;;
        1028) echo "Dell" ;;
        8086) echo "Intel" ;;
        14e4) echo "Broadcom" ;;
        *) echo "UNKNOWN" ;;
    esac
}

get_ctrl_model_from_lspci() {
    local busid="$1" line
    line=$(lspci -s "$busid" 2>/dev/null | head -1)
    [[ -z "$line" ]] && { echo "UNKNOWN"; return; }
    echo "$line" | sed 's/^[0-9a-fA-F:.]*[[:space:]]*[^:]*:[[:space:]]*//'
}

get_ctrl_type_from_class() {
    local k; k=$(normalize_pci_addr "$1")
    local cls
    cls=$(cat "/sys/bus/pci/devices/$k/class" 2>/dev/null | tr -d ' \n')
    case "$cls" in
        0x0104*) echo "RAID" ;;
        0x0107*) echo "HBA" ;;
        0x0106*) echo "HBA-SATA" ;;
        *)       echo "Unknown" ;;
    esac
}

# ============================================================================
# Broadcom/LSI MegaRAID（storcli）
# ============================================================================

MRAID_MODEL=""
MRAID_SERIAL=""
MRAID_FW=""
MRAID_BIOS=""
MRAID_CACHE=""
MRAID_STATE=""
MRAID_RAID=""
MRAID_BBU=""
MRAID_VDS=""
MRAID_PDS=""
MRAID_MEM_CE=""
MRAID_MEM_UE=""

_reset_megaraid_vars() {
    MRAID_MODEL=""; MRAID_SERIAL=""; MRAID_FW=""; MRAID_BIOS=""
    MRAID_CACHE=""; MRAID_STATE=""; MRAID_RAID=""
    MRAID_BBU=""; MRAID_VDS=""; MRAID_PDS=""
    MRAID_MEM_CE=""; MRAID_MEM_UE=""
}

collect_megaraid_info() {
    local storcli="$1" ctrl_idx="$2"
    _reset_megaraid_vars

    local json
    json=$($SUDO "$storcli" /c${ctrl_idx} show all J 2>/dev/null)
    [[ -z "$json" ]] && return 1

    local line v
    while IFS= read -r line; do
        if [[ -z "$MRAID_MODEL" ]] && [[ "$line" =~ \"Model\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_MODEL=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_SERIAL" ]] && [[ "$line" =~ \"Serial\ Number\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_SERIAL=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_FW" ]] && [[ "$line" =~ \"Firmware\ Version\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_FW=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_FW" ]] && [[ "$line" =~ \"FW\ Version\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_FW=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_BIOS" ]] && [[ "$line" =~ \"[Bb][Ii][Oo][Ss]\ Version\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_BIOS=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_CACHE" ]] && [[ "$line" =~ \"On\ Board\ Memory\ Size\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            v=$(_trim "${BASH_REMATCH[1]}")
            MRAID_CACHE=$(echo "$v" | grep -oE '^[0-9]+' || echo "$v")
        fi
        if [[ -z "$MRAID_CACHE" ]] && [[ "$line" =~ \"Memory\ Size\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            v=$(_trim "${BASH_REMATCH[1]}")
            MRAID_CACHE=$(echo "$v" | grep -oE '^[0-9]+' || echo "$v")
        fi
        if [[ -z "$MRAID_STATE" ]] && [[ "$line" =~ \"Controller\ Status\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_STATE=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_RAID" ]] && [[ "$line" =~ \"RAID\ Level\ Supported\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_RAID=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_BBU" ]] && [[ "$line" =~ \"BBU\"[[:space:]]*:[[:space:]]*\"([^\"]+)\" ]]; then
            MRAID_BBU=$(_trim "${BASH_REMATCH[1]}")
        fi
        if [[ -z "$MRAID_MEM_CE" ]] && [[ "$line" =~ \"Memory\ Correctable\ Errors\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then
            MRAID_MEM_CE="${BASH_REMATCH[1]}"
        fi
        if [[ -z "$MRAID_MEM_UE" ]] && [[ "$line" =~ \"Memory\ Uncorrectable\ Errors\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then
            MRAID_MEM_UE="${BASH_REMATCH[1]}"
        fi
        if [[ -z "$MRAID_VDS" ]] && [[ "$line" =~ \"Virtual\ Drives\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then
            MRAID_VDS="${BASH_REMATCH[1]}"
        fi
        if [[ -z "$MRAID_PDS" ]] && [[ "$line" =~ \"Physical\ Drives\"[[:space:]]*:[[:space:]]*([0-9]+) ]]; then
            MRAID_PDS="${BASH_REMATCH[1]}"
        fi
    done <<< "$json"

    local cv_state
    cv_state=$(echo "$json" | awk '
        /"Cachevault_Info"/ { f=1 }
        f && /"State"/ {
            line=$0
            sub(/.*"State"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*/, "", line)
            print line
            exit
        }
    ')
    [[ -n "$cv_state" ]] && MRAID_BBU="$cv_state"

    [[ -z "$MRAID_MEM_CE" ]] && MRAID_MEM_CE="0"
    [[ -z "$MRAID_MEM_UE" ]] && MRAID_MEM_UE="0"

    return 0
}

# ============================================================================
# Broadcom/LSI SAS HBA（sas3flash）
# ============================================================================

collect_lsi_hba_info() {
    local sasflash="$1" ctrl_idx="$2"
    _reset_megaraid_vars

    local out
    out=$($SUDO "$sasflash" -c "$ctrl_idx" -list 2>/dev/null)
    if [[ -z "$out" ]]; then
        out=$($SUDO "$sasflash" -list 2>/dev/null)
    fi
    [[ -z "$out" ]] && return 1

    local line
    while IFS= read -r line; do
        [[ "$line" =~ ^Controller[[:space:]]*:[[:space:]]*(.+)$ ]] && MRAID_MODEL="$(_trim "${BASH_REMATCH[1]}")"
        [[ "$line" =~ ^SAS[[:space:]]Address[[:space:]]*:[[:space:]]*(.+)$ ]] && MRAID_SERIAL="$(_trim "${BASH_REMATCH[1]}")"
        [[ "$line" =~ ^Firmware[[:space:]]Version[[:space:]]*:[[:space:]]*(.+)$ ]] && MRAID_FW="$(_trim "${BASH_REMATCH[1]}")"
        [[ "$line" =~ ^BIOS[[:space:]]Version[[:space:]]*:[[:space:]]*(.*)$ ]] && MRAID_BIOS="$(_trim "${BASH_REMATCH[1]}")"
    done <<< "$out"

    MRAID_STATE="Optimal"
    MRAID_MEM_CE="0"
    MRAID_MEM_UE="0"
    return 0
}

# ============================================================================
# HPE Smart Array（ssacli）
# ============================================================================

HPE_SLOT=""
HPE_MODEL=""
HPE_SERIAL=""
HPE_FW=""
HPE_CACHE=""
HPE_STATE=""
HPE_BBU=""
HPE_VDS=""
HPE_PDS=""

_reset_hpe_vars() {
    HPE_SLOT=""; HPE_MODEL=""; HPE_SERIAL=""; HPE_FW=""
    HPE_CACHE=""; HPE_STATE=""; HPE_BBU=""; HPE_VDS=""; HPE_PDS=""
}

list_hpe_slots() {
    local ssacli="$1" out
    out=$($SUDO "$ssacli" ctrl all show 2>/dev/null)
    echo "$out" | awk '/Slot [0-9]+/ { match($0, /Slot [0-9]+/); print substr($0, RSTART+5, RLENGTH-5) }' | sort -un
}

collect_hpe_sa_info() {
    local ssacli="$1" slot="$2"
    _reset_hpe_vars
    HPE_SLOT="$slot"

    local out
    out=$($SUDO "$ssacli" ctrl slot="$slot" show detail 2>/dev/null)
    [[ -z "$out" ]] && return 1

    local line
    while IFS= read -r line; do
        line=$(_trim "$line")
        [[ "$line" =~ ^Product\ Name:\ *(.*)$ ]] && HPE_MODEL="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Serial\ Number:\ *(.*)$ ]] && HPE_SERIAL="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Firmware\ Version:\ *(.*)$ ]] && HPE_FW="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Cache\ Status:\ *(.*)$ ]] && HPE_CACHE="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Cache\ Board:\ *(.*)$ ]] && HPE_CACHE="$HPE_CACHE|${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Controller\ Status:\ *(.*)$ ]] && HPE_STATE="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Battery/Capacitor\ Status:\ *(.*)$ ]] && HPE_BBU="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Logical\ Drives:\ *([0-9]+) ]] && HPE_VDS="${BASH_REMATCH[1]}"
        [[ "$line" =~ ^Physical\ Drives:\ *([0-9]+) ]] && HPE_PDS="${BASH_REMATCH[1]}"
    done <<< "$out"

    return 0
}

# ============================================================================
# Adaptec（arcconf）
# ============================================================================

ADP_INDEX=""
ADP_MODEL=""
ADP_SERIAL=""
ADP_FW=""
ADP_BIOS=""
ADP_CACHE=""
ADP_STATE=""
ADP_BBU=""
ADP_VDS=""
ADP_PDS=""
ADP_SLOT=""

_reset_adaptec_vars() {
    ADP_INDEX=""; ADP_MODEL=""; ADP_SERIAL=""; ADP_FW=""
    ADP_BIOS=""; ADP_CACHE=""; ADP_STATE=""; ADP_BBU=""
    ADP_VDS=""; ADP_PDS=""; ADP_SLOT=""
}

# ★ v3.4：修复 PD 计数正则；serial 过滤 Unknown；BIOS 从 AD 段取
collect_adaptec_info() {
    local arcconf="$1" idx="$2"
    _reset_adaptec_vars
    ADP_INDEX="$idx"

    local out
    out=$($SUDO "$arcconf" GETCONFIG "$idx" AD 2>/dev/null)
    [[ -z "$out" ]] && return 1

    local line tmp_serial
    while IFS= read -r line; do
        line=$(_trim "$line")

        # 型号
        [[ "$line" =~ ^Controller\ Model[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_MODEL="${BASH_REMATCH[1]}"

        # serial 多字段 + 过滤字面 "Unknown"
        tmp_serial=""
        [[ "$line" =~ ^Controller\ Serial\ Number[[:space:]]*:[[:space:]]*(.*)$ ]] && tmp_serial="${BASH_REMATCH[1]}"
        [[ -z "$tmp_serial" && "$line" =~ ^Serial\ Number[[:space:]]*:[[:space:]]*(.*)$ ]] && tmp_serial="${BASH_REMATCH[1]}"
        [[ -z "$tmp_serial" && "$line" =~ ^Serial[[:space:]]*:[[:space:]]*(.*)$ ]] && tmp_serial="${BASH_REMATCH[1]}"
        tmp_serial=$(_trim "$tmp_serial")
        if [[ -n "$tmp_serial" && "$tmp_serial" != "Unknown" && "$tmp_serial" != "N/A" && "$tmp_serial" != "None" ]]; then
            ADP_SERIAL="$tmp_serial"
        fi

        # 固件
        [[ "$line" =~ ^Firmware[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_FW="${BASH_REMATCH[1]}"

        # BIOS（SmartHBA 一般没有，保留以防万一）
        [[ -z "$ADP_BIOS" && "$line" =~ ^BIOS[[:space:]]+Version[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_BIOS="${BASH_REMATCH[1]}"
        [[ -z "$ADP_BIOS" && "$line" =~ ^BIOS[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_BIOS="${BASH_REMATCH[1]}"

        # 缓存
        [[ "$line" =~ ^Cache\ memory[[:space:]]*:[[:space:]]*(.*)$ ]] && {
            local cv="${BASH_REMATCH[1]}"
            ADP_CACHE=$(echo "$cv" | grep -oE '^[0-9]+' || echo "$cv")
        }

        # 控制器状态
        [[ "$line" =~ ^Controller\ Status[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_STATE="${BASH_REMATCH[1]}"

        # 备份电源
        [[ "$line" =~ ^Backup\ Power\ Status[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_BBU="${BASH_REMATCH[1]}"

        # 逻辑盘
        [[ "$line" =~ ^Logical\ devices/Failed/Degraded[[:space:]]*:[[:space:]]*([0-9]+)/ ]] \
            && ADP_VDS="${BASH_REMATCH[1]}"

        # 物理槽位
        [[ "$line" =~ ^Physical\ Slot[[:space:]]*:[[:space:]]*(.*)$ ]] \
            && ADP_SLOT="${BASH_REMATCH[1]}"
    done <<< "$out"

    [[ -z "$ADP_MODEL" ]] && return 1

    # serial 兜底：lspci [SN]
    if [[ -z "$ADP_SERIAL" ]]; then
        local busid lspci_sn
        busid=$(lspci -D 2>/dev/null | awk '/\[9005:/{print $1; exit}')
        if [[ -n "$busid" ]]; then
            lspci_sn=$(lspci -s "$busid" -vv 2>/dev/null \
                | grep -i '\[SN\]' | head -1 \
                | sed 's/.*\[SN\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            if [[ -n "$lspci_sn" && "$lspci_sn" != "Unknown" ]]; then
                ADP_SERIAL="$lspci_sn"
                log_debug "  Adaptec serial 从 lspci [SN] 获得: $ADP_SERIAL"
            fi
        fi
    fi

    # ★ v3.4：PD 计数 —— 修复正则 bug
    #   旧：'Device is a[ n] +' 只匹配 "an xxx"，不匹配 "a xxx"
    #   新：'Device is a(n)?[[:space:]]+' 同时匹配两种
    local pd_out
    pd_out=$($SUDO "$arcconf" GETCONFIG "$idx" PD 2>/dev/null)
    if [[ -n "$pd_out" ]]; then
        local real_pd_count
        real_pd_count=$(echo "$pd_out" \
            | grep -E 'Device is a(n)?[[:space:]]+' \
            | grep -viE 'Enclosure|Expander|Virtual|SES' \
            | wc -l)
        real_pd_count=$(_trim "$real_pd_count")
        if [[ "$real_pd_count" =~ ^[0-9]+$ && "$real_pd_count" -gt 0 ]]; then
            ADP_PDS="$real_pd_count"
            log_debug "  Adaptec 物理盘计数: $ADP_PDS"
        else
            # arcconf 视角没有真实物理盘（HBA 模式只有 Enclosure）
            ADP_PDS="N/A"
            log_debug "  Adaptec 视角无物理盘 → N/A"
        fi
    else
        ADP_PDS="N/A"
    fi

    return 0
}

list_adaptec_ctrls() {
    local arcconf="$1" out
    out=$($SUDO "$arcconf" LIST 2>/dev/null)
    echo "$out" | awk '
        match($0, /Controller[[:space:]]+[0-9]+[[:space:]]*:/) {
            s = substr($0, RSTART, RLENGTH)
            gsub(/[^0-9]/, "", s)
            print s
        }'
}

# ============================================================================
# 伪 RAID 排除
# ============================================================================

is_fake_raid_like() {
    local busid="$1"
    [[ -z "$busid" ]] && return 1

    local desc
    desc=$(lspci -s "$busid" 2>/dev/null | head -1)
    case "$desc" in
        *"PCIe Switch management endpoint"*)
            log_debug "排除伪 RAID（描述命中 PCIe Switch mgmt ep）: $busid | $desc"
            return 0 ;;
    esac

    local vid pid
    vid=$(get_pcie_vid "$busid")
    pid=$(get_pcie_pid "$busid")
    vid=$(echo "$vid" | tr 'A-F' 'a-f')
    pid=$(echo "$pid" | tr 'A-F' 'a-f')

    if [[ "$vid" == "1000" ]]; then
        case "$pid" in
            c010|c011|c012|c013)
                log_debug "排除伪 RAID（PID 黑名单 $vid:$pid）: $busid"
                return 0 ;;
        esac
    fi

    return 1
}

# ============================================================================
# 主收集
# ============================================================================

is_interesting_ctrl() {
    local busid="$1"

    is_fake_raid_like "$busid" && return 1

    local type; type=$(get_ctrl_type_from_class "$busid")
    case "$type" in
        RAID|HBA|HBA-SATA) return 0 ;;
        *) return 1 ;;
    esac
}

collect_all_ctrl_info() {
    local serial="$1" output_file="$2"

    load_pci_slot_map

    local storcli perccli sas3flash sas2flash arcconf ssacli
    storcli=$(_find_storcli)
    perccli=$(_find_perccli)
    sas3flash=$(_find_sas3flash)
    sas2flash=$(_find_sas2flash)
    arcconf=$(_find_arcconf)
    ssacli=$(_find_ssacli)

    log_debug "storcli=$storcli"
    log_debug "perccli=$perccli"
    log_debug "sas3flash=$sas3flash"
    log_debug "sas2flash=$sas2flash"
    log_debug "arcconf=$arcconf"
    log_debug "ssacli=$ssacli"

    local megaraid_cmd="$storcli"
    [[ -z "$megaraid_cmd" ]] && megaraid_cmd="$perccli"

    declare -A MRAID_BY_PCI=()
    if [[ -n "$megaraid_cmd" ]]; then
        local i
        for i in $(seq 0 15); do
            local show
            show=$($SUDO "$megaraid_cmd" /c${i} show J 2>/dev/null)
            [[ -z "$show" ]] && continue
            echo "$show" | grep -q '"Bus Number"' || continue

            local bn dn fn
            bn=$(echo "$show" | grep '"Bus Number"' | head -1 | awk -F: '{print $2}' | tr -d ' ,')
            dn=$(echo "$show" | grep '"Device Number"' | head -1 | awk -F: '{print $2}' | tr -d ' ,')
            fn=$(echo "$show" | grep '"Function Number"' | head -1 | awk -F: '{print $2}' | tr -d ' ,')

            if [[ -n "$bn" && -n "$dn" && -n "$fn" ]]; then
                local pci
                pci=$(printf "%04x:%02x:%02x.%x" 0 "$bn" "$dn" "$fn")
                MRAID_BY_PCI["$i"]="$pci"
                log_debug "MegaRAID c${i} → $pci"
            fi
        done
    fi

    declare -A MRAID_DETAIL_LOADED=()
    if [[ -n "$megaraid_cmd" ]]; then
        local i
        for i in "${!MRAID_BY_PCI[@]}"; do
            local pci="${MRAID_BY_PCI[$i]}"
            MRAID_DETAIL_LOADED["$pci"]="$i"
        done
    fi

    local busids
    busids=$(lspci -D 2>/dev/null | grep -iE \
        "RAID bus controller|Serial Attached SCSI controller" \
        | awk '{print $1}' | sort)

    local idx=0
    local busid
    for busid in $busids; do
        if ! is_interesting_ctrl "$busid"; then
            log_debug "跳过非 RAID/HBA 控制器: $busid"
            continue
        fi

        local key; key=$(normalize_pci_addr "$busid")
        local vid pid subsys ctrl_type vendor model submodel
        vid=$(get_pcie_vid "$busid")
        pid=$(get_pcie_pid "$busid")
        subsys=$(get_pcie_subsystem_id "$busid")
        ctrl_type=$(get_ctrl_type_from_class "$busid")
        vendor=$(get_ctrl_vendor_from_vid "$vid")
        model=$(get_ctrl_model_from_lspci "$busid")
        submodel=$(get_ctrl_submodel_from_lspci "$busid")

        local pcie_gen pcie_cap pcie_sta
        pcie_gen=$(get_pcie_gen "$busid")
        pcie_cap=$(get_pcie_link_cap "$busid")
        pcie_sta=$(get_pcie_link_sta "$busid")

        local pcie_slot; pcie_slot=$(get_pcie_slot "$key")

        local fw="" bios="" cache="" bbu_state="" raid_levels=""
        local vd_count="0" pd_count="" ctrl_state=""
        local -a err_parts=()

        if [[ -n "${MRAID_DETAIL_LOADED[$key]+x}" ]]; then
            local i="${MRAID_DETAIL_LOADED[$key]}"
            collect_megaraid_info "$megaraid_cmd" "$i"
            [[ -n "$MRAID_MODEL" ]] && model="$MRAID_MODEL"
            fw="$MRAID_FW"
            bios="$MRAID_BIOS"
            cache="$MRAID_CACHE"
            ctrl_state="$MRAID_STATE"
            raid_levels="$MRAID_RAID"
            bbu_state="$MRAID_BBU"
            vd_count=$(_zero_if_empty "$MRAID_VDS")
            pd_count="$MRAID_PDS"

            [[ -n "$ctrl_state" && "$ctrl_state" != "Optimal" ]] \
                && err_parts+=("Controller Status:${ctrl_state}")
            if ! _bbu_is_ok "$bbu_state"; then
                err_parts+=("Cachevault_Info State:${bbu_state}")
            fi
            [[ -n "$MRAID_MEM_CE" && "$MRAID_MEM_CE" != "0" ]] \
                && err_parts+=("Memory Correctable Errors:${MRAID_MEM_CE}")
            [[ -n "$MRAID_MEM_UE" && "$MRAID_MEM_UE" != "0" ]] \
                && err_parts+=("Memory Uncorrectable Errors:${MRAID_MEM_UE}")

            local errors; errors=$(_build_errors "${err_parts[@]}")

            output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$model" "$submodel" "$MRAID_SERIAL" \
                       "$fw" "$bios" "$busid" "$pcie_slot" \
                       "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                       "$raid_levels" "$vd_count" "$pd_count" \
                       "$ctrl_state" "$cache" "$bbu_state" \
                       "$errors" >> "$output_file"
            log_info "✓ [$idx] $ctrl_type $vendor $model [$submodel] @ $busid (state=$ctrl_state, bbu=$bbu_state, cache=${cache}MB, fw=$fw, errors=$errors)"
        elif [[ -n "$ssacli" ]] && [[ "$vendor" == "HPE" ]]; then
            local slots; slots=$(list_hpe_slots "$ssacli")
            local matched=false
            local slot
            for slot in $slots; do
                collect_hpe_sa_info "$ssacli" "$slot"
                if [[ -n "$HPE_MODEL" ]]; then
                    matched=true
                    local ctrl_state_str="$HPE_STATE"
                    local -a hpe_err=()
                    [[ -n "$ctrl_state_str" && "$ctrl_state_str" != "OK" ]] \
                        && hpe_err+=("Controller Status:${ctrl_state_str}")
                    if ! _bbu_is_ok "$HPE_BBU"; then
                        hpe_err+=("Battery/Capacitor Status:${HPE_BBU}")
                    fi
                    local errors; errors=$(_build_errors "${hpe_err[@]}")
                    local hpe_vd; hpe_vd=$(_zero_if_empty "$HPE_VDS")

                    output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$HPE_MODEL" "$submodel" "$HPE_SERIAL" \
                               "$HPE_FW" "" "$busid" "$pcie_slot" \
                               "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                               "" "$hpe_vd" "$HPE_PDS" \
                               "$ctrl_state_str" "$HPE_CACHE" "$HPE_BBU" \
                               "$errors" >> "$output_file"
                    log_info "✓ [$idx] $ctrl_type $vendor $HPE_MODEL [$submodel] @ $busid"
                    break
                fi
            done
            if [[ "$matched" == "false" ]]; then
                output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$model" "$submodel" "" \
                           "" "" "$busid" "$pcie_slot" \
                           "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                           "" "$vd_count" "$pd_count" "" "" "" "0" >> "$output_file"
                log_info "✓ [$idx] $ctrl_type $vendor $model [$submodel] @ $busid (lspci-only)"
            fi
        elif [[ -n "$arcconf" ]] && [[ "$vendor" == "Adaptec" ]]; then
            local ctrls; ctrls=$(list_adaptec_ctrls "$arcconf")
            local c
            local matched=false
            for c in $ctrls; do
                collect_adaptec_info "$arcconf" "$c"
                if [[ -n "$ADP_MODEL" ]]; then
                    matched=true

                    # pcie_slot 用 arcconf Physical Slot 兜底
                    if [[ -z "$pcie_slot" || "$pcie_slot" == "N/A" ]] && [[ -n "$ADP_SLOT" ]]; then
                        pcie_slot="Slot ${ADP_SLOT}"
                    fi

                    local -a adp_err=()
                    [[ -n "$ADP_STATE" && "$ADP_STATE" != "Optimal" ]] \
                        && adp_err+=("Controller Status:${ADP_STATE}")
                    if ! _bbu_is_ok "$ADP_BBU"; then
                        adp_err+=("Backup Power Status:${ADP_BBU}")
                    fi
                    local errors; errors=$(_build_errors "${adp_err[@]}")
                    local adp_vd; adp_vd=$(_zero_if_empty "$ADP_VDS")
                    # 保留 N/A 语义（HBA 模式下 arcconf 不管理物理盘）
                    local adp_pd="${ADP_PDS:-N/A}"

                    output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$ADP_MODEL" "$submodel" "$ADP_SERIAL" \
                               "$ADP_FW" "$ADP_BIOS" "$busid" "$pcie_slot" \
                               "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                               "" "$adp_vd" "$adp_pd" \
                               "$ADP_STATE" "$ADP_CACHE" "$ADP_BBU" \
                               "$errors" >> "$output_file"
                    log_info "✓ [$idx] $ctrl_type $vendor $ADP_MODEL [$submodel] @ $busid (state=$ADP_STATE, bbu=$ADP_BBU, cache=${ADP_CACHE}MB, fw=$ADP_FW, bios=$ADP_BIOS, vd=$adp_vd, pd=$adp_pd)"
                    break
                fi
            done
            if [[ "$matched" == "false" ]]; then
                output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$model" "$submodel" "" \
                           "" "" "$busid" "$pcie_slot" \
                           "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                           "" "$vd_count" "$pd_count" "" "" "" "0" >> "$output_file"
                log_info "✓ [$idx] $ctrl_type $vendor $model [$submodel] @ $busid (lspci-only)"
            fi
        elif [[ -n "$sas3flash" ]] && [[ "$vendor" == "Broadcom/LSI" ]]; then
            local matched=false
            local c
            for c in 0 1 2 3 4 5 6 7; do
                collect_lsi_hba_info "$sas3flash" "$c"
                if [[ -n "$MRAID_MODEL" ]]; then
                    matched=true
                    local -a hba_err=()
                    [[ -n "$MRAID_STATE" && "$MRAID_STATE" != "Optimal" ]] \
                        && hba_err+=("Controller Status:${MRAID_STATE}")
                    local errors; errors=$(_build_errors "${hba_err[@]}")

                    output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$MRAID_MODEL" "$submodel" "$MRAID_SERIAL" \
                               "$MRAID_FW" "$MRAID_BIOS" "$busid" "$pcie_slot" \
                               "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                               "" "$vd_count" "$pd_count" "$MRAID_STATE" "" "" \
                               "$errors" >> "$output_file"
                    log_info "✓ [$idx] $ctrl_type $vendor $MRAID_MODEL [$submodel] @ $busid (sas3flash, fw=$MRAID_FW)"
                    break
                fi
            done
            if [[ "$matched" == "false" ]]; then
                output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$model" "$submodel" "" \
                           "" "" "$busid" "$pcie_slot" \
                           "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                           "" "$vd_count" "$pd_count" "" "" "" "0" >> "$output_file"
                log_info "✓ [$idx] $ctrl_type $vendor $model [$submodel] @ $busid (lspci-only)"
            fi
        else
            output_row "$serial" "$idx" "$ctrl_type" "$vendor" "$model" "$submodel" "" \
                       "" "" "$busid" "$pcie_slot" \
                       "$vid" "$pid" "$subsys" "$pcie_gen" "$pcie_cap" "$pcie_sta" \
                       "" "$vd_count" "$pd_count" "" "" "" "0" >> "$output_file"
            log_info "✓ [$idx] $ctrl_type $vendor $model [$submodel] @ $busid (lspci-only)"
        fi

        idx=$((idx + 1))
    done
}

# ============================================================================
# 系统序列号
# ============================================================================

get_system_serial() {
    local s
    s=$($SUDO dmidecode -s system-serial-number 2>/dev/null | head -1)
    [[ -n "$s" && "$s" != "Not Specified" && "$s" != "Unknown" ]] && { echo "$s"; return; }
    [[ -f /sys/class/dmi/id/product_serial ]] && s=$($SUDO cat /sys/class/dmi/id/product_serial 2>/dev/null)
    [[ -n "$s" && "$s" != "Not Specified" ]] && { echo "$s"; return; }
    echo "UNKNOWN"
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_separator
    echo -e "${GREEN}服务器 RAID/HBA 控制器信息收集工具${NC}"
    print_separator

    if [[ "$(id -u)" -ne 0 ]]; then
        log_warn "非 root 运行，脚本内需要 root 的命令会调用 sudo"
        log_warn "建议用 sudo 运行以避免频繁输入密码: sudo $SCRIPT_NAME"
    fi

    SYSTEM_SERIAL=$(get_system_serial)
    log_info "系统序列号: $SYSTEM_SERIAL"

    if [[ "$SYSTEM_SERIAL" == "UNKNOWN" ]]; then
        OUTPUT_FILE="${OUTPUT_DIR}/raid_info.csv"
    else
        OUTPUT_FILE="${OUTPUT_DIR}/raid_info_${SYSTEM_SERIAL}.csv"
    fi

    [[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR" 2>/dev/null || { log_error "无法创建 $OUTPUT_DIR"; exit 1; }

    echo "server_serial,raid_index,raid_type,raid_vendor,raid_model,raid_submodel,raid_serial,raid_firmware,raid_bios_version,raid_pci_busid,pcie_slot,pcie_vendor_id,pcie_product_id,pcie_subsystem_id,pcie_gen,pcie_link_cap,pcie_link_sta,raid_raid_levels,raid_vd_count,raid_pd_count,raid_state,raid_cache_mb,raid_bbu_state,errors" > "$OUTPUT_FILE"

    collect_all_ctrl_info "$SYSTEM_SERIAL" "$OUTPUT_FILE"

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}"
    print_separator

    if [[ -f "$OUTPUT_FILE" ]]; then
        local n=$(($(wc -l < "$OUTPUT_FILE") - 1))
        echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}"
        echo -e "📊 控制器记录: ${BLUE}$n${NC} 条"
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    fi
}

# ============================================================================
# 帮助 & 参数
# ============================================================================

show_help() {
    cat << 'EOF'
服务器 RAID/HBA 控制器信息收集工具 (v3.4)

用法: sudo ./collect_raid.sh [选项]

选项:
    -h, --help          帮助
    -d, --debug         调试模式
    -o, --output DIR    输出目录 (默认: ./)
    -s, --serial SN     手动指定系统序列号

说明:
    - 只采集 RAID 控制器和 SAS HBA，不采集 NVMe / Intel VROC
    - 排除 PCIe Switch management endpoint（伪 SAS class）
    - raid_type 按 PCI class 显示：0x0104→RAID，0x0107→HBA
      （H460-B1 等 SmartHBA 显示为 HBA，不再强制标为 RAID）
    - raid_submodel 来自 lspci -vv 的 Subsystem 行
    - BBU/CV 状态 NA/N/A/Absent/-/None/No Battery Connected 不误报

输出列（24 列）:
    server_serial, raid_index, raid_type, raid_vendor, raid_model,
    raid_submodel, raid_serial, raid_firmware, raid_bios_version,
    raid_pci_busid, pcie_slot, pcie_vendor_id, pcie_product_id,
    pcie_subsystem_id, pcie_gen, pcie_link_cap, pcie_link_sta,
    raid_raid_levels, raid_vd_count, raid_pd_count,
    raid_state, raid_cache_mb, raid_bbu_state, errors

errors 字段格式:
    无错误  → 0
    有错误  → 原始字段名:值;原始字段名:值

排除规则:
    - lspci 描述含 "PCIe Switch management endpoint"
    - 设备 ID 黑名单: 1000:c010 / c011 / c012 / c013

Adaptec 采集说明 (v3.4):
    - arcconf GETCONFIG <id> AD   → 控制器信息
    - arcconf GETCONFIG <id> PD   → 物理盘计数
        正则 'Device is a(n)?[[:space:]]+' 匹配 "a xxx" 与 "an xxx"
        排除 Enclosure / Expander / Virtual / SES 等伪设备
        无真实物理盘时输出 N/A
    - 不调用 GETCONFIG BIOS（arcconf 无此子命令）
    - raid_serial：AD 段多字段（Controller Serial Number → Serial Number
                                  → Serial），过滤字面 "Unknown"，
                                  lspci [SN] 兜底，仍无则留空
    - raid_bios_version：AD 段若无则留空（SmartHBA 通常无 BIOS 字段）
    - 支持自动发现: PATH / /usr/StorMan/arcconf / <script_dir>/tool/arcconf

v3.4 变更:
    - 修复 Adaptec PD 计数正则 bug
      旧：'Device is a[ n] +'  只匹配 "an xxx"
      新：'Device is a(n)?[[:space:]]+'  同时匹配 "a xxx" 与 "an xxx"
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)   show_help; exit 0 ;;
            -d|--debug)  DEBUG="true"; shift ;;
            -o|--output) OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial) SYSTEM_SERIAL="$2"; shift 2 ;;
            *) log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
}

parse_args "$@"
main
