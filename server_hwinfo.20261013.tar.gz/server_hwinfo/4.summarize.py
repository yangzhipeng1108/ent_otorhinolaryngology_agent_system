#!/usr/bin/env python3
# ============================================================================
# 把 all_server_report/<host>/*.csv 按类别汇总为 *_summary.csv
#   - 使用 csv 模块，正确处理引号内的多行字段
#   - 输出时把字段内换行压成 "; "
#   - 表头不一致的文件会被跳过并报告
# 用法: ./summarize.py [SOURCE_DIR] [OUTPUT_DIR]
# ============================================================================
import csv, sys, os

SRC = sys.argv[1] if len(sys.argv) > 1 else './all_server_report'
OUT = sys.argv[2] if len(sys.argv) > 2 else './summary_hwinfo_report'

PREFIXES = [
    'cpu_info', 'memory_info', 'disk_info', 'nic_info', 'ib_info',
    'raid_info', 'gpu_info', 'psu_info', 'fan_info', 'server_info',
]

os.makedirs(OUT, exist_ok=True)

def flat(s):
    return s.replace('\r\n', '; ').replace('\n', '; ').replace('\r', '; ')

for prefix in PREFIXES:
    files = []
    for root, _, fnames in os.walk(SRC):
        for fn in fnames:
            if fn.startswith(prefix + '_') and fn.endswith('.csv'):
                files.append(os.path.join(root, fn))
    if not files:
        print(f"[WARN] 未找到 {prefix}_*.csv，跳过")
        continue

    # 用第一个文件的表头作为基准
    with open(files[0], 'r', encoding='utf-8', newline='') as f:
        base_header = next(csv.reader(f))
    base_key = tuple(base_header)

    rows_set = set()
    mismatched = 0
    for fp in files:
        with open(fp, 'r', encoding='utf-8', newline='') as f:
            reader = csv.reader(f)
            try:
                header = tuple(next(reader))
            except StopIteration:
                continue
            if header != base_key:
                mismatched += 1
                continue
            for row in reader:
                if not row or all(not c for c in row):
                    continue
                rows_set.add(tuple(flat(c) for c in row))

    out_path = os.path.join(OUT, f'{prefix}_summary.csv')
    with open(out_path, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL, lineterminator='\n')
        w.writerow(base_header)
        for row in sorted(rows_set):
            w.writerow(row)

    print(f"✅ {out_path}: {len(rows_set)} 条 (跳过表头不一致: {mismatched})")

print("全部完成")
